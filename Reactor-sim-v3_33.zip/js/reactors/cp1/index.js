// js/reactors/cp1/index.js
// Chicago Pile-1 — реактор-модуль (фабрика createCp1Reactor()), подшаг C
// плана «CP-1 + Shadow DOM» (см. AGENT_HANDOFF.md). Физика перенесена из
// mockups/cp1-steampunk-panel.html (простая учебная точечная кинетика,
// НЕ точная модель CP-1) почти без изменений — главные отличия:
//  - Реализует тот же контракт, что и РБМК: mount(container, {logger}) /
//    unmount() / start() / pause() / scram() / reset(mode) / getSnapshot() /
//    loadState(payload) / loadScenario(payload) / loadLesson(payload).
//  - Фабрика (не глобальные let в макете) — состояние в замыкании,
//    каждый mount() строит заново, как и РБМК.
//  - Физика раньше шагала по setInterval(500мс) фиксированным dt=0.5 —
//    теперь по requestAnimationFrame с реальным dt (и simSpeed) как у
//    РБМК; формула роста мощности не зависит от размера шага (это
//    непрерывная экспонента), так что результат идентичен, только более
//    гладкий.
//  - Собственная панель журнала макета (`.log-panel`) убрана — события
//    пишутся в общий EventLog оркестратора («Лог един»). Собственные
//    лампы-индикаторы (Крит./Подкрит./Авар. останов/Топор наготове)
//    ОСТАВЛЕНЫ как есть — общий annunciator-grid для них не используется
//    (см. panel_template.js).
//  - ОДИН shadow root (не четыре, как у РБМК) — разметка макета
//    самодостаточна, не размазана по нескольким CSS-контейнерам общего
//    index.html.
//  - У CP-1 нет разделения "Горячий/Холодный старт" (физика слишком
//    простая, чтобы это было содержательно) — общая кнопка «Старт»
//    (title-bar) доступна сразу после mount(), без отдельного шага сброса.

function createCp1Reactor() {
  // v3.13 — по замечанию пользователя: реактор по умолчанию заглушён (это
  // был эксперимент, не работающая станция). Регулирующие стержни введены
  // (0 = полностью введены в новых терминах "% введено", см. pctInserted
  // ниже), ЗАПУСК РЕАКТОРА выключен (ZIP заперт — без него критика
  // невозможна физически, см. computeReactivity), поток — на уровне фона.
  const state = {
    t: 0,
    rod1: 0,
    rod2: 0,
    zipOut: false,
    scram: false,
    power: 0.001, // относительный поток нейтронов (лог. шкала), фон
    precursor: 0, // концентрация предшественников запаздывающих нейтронов (1-групповое приближение)
    reactivityCents: 0,
    graphiteTemp: 22,
    meterRangeIdx: 1, // v3.16 — индекс диапазона шунта прибора (см. METER_RANGES), по умолчанию 10¹⁰ Ω, покрывает фон 0.001
    zipTripThreshold: 10, // v3.17 — уставка тросового ZIP (те же units, что power); регулируется оператором, см. mount()
    zipTripped: false, // v3.17 — стержень сброшен АВТОМАТИКОЙ (не рукой) — для лога/лампы, отличать от zipOut=false
    fullHistory: [], // v3.17 — оскциллограф "весь эксперимент": {t, power}, по времени (не по кадрам), НЕ срезается, см. sampleFullHistory()
    scopeMode: 'sweep', // v3.17 — 'sweep' (текущее поведение, по кадрам) | 'full' (весь буфер fullHistory по времени)
    history: [],
  };
  const MAX_HISTORY = 640;
  // v3.19 — по решению пользователя ускорение времени возвращено, но со
  // своим потолком ×10 (не ×3600, как у РБМК): весь эксперимент CP-1 по
  // graph_description.md — ~99 мин (5940с) истории, ×10 укладывает его в
  // ~10 мин игрового времени — «разумная длительность сессии» по прямому
  // указанию пользователя. ×1 остаётся «честным» темпом наравне с
  // историческим экспериментом. Ускорение НЕ влияет на оценку/сценарий —
  // нейтральный debug/просмотровый режим (см. История.md v3.18).
  const CP1_SPEED_PRESETS = [
    { value: 1, label: '×1' },
    { value: 2, label: '×2' },
    { value: 5, label: '×5' },
    { value: 10, label: '×10' },
  ];
  const FULL_HISTORY_SAMPLE_DT = 0.5; // v3.17 — интервал сэмплирования fullHistory, сим. секунды (~5400с эксперимента / 0.5с = ~10800 точек, разумно для canvas)
  let lastFullSampleT = -Infinity;

  // --- Точечная кинетика, 1 группа запаздывающих нейтронов (v3.13) ---
  // Раньше был голый экспоненциальный рост state.power *= exp(rho·k·dt) —
  // пользователь справедливо указал, что это противоречит центральному
  // историческому факту CP-1: реактор был управляем ЧЕЛОВЕКОМ ВРУЧНУЮ
  // именно благодаря запаздывающим нейтронам — они дают оператору МИНУТЫ,
  // а не секунды, на реакцию, пока реактивность остаётся ниже β (порога
  // мгновенной критичности). Без явного разделения на мгновенные/
  // запаздывающие нейтроны это свойство физически не может проявиться.
  // BETA/LAMBDA_GEN — типичные порядковые величины для теплового реактора
  // на графите (точных опубликованных чисел для CP-1 не нашёл, если у вас
  // есть источник с конкретным временем генерации нейтронов — можно
  // уточнить); LAMBDA_DECAY — эффективная 1-групповая постоянная распада
  // предшественников (типичное значение порядка 0.1 /с).
  const BETA = 0.0064; // эффективная доля запаздывающих нейтронов (близко к справочному значению для U-235)
  const LAMBDA_GEN = 0.05; // время жизни мгновенных нейтронов, с (порядок величины для графитового замедлителя — гораздо больше, чем в лёгководных реакторах)
  const LAMBDA_DECAY = 0.1; // постоянная распада предшественников, 1/с
  // v3.16 — по разбору графика эксперимента 2 декабря 1942 (см. AGENT_HANDOFF.md):
  // без внешнего источника подкритическая система физически не может держать
  // ненулевой поток бесконечно — она обязана экспоненциально спадать к нулю
  // (проверено численно: при ρ=-1цент n(1000с)=0.28, n(5000с)=0.03,
  // n(20000с)=6.9e-6 — это медленный спад, не плато). С источником S
  // появляется настоящее подкритическое равновесие n_eq = S·Λ/|ρ| — именно
  // так работает историческая техника приближения к критике по 1/M (Ra-Be
  // источник, стоявший в кладке CP-1 до выхода на самоподдержание).
  // Калибровка: S подобран так, чтобы при холодном старте (стержни введены,
  // ZIP заперт, ρ=-230 центов, см. computeReactivity) равновесный поток был
  // равен прежнему фоновому уровню state.power=0.001 — так не пришлось
  // менять начальные условия/шкалу прибора.
  const NEUTRON_SOURCE = 0.0002944; // S, тех же units, что n (относительный поток)

  // v3.16 — диапазоны шунта прибора (по графику: упомянуты 10⁹ и 10¹⁰ Ω,
  // остальные добавлены по той же логике для полного перекрытия шкалы
  // потока 0.0001..1000). Индекс 0 — самая высокая чувствительность
  // (большое Ω, для малых потоков у фона), растёт индекс — грубее
  // диапазон. Окна decade-перекрытия ×2, чтобы не было "мёртвой зоны"
  // между соседними диапазонами.
  const METER_RANGES = [
    { ohms: '10¹¹', min: 0.0001, max: 0.01 },
    { ohms: '10¹⁰', min: 0.001, max: 0.1 },
    { ohms: '10⁹', min: 0.01, max: 1 },
    { ohms: '10⁸', min: 0.1, max: 10 },
    { ohms: '10⁷', min: 1, max: 100 },
    { ohms: '10⁶', min: 10, max: 1000 },
  ];

  // v3.31 — по замечанию пользователя: шкала осциллографа мощности
  // (drawScope()) была захардкожена на 5.7 декады (~0.0003..158), тогда как
  // сама модель покрывает поток 0.0001..1000 (см. METER_RANGES выше) — 7
  // декад. Из-за этого при росте мощности выше ~158 кривая упиралась в
  // потолок графика и ложилась плашмя, хотя реактор продолжал расти —
  // выглядело как "рисование ограничено". Теперь шкала графика явно
  // совпадает с полным диапазоном модели.
  const SCOPE_LOG_MIN = -4; // log10(0.0001)
  const SCOPE_LOG_RANGE = 7; // log10(1000) - log10(0.0001)

  let diagnostics, alarms, scenarioEngine;
  let simRunning = false;
  let simSpeed = 1;
  // v3.19 — попап указаний урока (см. panel_template.js/cp1-panel.css):
  // _instructionDismissed — оператор свернул текущую подсказку вручную;
  // сбрасывается заново при переходе к СЛЕДУЮЩЕЙ цели урока (см.
  // renderInstructionPopup()) — свёрнутая на предыдущем шаге подсказка не
  // должна навсегда молчать. _lastRenderedGoalId — какая цель сейчас
  // активна, чтобы отследить этот переход.
  let _instructionDismissed = false;
  let _lastRenderedGoalId = null;
  // v3.15 — по разбору бага (см. AGENT_HANDOFF.md): у CP-1, в отличие от
  // РБМК (rodControlsLocked), органов управления вообще не было заблокировано
  // до нажатия «Старт» — стержни/тумблеры ZIP/SCRAM реагировали на мышь сразу
  // после mount(). Флаг ниже гейтит и обработчики (в mount()), и визуальное
  // состояние (disabled/класс .locked, см. setRodControlsLocked()).
  let rodControlsLocked = true;
  let lastTs = null;
  let rafHandle = null;
  let shadowRoot = null;
  let scopeCtx = null;
  let scopeCanvasEl = null;

  // v3.15 — вынесено из frame() наружу: раньше объявлялось `let growthRate=0`
  // ЗАНОВО каждый кадр, поэтому на паузе (simRunning=false) обнулялось
  // безусловно — стрелка периода прыгала к "∞" и обратно при паузе/продолжении
  // (баг из разбора, п.6). Теперь — держит последнее валидное значение, пока
  // не идёт новый расчёт (см. frame()).
  let growthRate = 0;

  let _boundListeners = [];
  function on(el, type, fn) {
    if (!el) return;
    el.addEventListener(type, fn);
    _boundListeners.push({ el, type, fn });
  }
  function offAll() {
    _boundListeners.forEach(({ el, type, fn }) => el.removeEventListener(type, fn));
    _boundListeners = [];
  }

  // v3.26 — по разбору с пользователем: непрерывный сервопривод-регулятор
  // (updateAutoRod/autoRodPos/setpointPct) убран из модели ПОЛНОСТЬЮ, не
  // только из этого урока. Причина — арифметика центов: максимум, что
  // могли дать оба ручных стержня (90 центов при полном выводе), был
  // МЕНЬШЕ полномочий автомата (180 центов), поэтому автомат физически
  // ВСЕГДА побеждал ручные стержни и намертво держал поток у уставки —
  // сколько ни отводи рычаги, реактор дальше не шёл. Это не давало пройти
  // исторический график (там несколько последовательных пиков со сменой
  // диапазона прибора, см. graph_description.md), да и исторически
  // автоматический стержень CP-1 был скорее пороговой сработкой (уже
  // реализовано отдельно как тросовый ZIP, см. zipTripThreshold ниже), а
  // не непрерывным ПИД-регулятором. Реактивность теперь полностью в руках
  // оператора — только стержни I/II, ZIP и А.ЗАЩИТА.
  function computeReactivity() {
    const w1 = (state.rod1 - 50) * 0.9;
    const w2 = (state.rod2 - 50) * 0.9;
    const zip = state.zipOut ? 0 : -140;
    const scramPenalty = state.scram ? -400 : 0;
    return w1 + w2 + zip + scramPenalty;
  }

  function kineticsDerivative(y, t) {
    const [n, C] = y;
    const rhoAbs = (state.reactivityCents / 100) * BETA; // цент -> доллар ($ = доля от β) -> абсолютная реактивность
    const dndt = ((rhoAbs - BETA) / LAMBDA_GEN) * n + LAMBDA_DECAY * C + NEUTRON_SOURCE;
    const dCdt = (BETA / LAMBDA_GEN) * n - LAMBDA_DECAY * C;
    return [dndt, dCdt];
  }

  function step(dt) {
    state.reactivityCents = computeReactivity();

    // Подшаги для численной устойчивости — при малом LAMBDA_GEN уравнения
    // точечной кинетики жёсткие, кадровый dt (до 0.25с) слишком груб для
    // RK4 напрямую при реактивности, близкой к β.
    const subSteps = Math.max(1, Math.ceil(dt / 0.02));
    const subDt = dt / subSteps;
    for (let i = 0; i < subSteps; i++) {
      const y = RK4Solver.step([state.power, state.precursor], state.t, subDt, kineticsDerivative);
      // v3.16 — с добавлением внешнего источника (NEUTRON_SOURCE) у системы
      // появилось настоящее физическое подкритическое равновесие (см.
      // комментарий у NEUTRON_SOURCE выше), поэтому пол 0.001 из v3.15
      // (костыль против "мёртвой" стрелки при спаде без источника) больше
      // не нужен — физика сама держит поток на нужном уровне. Оставлен
      // только численный пол на много порядков ниже, чтобы RK4 не увёл
      // n в отрицательные значения из-за шага интегрирования.
      state.power = Math.max(1e-9, Math.min(2000, y[0]));
      state.precursor = Math.max(0, y[1]);
      state.t += subDt;
    }

    const targetTemp = 20 + Math.min(state.power, 100) * 1.1;
    state.graphiteTemp += (targetTemp - state.graphiteTemp) * 0.02 * (dt / 0.5);

    // v3.17 — тросовый ZIP-стержень Зинна: простой пороговый триггер по
    // УРОВНЮ потока (не по реактивности/периоду — так и было устроено
    // физически, ионизационная камера + реле, см. AGENT_HANDOFF.md).
    // Порог задаёт оператор (zipThreshInput) — поэтому его можно выставить
    // слишком низко и получить историческую ложную сработку, как у Зинна
    // 2 декабря 1942 до обеда. Срабатывает только пока стержень реально
    // выведен и нет уже стоящей ручной А.ЗАЩИТЫ; ре-арм — только рукой
    // оператором (тумблер «ЗАПУСК РЕАКТОРА»), см. mount().
    if (state.zipOut && !state.scram && state.power >= state.zipTripThreshold) {
      state.zipOut = false;
      state.zipTripped = true;
      if (shadowRoot) shadowRoot.getElementById('zipToggle').classList.remove('on');
      diagnostics.log(
        state.t,
        'alarm',
        `АВТО-ZIP: поток достиг уставки ${state.zipTripThreshold.toFixed(3)} — стержень сброшен автоматикой`,
        'auto-zip',
        buildSnapshot()
      );
    }

    state.history.push(state.power);
    if (state.history.length > MAX_HISTORY) state.history.shift();

    // v3.17 — буфер "весь эксперимент": пишем по ВРЕМЕНИ, не по кадрам,
    // и не срезаем — иначе при разной частоте кадров/simSpeed развёртка
    // "full" искажалась бы (см. FUTURE_IDEAS.md, разбор перед реализацией).
    if (state.t - lastFullSampleT >= FULL_HISTORY_SAMPLE_DT) {
      state.fullHistory.push({ t: state.t, power: state.power });
      lastFullSampleT = state.t;
    }
  }

  function buildSnapshot() {
    return {
      t: state.t,
      power: state.power,
      reactivityCents: state.reactivityCents,
      graphiteTemp: state.graphiteTemp,
      rod1: state.rod1,
      rod2: state.rod2,
      zipOut: state.zipOut,
      scram: state.scram,
      meterRangeIdx: state.meterRangeIdx,
      zipTripThreshold: state.zipTripThreshold,
      zipTripped: state.zipTripped,
    };
  }

  // v3.11 — по договорённости с пользователем: панель показывает % ВВЕДЕНО
  // (как и РБМК), а не сырое state.rod1/rod2 (то внутри по-прежнему
  // "% выведено" — 0=внутри/введён, 100=снаружи/выведен, физика
  // computeReactivity() и формат сохранения НЕ меняются, флип только на
  // отображении, см. mount()/applyStateToDom()/обработчики ниже).
  function pctInserted(v) {
    return 100 - v;
  }

  // ---------- gauge rendering (перенесено из макета как есть) ----------
  function buildGauge(el, opts) {
    el.innerHTML = '';
    const cx = 98, cy = 98;
    const startAngle = -220, endAngle = 40;
    const span = endAngle - startAngle;

    function addMajorTick(t, label) {
      const ang = startAngle + t * span;
      const rad = (ang * Math.PI) / 180;
      const tick = document.createElement('div');
      tick.className = 'tick major';
      tick.style.transform = `rotate(${ang + 90}deg) translate(-1px, -92px)`;
      el.appendChild(tick);

      const num = document.createElement('div');
      num.className = 'tick-num';
      // v3.33 — по замечанию пользователя: цифры почти впритык к рискам.
      // Риски занимают полосу 80–92px (см. .tick.major в cp1-panel.css +
      // translate(-1px,-92px)), радиус цифр был 74px — зазор всего 6px,
      // да ещё центрирование цифры (translate(-50%,-50%), font-size 12px)
      // съедало половину этого зазора. Радиус уменьшен до 63px — зазор до
      // внутреннего края риски (80px) вырос до ~17px.
      const nx = cx + Math.cos(rad) * 63;
      const ny = cy + Math.sin(rad) * 63;
      num.style.left = nx + 'px';
      num.style.top = ny + 'px';
      num.textContent = label;
      el.appendChild(num);
    }

    function addMinorTick(t) {
      const ang = startAngle + t * span;
      const minor = document.createElement('div');
      minor.className = 'tick minor';
      minor.style.transform = `rotate(${ang + 90}deg) translate(-0.5px,-92px)`;
      el.appendChild(minor);
    }

    // v3.32 — два режима расстановки делений:
    // 1) opts.ticks — явный список {frac,label} в ПРОИЗВОЛЬНЫХ (не равных)
    //    угловых долях 0..1; нужен для настоящей лог. сетки "1-2-5"
    //    (см. rebuildFluxGaugeLabels), где деления идут по истинному log10,
    //    а не по равному индексу.
    // 2) opts.majorTicks/opts.labelForTick — старое поведение, N равных
    //    долей (используется gaugeReact, где сетка качественная, не числовая).
    if (opts.ticks) {
      opts.ticks.forEach((tk) => addMajorTick(tk.frac, tk.label));
      (opts.minorFracs || []).forEach((f) => addMinorTick(f));
    } else {
      const N = opts.majorTicks;
      for (let i = 0; i <= N; i++) {
        const t = i / N;
        addMajorTick(t, opts.labelForTick(i, N));
        if (i < N) {
          for (let m = 1; m < 4; m++) {
            addMinorTick(t + (m / 4) * (1 / N));
          }
        }
      }
    }
    const unit = document.createElement('div');
    unit.className = 'gauge-unit';
    unit.textContent = opts.unit;
    el.appendChild(unit);

    const needle = document.createElement('div');
    needle.className = 'needle';
    needle.id = opts.id + '_needle';
    el.appendChild(needle);

    const hub = document.createElement('div');
    hub.className = 'needle-hub';
    el.appendChild(hub);

    const readout = document.createElement('div');
    readout.className = 'gauge-readout';
    readout.id = opts.id + '_readout';
    el.appendChild(readout);

    el._opts = { startAngle, span };
  }

  function setNeedle(id, frac) {
    frac = Math.max(0, Math.min(1, frac));
    const el = shadowRoot.getElementById(id + '_needle');
    const gauge = shadowRoot.getElementById(id);
    const { startAngle, span } = gauge._opts;
    const ang = startAngle + frac * span;
    el.style.transform = `translate(-50%,-100%) rotate(${ang + 90}deg)`;
  }

  function buildNixieGroup(container, digits) {
    container.innerHTML = '';
    for (let i = 0; i < digits; i++) {
      const tube = document.createElement('div');
      tube.className = 'nixie-tube';
      const cap = document.createElement('div');
      cap.className = 'cap';
      const digit = document.createElement('div');
      digit.className = 'digit';
      digit.textContent = '0';
      tube.appendChild(cap);
      tube.appendChild(digit);
      container.appendChild(tube);
    }
  }
  function setNixieValue(container, value, digits) {
    const v = Math.max(0, Math.min(Math.pow(10, digits) - 1, Math.round(value)));
    const str = String(v).padStart(digits, '0');
    const tubes = container.querySelectorAll('.nixie-tube .digit');
    for (let i = 0; i < tubes.length; i++) tubes[i].textContent = str[i];
  }

  function drawScope() {
    if (!scopeCtx) return;
    const w = scopeCanvasEl.width, h = scopeCanvasEl.height;
    scopeCtx.fillStyle = '#03150a';
    scopeCtx.fillRect(0, 0, w, h);

    // v3.19 — в режиме 'full' нижняя полоса (~22% высоты) отведена под
    // историческую кривую (historical_overlay.js) — по решению
    // пользователя ОТДЕЛЬНОЙ полосой со своей шкалой 0..1 "качественной
    // высоты" из graph_description.md, а не наложением на лог-шкалу
    // мощности выше (см. История.md v3.18 — риск выдать оцифрованную
    // "форму" графика за сопоставимую физическую величину). В режиме
    // 'sweep' полоса не резервируется — поведение как раньше.
    const showHistStrip = state.scopeMode === 'full';
    const stripH = showHistStrip ? Math.round(h * 0.22) : 0;
    const mainH = h - stripH;

    scopeCtx.strokeStyle = 'rgba(61,255,122,0.12)';
    scopeCtx.lineWidth = 1;
    for (let x = 0; x < w; x += w / 10) {
      scopeCtx.beginPath();
      scopeCtx.moveTo(x, 0);
      scopeCtx.lineTo(x, mainH);
      scopeCtx.stroke();
    }
    for (let y = 0; y < mainH; y += mainH / 6) {
      scopeCtx.beginPath();
      scopeCtx.moveTo(0, y);
      scopeCtx.lineTo(w, y);
      scopeCtx.stroke();
    }

    scopeCtx.beginPath();
    scopeCtx.strokeStyle = '#3dff7a';
    scopeCtx.lineWidth = 2;
    scopeCtx.shadowColor = '#3dff7a';
    scopeCtx.shadowBlur = 6;
    if (state.scopeMode === 'full') {
      // v3.17 — "весь эксперимент": X по РЕАЛЬНОМУ времени точки относительно
      // текущего state.t (растягивается по мере роста t — кривая сжимается
      // влево, пока идёт эксперимент). Y — та же лог-шкала, что у sweep,
      // но теперь отмасштабирована на mainH (не на весь h), чтобы уступить
      // место полосе истории снизу.
      const hist = state.fullHistory;
      const tMax = Math.max(state.t, 1e-6);
      for (let i = 0; i < hist.length; i++) {
        const x = (hist[i].t / tMax) * w;
        const logv = Math.log10(Math.max(0.0005, hist[i].power));
        const norm = (logv - SCOPE_LOG_MIN) / SCOPE_LOG_RANGE;
        const y = mainH - Math.max(0, Math.min(1, norm)) * mainH;
        if (i === 0) scopeCtx.moveTo(x, y);
        else scopeCtx.lineTo(x, y);
      }
    } else {
      const hist = state.history;
      for (let i = 0; i < hist.length; i++) {
        const x = (i / (MAX_HISTORY - 1)) * w;
        const logv = Math.log10(Math.max(0.0005, hist[i]));
        const norm = (logv - SCOPE_LOG_MIN) / SCOPE_LOG_RANGE;
        const y = mainH - Math.max(0, Math.min(1, norm)) * mainH;
        if (i === 0) scopeCtx.moveTo(x, y);
        else scopeCtx.lineTo(x, y);
      }
    }
    scopeCtx.stroke();
    scopeCtx.shadowBlur = 0;

    if (showHistStrip) drawHistoricalStrip(w, mainH, stripH);
  }

  /**
   * Полоса исторической кривой (CP-1, 2 дек. 1942) под живым графиком
   * мощности. Своя шкала 0..1 (levelFrac из CP1_HISTORICAL_OVERLAY),
   * НЕ физическая величина — намеренно не смешивается визуально с
   * лог-шкалой мощности выше (см. drawScope()). x одной шкалы с основным
   * графиком (t/tMax*w) — это единственное, что здесь сопоставимо
   * напрямую: горизонтальное положение "где мы сейчас во времени
   * эксперимента относительно Ферми".
   */
  function drawHistoricalStrip(w, mainH, stripH) {
    const overlay = typeof CP1_HISTORICAL_OVERLAY !== 'undefined' ? CP1_HISTORICAL_OVERLAY : null;
    scopeCtx.strokeStyle = 'rgba(61,255,122,0.25)';
    scopeCtx.lineWidth = 1;
    scopeCtx.beginPath();
    scopeCtx.moveTo(0, mainH + 0.5);
    scopeCtx.lineTo(w, mainH + 0.5);
    scopeCtx.stroke();

    if (!overlay) return;

    const y0 = mainH + 3;
    const usableH = Math.max(1, stripH - 6);
    // v3.27 — по разбору с пользователем: раньше tMax полосы = state.t
    // (текущее время ЖИВОГО эксперимента), из-за чего историческая кривая
    // пересчитывала свой масштаб КАЖДЫЙ кадр под то, сколько прошло у
    // оператора, а не показывала фиксированную историческую форму. Пока
    // живой t < 5940 (а он почти всегда меньше — оператор редко идёт
    // секунда-в-секунду по Ферми), почти все точки CP1_HISTORICAL_OVERLAY
    // улетали за правый край канваса, и видна была только вытянутая,
    // почти плоская первая пара точек — отсюда жалоба «график не совпадает
    // с историей». Теперь tMax полосы — ФИКСИРОВАННАЯ полная длительность
    // исторического эксперимента (последняя точка overlay.curve, 5940 с),
    // историческая кривая всегда рисуется целиком, неизменной формы.
    // Сопоставление «где мы сейчас во времени эксперимента» перенесено в
    // отдельный вертикальный маркер ниже (используя ЖИВОЙ state.t по ТОЙ
    // ЖЕ фиксированной шкале) — так видно и полную историческую форму, и
    // прогресс оператора относительно неё одновременно.
    const histTotalT = overlay.curve.length ? overlay.curve[overlay.curve.length - 1].t : 1;
    const tMax = Math.max(histTotalT, 1e-6);
    const histColor = 'rgba(214,178,74,0.8)'; // приглушённый жёлто-серый — сознательно отличается от зелёного живого графика

    scopeCtx.beginPath();
    scopeCtx.strokeStyle = histColor;
    scopeCtx.lineWidth = 1.5;
    scopeCtx.setLineDash([4, 3]);
    for (let i = 0; i < overlay.curve.length; i++) {
      const p = overlay.curve[i];
      const x = (p.t / tMax) * w;
      const y = y0 + usableH - Math.max(0, Math.min(1, p.levelFrac)) * usableH;
      if (i === 0) scopeCtx.moveTo(x, y);
      else scopeCtx.lineTo(x, y);
    }
    scopeCtx.stroke();
    scopeCtx.setLineDash([]);

    // засечки событий — только внутри полосы (сознательно не выходят на
    // график мощности выше, чтобы не намекать на сопоставимость шкал)
    scopeCtx.font = '7px monospace';
    for (const ev of overlay.events) {
      const x = (ev.t / tMax) * w;
      if (x < -5 || x > w + 5) continue;
      scopeCtx.strokeStyle = 'rgba(214,178,74,0.3)';
      scopeCtx.lineWidth = 1;
      scopeCtx.setLineDash([2, 2]);
      scopeCtx.beginPath();
      scopeCtx.moveTo(x, y0);
      scopeCtx.lineTo(x, y0 + usableH);
      scopeCtx.stroke();
      scopeCtx.setLineDash([]);
      scopeCtx.save();
      scopeCtx.fillStyle = 'rgba(214,178,74,0.7)';
      scopeCtx.translate(Math.min(w - 2, x + 2), y0 + usableH - 1);
      scopeCtx.rotate(-Math.PI / 2);
      scopeCtx.fillText(ev.label, 0, 0);
      scopeCtx.restore();
    }

    scopeCtx.font = '8px monospace';
    scopeCtx.fillStyle = histColor;
    scopeCtx.fillText('ИСТОРИЯ: 2 ДЕК. 1942 · НЕ В МАСШТАБЕ', 4, y0 + 7);

    // v3.27 — маркер «вы сейчас здесь»: живой state.t на ТОЙ ЖЕ
    // фиксированной шкале tMax, что и историческая кривая выше. Если
    // живой эксперимент обогнал историческую длительность (state.t >
    // histTotalT), маркер прижимается к правому краю, а не улетает за
    // канвас — оператор всё равно видит, что он «дальше конца истории».
    const curX = Math.max(0, Math.min(w, (state.t / tMax) * w));
    scopeCtx.strokeStyle = 'rgba(255,255,255,0.55)';
    scopeCtx.lineWidth = 1;
    scopeCtx.setLineDash([1, 2]);
    scopeCtx.beginPath();
    scopeCtx.moveTo(curX, y0);
    scopeCtx.lineTo(curX, y0 + usableH);
    scopeCtx.stroke();
    scopeCtx.setLineDash([]);
    scopeCtx.fillStyle = 'rgba(255,255,255,0.75)';
    scopeCtx.font = '7px monospace';
    const markerLabel = 'ВЫ ЗДЕСЬ';
    const labelX = curX + 3 > w - 40 ? curX - 3 - scopeCtx.measureText(markerLabel).width : curX + 3;
    scopeCtx.fillText(markerLabel, Math.max(2, labelX), y0 + 7);
  }

  /**
   * v3.19 — попап указаний текущего урока (см. panel_template.js). Логика
   * сознательно ПРОСТАЯ по прямому требованию пользователя: показывает
   * ПЕРВУЮ незавершённую цель урока и ничего не проверяет сверх этого —
   * не "прячет" подсказку и не помечает её проваленной из-за того, что
   * живой график мощности разошёлся с исторической кривой-оверлеем
   * (обсуждение см. История.md). Цели урока сами по себе триггерятся
   * только по модельному времени (`t`), см. lessons/cp1-historical-run —
   * поэтому они и не могут "сорваться" от действий оператора, только
   * последовательно открываться по ходу времени.
   */
  function renderInstructionPopup() {
    const popupEl = shadowRoot.getElementById('instructionPopup');
    const reopenEl = shadowRoot.getElementById('instructionReopenBtn');
    if (!popupEl || !reopenEl) return;

    if (!scenarioEngine || !scenarioEngine.isLoaded()) {
      popupEl.hidden = true;
      reopenEl.hidden = true;
      return;
    }

    const goals = scenarioEngine.getGoalsState();
    if (!goals.length) {
      popupEl.hidden = true;
      reopenEl.hidden = true;
      return;
    }

    const doneCount = goals.filter((g) => g.completed).length;
    const current = goals.find((g) => !g.completed) || goals[goals.length - 1];

    // Переход к следующей цели — заново разворачиваем, даже если
    // предыдущую оператор свернул вручную (свёрнутое указание не должно
    // навсегда молчать до конца урока).
    if (current.id !== _lastRenderedGoalId) {
      _instructionDismissed = false;
      _lastRenderedGoalId = current.id;
    }

    shadowRoot.getElementById('instructionCount').textContent = `${Math.min(doneCount + 1, goals.length)} / ${goals.length}`;
    shadowRoot.getElementById('instructionTitle').textContent = current.title || '';
    shadowRoot.getElementById('instructionText').textContent = current.goalText || '';
    shadowRoot.getElementById('instructionHint').textContent = current.hintText || '';

    popupEl.hidden = _instructionDismissed;
    reopenEl.hidden = !_instructionDismissed;
  }

  // v3.22 — БАГФИКС: раньше подписи делений шкалы счётчика потока были
  // ФИКСИРОВАННЫМИ (.001..1000, все 6 декад разом), а положение стрелки
  // считается ОТНОСИТЕЛЬНО ВЫБРАННОГО ДИАПАЗОНА ШУНТА (METER_RANGES[idx],
  // всего 2 декады) — из-за этого при уставке/потоке за пределами текущего
  // диапазона стрелка утыкалась в упор шкалы, а напечатанное там число
  // (напр. «1000») не имело отношения к реальному значению (см. разбор
  // бага с уставкой в чате). Теперь подписи пересчитываются под текущий
  // диапазон при каждой смене шунта — см. rebuildFluxGaugeLabels().
  // v3.29 — по замечанию пользователя: подписи делений занимали много места
  // на маленьком циферблате (напр. "0.0464"). Реальные приборы такого типа
  // обычно решают это отдельным множителем шкалы (аналог переключателя
  // декад шунта, который здесь уже есть — см. METER_RANGES/rangeVal), а не
  // печатью полного числа на каждой отметке — степень печатается один раз
  // рядом с "ОТН. ЕД." через SUPERSCRIPT_DIGITS, сами деления — круглая
  // мантисса (см. v3.32 ниже, FLUX_MAJOR_MANTISSAS).
  const SUPERSCRIPT_DIGITS = { '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹', '-': '⁻' };
  function toSuperscript(n) {
    return String(n).split('').map((ch) => SUPERSCRIPT_DIGITS[ch] || ch).join('');
  }

  // v3.32 — по замечанию пользователя: прежняя раскладка (6 РАВНЫХ угловых
  // делений) давала мантиссы вида 1, 2.15, 4.64, 10, 21.5, 46.4, 100 —
  // некруглые числа, на маленьком циферблате не считываются с одного
  // взгляда. Заменено на стандартную для аналоговых лог. приборов сетку
  // "1-2-5": подписаны круглые 1,2,5,10,20,50,100, а угловое положение
  // каждой — ИСТИННАЯ логарифмическая позиция (frac = log10(v)/decades),
  // поэтому углы между соседними цифрами не равны (как и должно быть у
  // лог. шкалы) — короткий интервал 1↔2, чуть длиннее 2↔5, снова короткий
  // 5↔10, и так по второй декаде. Неподписанные минорные риски — на
  // промежуточных целых 3,4,6,7,8,9(,30,40,60,70,80,90).
  const FLUX_MAJOR_MANTISSAS = [1, 2, 5, 10, 20, 50, 100];
  const FLUX_MINOR_MANTISSAS = [3, 4, 6, 7, 8, 9, 30, 40, 60, 70, 80, 90];

  function rebuildFluxGaugeLabels() {
    const gaugeFluxEl = shadowRoot.getElementById('gaugeFlux');
    if (!gaugeFluxEl) return;
    const range = METER_RANGES[state.meterRangeIdx];
    const decades = Math.log10(range.max) - Math.log10(range.min);
    // v3.29 — множитель = десятичный порядок нижней границы диапазона, тогда
    // мантисса лежит в 1..100 (2 декады диапазона) вместо абсолютных чисел
    // вроде 0.0464/0.0215 — короче и читается быстрее. Множитель печатается
    // один раз в unit-подписи.
    const exp = Math.floor(Math.log10(range.min));
    buildGauge(gaugeFluxEl, {
      id: 'gaugeFlux',
      unit: exp === 0 ? 'ОТН. ЕД.' : `ОТН. ЕД. ×10${toSuperscript(exp)}`,
      ticks: FLUX_MAJOR_MANTISSAS.map((v) => ({ frac: Math.log10(v) / decades, label: String(v) })),
      minorFracs: FLUX_MINOR_MANTISSAS.map((v) => Math.log10(v) / decades),
    });
  }

  // v3.29 — по замечанию пользователя: реальная рабочая зона стержня I на
  // историческом уроке — 1-10% (см. lessons/cp1-historical-run.lesson.json),
  // а рычаг был линейным 0..100 — то есть вся содержательная зона занимала
  // ~1/10 хода мыши, остальные 9/10 хода вообще не используются на этом
  // уроке. Сделан НЕ буквально логарифмический слайдер (это ломается на
  // rod=0, физически валидном значении — полностью введённый стержень), а
  // кусочно-линейный: нижняя половина хода рычага (raw 0..50) растягивает
  // 0..20% реального положения (4x подробнее прежнего), верхняя половина
  // (raw 50..100) — оставшиеся 20..100% как было, грубее (эта часть нужна
  // редко — только чтобы быстро довыдвинуть стержень целиком). Точка сгиба
  // (20%) выбрана с запасом над рабочей зоной уроков (макс. 10%), чтобы весь
  // содержательный диапазон был в подробной половине. HTML step рычага
  // уменьшен с целочисленного до 0.1 (см. panel_template.js) — иначе даже
  // кусочная растяжка упёрлась бы в целочисленные 0.4%-шаги.
  const ROD_SLIDER_BREAK_RAW = 50;
  const ROD_SLIDER_BREAK_PCT = 20;
  function sliderToRod(raw) {
    raw = Math.max(0, Math.min(100, raw));
    if (raw <= ROD_SLIDER_BREAK_RAW) return (raw / ROD_SLIDER_BREAK_RAW) * ROD_SLIDER_BREAK_PCT;
    return ROD_SLIDER_BREAK_PCT + ((raw - ROD_SLIDER_BREAK_RAW) / (100 - ROD_SLIDER_BREAK_RAW)) * (100 - ROD_SLIDER_BREAK_PCT);
  }
  function rodToSlider(pct) {
    pct = Math.max(0, Math.min(100, pct));
    if (pct <= ROD_SLIDER_BREAK_PCT) return (pct / ROD_SLIDER_BREAK_PCT) * ROD_SLIDER_BREAK_RAW;
    return ROD_SLIDER_BREAK_RAW + ((pct - ROD_SLIDER_BREAK_PCT) / (100 - ROD_SLIDER_BREAK_PCT)) * (100 - ROD_SLIDER_BREAK_RAW);
  }

  function updateLeverVisual(handleEl, val) {
    const trackH = 114, handleH = 19;
    const top = 8 + (1 - val / 100) * (trackH - handleH);
    handleEl.style.top = top + 'px';
  }

  // v3.25 — по замечанию пользователя: раньше здесь были РЕАЛЬНЫЕ часы
  // (Date().getHours()/getMinutes()/getSeconds()) — как у настенной таблички
  // в макете. Заменено на модельное время с начала эксперимента (state.t),
  // в ТОМ ЖЕ формате, что и у РБМК (formatModelTimeLong() в
  // js/reactors/rbmk/index.js: "Д ЧЧ:ММ:СС") — для единообразия между
  // реакторами. Обновляется в frame() вместе с остальными показаниями (не
  // отдельным setInterval — тому не было доступа к state.t).
  function formatModelTimeLong(t) {
    const days = Math.floor(t / 86400);
    const h = Math.floor((t % 86400) / 3600).toString().padStart(2, '0');
    const m = Math.floor((t % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(t % 60).toString().padStart(2, '0');
    return `${days} ${h}:${m}:${s}`;
  }

  // Данные общие (общий EventLog оркестратора, «Лог един»), но рендер —
  // родной для CP-1 (состаренная бумага, "Т+####с" — формат из исходного
  // макета, см. mockups/cp1-steampunk-panel.html, функция logMsg()).
  // Не переиспользует SharedLogPanel (тот рисует в стиле РБМК) — см.
  // AGENT_HANDOFF.md v3.12.
  let _lastLogVersion = -1;
  function renderOwnLog() {
    if (!diagnostics || diagnostics._logVersion === _lastLogVersion) return;
    _lastLogVersion = diagnostics._logVersion;
    const logEl = shadowRoot.getElementById('log');
    if (!logEl) return;
    logEl.innerHTML = diagnostics.events
      .map((e) => {
        const t = Math.max(0, Math.round(e.t)).toString().padStart(4, '0');
        return `<div><span class="t">Т+${t}с</span>${e.text}</div>`;
      })
      .join('');
    logEl.scrollTop = logEl.scrollHeight;
  }

  // v3.15 — визуальная и функциональная блокировка органов управления до
  // «Старт» (аналог rodControlsLocked у РБМК). rod1Input/rod2Input —
  // настоящие <input>, для них штатный .disabled (браузер сам не шлёт
  // 'input' событие с disabled-элемента). zipToggle/scramToggle — <div> с
  // собственным click-обработчиком (не <button>), поэтому для них — явная
  // проверка rodControlsLocked в начале обработчика (ниже) + класс .locked
  // только для визуала (dim + cursor:not-allowed, см. cp1-panel.css).
  function setRodControlsLocked(locked) {
    rodControlsLocked = locked;
    const rod1Input = shadowRoot.getElementById('rod1Input');
    const rod2Input = shadowRoot.getElementById('rod2Input');
    const zipToggle = shadowRoot.getElementById('zipToggle');
    const scramToggle = shadowRoot.getElementById('scramToggle');
    rod1Input.disabled = locked;
    rod2Input.disabled = locked;
    rod1Input.closest('.lever-track')?.classList.toggle('locked', locked);
    rod2Input.closest('.lever-track')?.classList.toggle('locked', locked);
    zipToggle.classList.toggle('locked', locked);
    scramToggle.classList.toggle('locked', locked);
    // v3.30 — точная установка (см. makeRodValueEditable()) тоже органы
    // управления стержнем — блокируется/разблокируется вместе с рычагами.
    shadowRoot.getElementById('rod1Read')?.classList.toggle('locked', locked);
    shadowRoot.getElementById('rod2Read')?.classList.toggle('locked', locked);
  }

  function onScram() {
    // v3.13 — SCRAM больше не трогает положение регулирующих стержней
    // (историческая неточность старой версии) — аварийный стержень
    // физически ОТДЕЛЬНЫЙ от регулирующих, вставляется независимо. Одного
    // штрафа -400 цент в computeReactivity() достаточно для глубокой
    // подкритичности вне зависимости от того, где стоят стержни I/II.
    state.scram = true;
    shadowRoot.getElementById('scramToggle').classList.add('on');
    shadowRoot.getElementById('lampScram').classList.add('on');
    diagnostics.log(state.t, 'alarm', 'АВАРИЙНАЯ ЗАЩИТА — стержень аварийной защиты введён', 'scram', buildSnapshot());
  }

  function onStart() {
    simRunning = true;
    // v3.24 — БАГФИКС: раньше дропдаун реактора здесь НЕ блокировался
    // (см. историю ниже) — это и позволило переключиться на другой реактор
    // прямо посреди урока/сессии CP-1, оставив панель CP-1 висеть на
    // экране с застывшим состоянием (репорт пользователя, разбор в чате).
    // Теперь блокируем как у РБМК; разблокировка — в mount() (свежий
    // маунт) и в applyStatePayload() (загрузка состояния/урока — тоже
    // естественная точка "начали заново").
    //
    // Старое обоснование (v3.15, уже неактуально, оставлено для истории):
    // «В отличие от РБМК дропдаун реактора здесь НЕ блокируется — у CP-1
    // нет терминальной аварии (нечего защищать преждевременным
    // переключением), а отдельной кнопки сброса, которая могла бы потом
    // разблокировать дропдаун (как afterStartReset() у РБМК), у CP-1 тоже
    // нет.» — второй тезис оказался ложным поводом для дыры: раз кнопки
    // сброса нет, разблокировкой стали естественные точки «начали заново»
    // (см. выше), а не полное отсутствие блокировки.
    ControlsPanel.setReactorSelectLocked(true);
    // v3.15 — а органы управления (стержни/ZIP/SCRAM), в отличие от
    // дропдауна, разблокируются здесь и остаются разблокированными до
    // unmount()/reset() — пауза их повторно не запирает (в отличие от РБМК),
    // т.к. баг был именно про «активно ДО Старта», про паузу пользователь
    // не сообщал.
    setRodControlsLocked(false);
    diagnostics.log(state.t, 'info', 'Симуляция CP-1 запущена оператором', 'system', buildSnapshot());
  }

  function onPauseToggle() {
    simRunning = !simRunning;
    diagnostics.log(state.t, 'info', simRunning ? 'Симуляция продолжена оператором' : 'Симуляция поставлена на паузу оператором', 'system', buildSnapshot());
    return simRunning;
  }

  function frame(ts) {
    if (lastTs === null) lastTs = ts;
    let realDt = (ts - lastTs) / 1000;
    lastTs = ts;
    realDt = Math.min(realDt, 0.25);

    // v3.15 — раньше: growthRate = ln(power_после/power_до) / realDt, т.е.
    // "сырая" разница мощности ЗА ОДИН КАДР (обычно 16-250мс). Это
    // статистически шумная оценка — любое резкое изменение входа (тумблер,
    // движение стержня, снятие паузы) даёт на один кадр экстремальное
    // отношение, стрелка улетает в крайнее положение и затем "остывает" на
    // следующих кадрах до настоящего периода (баг из разбора, п.3-5,7-8).
    // Теперь — берём МГНОВЕННУЮ логарифмическую производную прямо из
    // уравнений точечной кинетики (dn/dt / n при текущих n, C и
    // reactivityCents, ПОСЛЕ шага физики) — это та же величина, что и раньше
    // в пределе realDt→0, но без шума дискретизации по кадру: убрано деление
    // на маленький realDt, любое дрожание убрано на уровне формулы, а не
    // сглаживанием постфактум.
    if (simRunning) {
      step(realDt * simSpeed);
      const n = state.power;
      growthRate = n > 0 ? kineticsDerivative([n, state.precursor], state.t)[0] / n : 0;
    }
    // else: growthRate НЕ трогаем — держит последнее валидное значение на
    // паузе, не пересчитывает и не обнуляет (баг из разбора, п.6).

    // v3.16 — стрелка растягивается по ВЫБРАННОМУ диапазону шунта
    // (METER_RANGES[meterRangeIdx]), а не по фиксированным 6 декадам —
    // так и был устроен реальный прибор: один и тот же реальный поток даёт
    // разное отклонение стрелки в зависимости от выбранного шунта, и при
    // выходе за пределы диапазона стрелка "пришпилена" к краю (сигнал
    // оператору переключить диапазон), а не улетает с циферблата.
    const range = METER_RANGES[state.meterRangeIdx];
    const logp = Math.log10(Math.max(1e-9, state.power));
    const fluxFrac = Math.max(0, Math.min(1, (logp - Math.log10(range.min)) / (Math.log10(range.max) - Math.log10(range.min))));
    setNeedle('gaugeFlux', fluxFrac);
    shadowRoot.getElementById('gaugeFlux_readout').textContent = state.power < 1 ? state.power.toFixed(3) : state.power.toFixed(1);

    // v3.13 — правый прибор теперь "Период разгона" (physически осмысленная
    // величина, которую реально считал Ферми), не "запас реактивности в
    // центах" (анахронизм, см. AGENT_HANDOFF.md). Игла — по тангенсу от
    // темпа роста (гладкое насыщение к краям, 0.5 = стабильно), текст —
    // сам период в секундах или "∞" рядом с равновесием.
    const reactFrac = 0.5 + 0.5 * Math.tanh(growthRate * 20);
    setNeedle('gaugeReact', reactFrac);
    // v3.22 — по просьбе пользователя: раньше при почти-нулевом growthRate
    // (реактор у равновесия) 1/growthRate улетало в произвольно большие
    // 5-6-значные числа — математически честно, но нечитаемо и создавало
    // впечатление "разгона", хотя стрелка (см. выше) в этот момент как раз
    // показывает стабильность. Теперь капаем отображение на ±999с — знак
    // сохраняем (растёт/спадает), а не заменяем на "∞" раньше времени.
    {
      const periodVal = 1 / growthRate;
      let periodText;
      if (Math.abs(growthRate) < 1e-4) {
        periodText = '∞';
      } else if (Math.abs(periodVal) > 999) {
        periodText = (periodVal > 0 ? '>999' : '<-999') + ' с';
      } else {
        periodText = periodVal.toFixed(0) + ' с';
      }
      shadowRoot.getElementById('gaugeReact_readout').textContent = periodText;
    }

    setNixieValue(shadowRoot.getElementById('tempNixie'), state.graphiteTemp, 3);

    const critical = Math.abs(growthRate) < 0.002 && state.power > 0.01 && !state.scram;
    shadowRoot.getElementById('lampCrit').classList.toggle('on', critical);
    shadowRoot.getElementById('lampSub').classList.toggle('on', growthRate < -0.002 || state.power <= 0.01 || state.scram);
    if (state.scram) shadowRoot.getElementById('lampScram').classList.add('on');
    else shadowRoot.getElementById('lampScram').classList.remove('on');
    shadowRoot.getElementById('lampZipTrip').classList.toggle('on', state.zipTripped);

    shadowRoot.getElementById('wallClock').textContent = formatModelTimeLong(state.t);

    drawScope();

    alarms.evaluate(state.t, buildSnapshot());
    renderOwnLog();

    // v3.19 — урок CP-1 (см. loadLesson): цели идут по МОДЕЛЬНОМУ времени
    // (`t` в снапшоте, не scenarioTimeSec движка) — это осознанно, см.
    // История.md: у CP-1 есть ускорение ×1..×10, а модельное время t уже
    // растягивает историческую кривую-оверлей (drawScope()) по той же
    // логике, так что оба привязаны к одной и той же оси и не разъезжаются
    // при смене скорости. sequentialGoals:true в самом уроке — движок сам
    // добавляет сообщение-подтверждение по каждой цели в общий журнал.
    if (scenarioEngine && scenarioEngine.isLoaded()) {
      scenarioEngine.tick(buildSnapshot(), realDt, simRunning);
      scenarioEngine.getActiveMessages().forEach((m) => {
        diagnostics.log(state.t, m.severity, m.text, 'scenario', buildSnapshot());
      });
    }
    renderInstructionPopup();

    rafHandle = requestAnimationFrame(frame);
  }

  function exportStateToJson() {
    const payload = {
      formatVersion: 1,
      reactor: 'cp1',
      savedAt: new Date().toISOString(),
      simSpeed,
      state: {
        t: state.t,
        rod1: state.rod1,
        rod2: state.rod2,
        zipOut: state.zipOut,
        scram: state.scram,
        power: state.power,
        precursor: state.precursor,
        graphiteTemp: state.graphiteTemp,
        meterRangeIdx: state.meterRangeIdx,
        zipTripThreshold: state.zipTripThreshold,
      },
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    a.href = url;
    a.download = `cp1-state-${ts}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    diagnostics.log(state.t, 'info', 'Состояние CP-1 сохранено в файл', 'system', buildSnapshot());
  }

  function applyStateToDom() {
    shadowRoot.getElementById('rod1Input').value = rodToSlider(state.rod1); // v3.29 — обратное преобразование (физич. % -> позиция рычага)
    shadowRoot.getElementById('rod2Input').value = rodToSlider(state.rod2);
    shadowRoot.getElementById('rod1Read').textContent = pctInserted(state.rod1) + '%';
    shadowRoot.getElementById('rod2Read').textContent = pctInserted(state.rod2) + '%';
    setNixieValue(shadowRoot.getElementById('rod1Nixie'), pctInserted(state.rod1), 3);
    setNixieValue(shadowRoot.getElementById('rod2Nixie'), pctInserted(state.rod2), 3);
    updateLeverVisual(shadowRoot.getElementById('lever1'), state.rod1);
    updateLeverVisual(shadowRoot.getElementById('lever2'), state.rod2);
    shadowRoot.getElementById('zipToggle').classList.toggle('on', state.zipOut);
    shadowRoot.getElementById('scramToggle').classList.toggle('on', state.scram);
    shadowRoot.getElementById('lampScram').classList.toggle('on', state.scram);
    shadowRoot.getElementById('rangeVal').textContent = METER_RANGES[state.meterRangeIdx].ohms;
    const zipThreshInput = shadowRoot.getElementById('zipThreshInput');
    zipThreshInput.value = Math.round((Math.log10(Math.max(0.001, state.zipTripThreshold)) + 3) * 100);
    shadowRoot.getElementById('zipThreshVal').textContent = state.zipTripThreshold < 1 ? state.zipTripThreshold.toFixed(3) : state.zipTripThreshold.toFixed(1);
    shadowRoot.getElementById('lampZipTrip').classList.toggle('on', state.zipTripped);
  }

  function applyStatePayload(payload, label) {
    try {
      // v3.24 — загрузка состояния/урока ставит симуляцию на паузу: сама
      // по себе загрузка не должна "молча" продолжать идти на скорости от
      // предыдущего состояния, плюс это единственная надёжная точка, где
      // безопасно снова разблокировать дропдаун реактора (см. ниже) — если
      // бы simRunning остался true, разблокировка тут же повторно открыла
      // бы дыру, которую мы только что закрыли в onStart().
      simRunning = false;
      ControlsPanel.resetRunControl(); // v3.24 — визуал кнопок Старт/Пауза синхронизирован с simRunning=false выше
      const s = payload.state || payload; // допускаем как {reactor,state:{...}}, так и голый снимок
      state.rod1 = s.rod1 ?? 0;
      state.rod2 = s.rod2 ?? 0;
      state.zipOut = !!s.zipOut;
      state.scram = !!s.scram;
      state.power = s.power ?? 0.001;
      state.precursor = s.precursor ?? 0;
      state.graphiteTemp = s.graphiteTemp ?? 22;
      state.meterRangeIdx = Number.isInteger(s.meterRangeIdx) ? Math.max(0, Math.min(METER_RANGES.length - 1, s.meterRangeIdx)) : 1;
      state.zipTripThreshold = s.zipTripThreshold ?? 10;
      state.zipTripped = false; // v3.17 — сознательно не восстанавливаем "только что сработал" из сохранённого файла
      state.t = s.t ?? 0;
      state.history = [];
      state.fullHistory = []; // v3.17 — не персистентен, см. AGENT_HANDOFF.md
      lastFullSampleT = -Infinity;
      rebuildFluxGaugeLabels(); // v3.22 — диапазон шунта мог измениться при загрузке
      // v3.20 — БАГФИКС: раньше simSpeed вообще не восстанавливался отсюда.
      // Если оператор до загрузки состояния/урока нажимал ×2/×5/×10, эта
      // скорость молча продолжала действовать и после загрузки (кнопки в
      // ControlsPanel тоже не переключались обратно) — отсюда «стержни не
      // трогали, а время уже улетело на тысячи секунд» при загрузке урока.
      // Теперь читаем simSpeed из того же payload, что даёт exportStateToJson
      // (payload.simSpeed на верхнем уровне, СНАРУЖИ payload.state), и
      // синхронизируем подсветку кнопок.
      simSpeed = Number(payload.simSpeed) > 0 ? Number(payload.simSpeed) : 1;
      ControlsPanel.selectSpeed(simSpeed);
      ControlsPanel.setReactorSelectLocked(false); // v3.24 — загрузка состояния/урока = "начали заново", см. onStart()
      applyStateToDom();
      diagnostics.log(state.t, 'info', label, 'system', buildSnapshot());
      return { ok: true };
    } catch (e) {
      diagnostics.log(state.t, 'alarm', `Не удалось загрузить состояние CP-1: ${e.message}`, 'system', buildSnapshot());
      return { ok: false, error: e.message };
    }
  }

  function mount(container, opts = {}) {
    diagnostics = opts.logger;
    if (!diagnostics) throw new Error('createCp1Reactor().mount(): нужен opts.logger (общий EventLog оркестратора)');

    state.t = 0;
    state.rod1 = 0;
    state.rod2 = 0;
    state.zipOut = false;
    state.scram = false;
    state.power = 0.001;
    state.precursor = 0;
    state.reactivityCents = 0;
    state.graphiteTemp = 22;
    state.meterRangeIdx = 1;
    state.zipTripThreshold = 10;
    state.zipTripped = false;
    state.fullHistory = [];
    state.scopeMode = 'sweep';
    lastFullSampleT = -Infinity;
    state.history = [];
    simRunning = false;
    simSpeed = 1;

    alarms = new Cp1Alarms(diagnostics);
    scenarioEngine = new ScenarioEngine();
    _instructionDismissed = false;
    _lastRenderedGoalId = null;
    // v3.19 — Dashboard.renderScenarioPanel (обычно управляет disabled этой
    // кнопки) вызывается только из RBMK-модуля, для CP-1 не вызывается —
    // управляем состоянием кнопки сами.
    document.getElementById('btn-reset-scenario').disabled = true;
    ControlsPanel.setReactorSelectLocked(false); // v3.24 — свежий маунт всегда разблокирован

    const slot = document.getElementById('slot-cp1-panel');
    shadowRoot = slot.shadowRoot || slot.attachShadow({ mode: 'open' });

    // v3.11 — по договорённости с пользователем: панели времени РБМК и
    // "Активная зона · СУЗ" — специфичны для РБМК по смыслу, у CP-1 нет
    // ни того, ни другого (своя настенная табличка с реальным временем
    // внутри собственной панели, свои лампы вместо аннунциатора) —
    // прячем весь #console-row (левая колонка + центр/право РБМК) и
    // пустые console-diagnostics-row/console-thermal-row целиком.
    // v3.12 — #event-log-panel (общий, снаружи Shadow DOM) здесь БОЛЬШЕ
    // НЕ ПЕРЕСТАВЛЯЕТСЯ наружу — остаётся внутри скрытого
    // #console-diagnostics-row (то есть тоже скрыт). Пользователь указал,
    // что вынос общей RBMK-стилизованной панели журнала за пределы панели
    // CP-1 был ошибкой — у CP-1 свой дизайн, журнал должен быть частью
    // самой панели (см. .log-panel в panel_template.js), не отдельным
    // блоком снаружи. Данные при этом остаются общими (общий EventLog,
    // «Лог един») — просто рендерятся собственным кодом, см. renderOwnLog().
    document.getElementById('console-row').style.display = 'none';
    document.getElementById('console-diagnostics-row').style.display = 'none';
    document.getElementById('console-thermal-row').style.display = 'none';

    // Собственный CSS (не пересекается с css/style.css РБМК — другое
    // shadow-дерево) + шрифты, которые макет подключал в <head> (Rye/
    // Special Elite/Arvo/Cutive Mono, см. AGENT_HANDOFF.md).
    shadowRoot.innerHTML =
      '<link rel="preconnect" href="https://fonts.googleapis.com">' +
      '<link href="https://fonts.googleapis.com/css2?family=Rye&family=Special+Elite&family=Arvo:wght@400;700&family=Cutive+Mono&display=swap" rel="stylesheet">' +
      '<link rel="stylesheet" href="css/cp1-panel.css">' +
      CP1_TEMPLATE_MAIN;

    // v3.22 — подписи циферблата строятся динамически под текущий диапазон
    // шунта, см. rebuildFluxGaugeLabels(); финальный вызов applyRangeIdx()
    // ниже в mount() перестраивает их сразу под актуальный meterRangeIdx.
    rebuildFluxGaugeLabels();
    buildGauge(shadowRoot.getElementById('gaugeReact'), {
      id: 'gaugeReact',
      majorTicks: 4,
      unit: 'ПЕРИОД',
      labelForTick: (i) => ['спад', '', '∞', '', 'рост'][i] ?? '',
    });

    const rod1Nixie = shadowRoot.getElementById('rod1Nixie');
    const rod2Nixie = shadowRoot.getElementById('rod2Nixie');
    const tempNixie = shadowRoot.getElementById('tempNixie');
    buildNixieGroup(rod1Nixie, 3);
    buildNixieGroup(rod2Nixie, 3);
    buildNixieGroup(tempNixie, 3);
    setNixieValue(rod1Nixie, pctInserted(0), 3);
    setNixieValue(rod2Nixie, pctInserted(0), 3);

    const lever1 = shadowRoot.getElementById('lever1');
    const lever2 = shadowRoot.getElementById('lever2');
    updateLeverVisual(lever1, 0);
    updateLeverVisual(lever2, 0);

    scopeCanvasEl = shadowRoot.getElementById('scope');
    scopeCtx = scopeCanvasEl.getContext('2d');

    const wallClockEl = shadowRoot.getElementById('wallClock');
    wallClockEl.textContent = formatModelTimeLong(state.t);

    const rod1Input = shadowRoot.getElementById('rod1Input');
    const rod2Input = shadowRoot.getElementById('rod2Input');
    on(rod1Input, 'input', (e) => {
      if (rodControlsLocked) return; // disabled уже блокирует событие в браузере, это доп. страховка
      state.rod1 = sliderToRod(+e.target.value); // v3.29 — кусочно-линейная растяжка 0..20%
      shadowRoot.getElementById('rod1Read').textContent = pctInserted(state.rod1) + '%';
      setNixieValue(rod1Nixie, pctInserted(state.rod1), 3);
      updateLeverVisual(lever1, state.rod1);
    });
    on(rod2Input, 'input', (e) => {
      if (rodControlsLocked) return;
      state.rod2 = sliderToRod(+e.target.value); // v3.29 — та же растяжка, что и у СТЕРЖНЯ I
      shadowRoot.getElementById('rod2Read').textContent = pctInserted(state.rod2) + '%';
      setNixieValue(rod2Nixie, pctInserted(state.rod2), 3);
      updateLeverVisual(lever2, state.rod2);
    });

    // v3.30 — по отзыву пользователя: даже с растяжкой рабочей зоны (v3.29)
    // попасть мышью на повёрнутом рычаге ровно в экспериментальное значение
    // (1-2%, 4% и т.п.) практически невозможно. Клик по %-показанию
    // превращает его в текстовое поле — точная установка одним вводом.
    // Единицы ввода — % ВВЕДЕНО, как и сам дисплей (согласовано с
    // пользователем), т.е. НЕ то же самое, что % выведено из исторических
    // данных урока — пересчёт 100-x при сверке с историческими значениями
    // остаётся на операторе.
    function makeRodValueEditable(readId, rodKey, nixieEl, leverEl) {
      const readEl = shadowRoot.getElementById(readId);
      readEl.classList.add('editable');
      readEl.title = 'Клик — точная установка, % введено';

      function startEdit() {
        if (rodControlsLocked) return;
        if (readEl.querySelector('input')) return; // уже редактируется

        const input = document.createElement('input');
        input.type = 'text';
        input.inputMode = 'decimal';
        input.className = 'lever-val-edit';
        input.value = (Math.round(pctInserted(state[rodKey]) * 10) / 10).toString();

        let cancelled = false;
        function finish() {
          if (!cancelled) {
            const parsed = parseFloat(input.value.replace(',', '.').trim());
            if (Number.isFinite(parsed)) {
              const pctIns = Math.max(0, Math.min(100, parsed));
              state[rodKey] = 100 - pctIns;
              shadowRoot.getElementById(readId === 'rod1Read' ? 'rod1Input' : 'rod2Input').value = rodToSlider(state[rodKey]);
              setNixieValue(nixieEl, pctInserted(state[rodKey]), 3);
              updateLeverVisual(leverEl, state[rodKey]);
            }
          }
          readEl.textContent = pctInserted(state[rodKey]) + '%';
        }
        input.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
          else if (e.key === 'Escape') { e.preventDefault(); cancelled = true; input.blur(); }
        });
        input.addEventListener('blur', finish, { once: true });

        readEl.textContent = '';
        readEl.appendChild(input);
        input.focus();
        input.select();
      }

      on(readEl, 'click', startEdit);
    }
    makeRodValueEditable('rod1Read', 'rod1', rod1Nixie, lever1);
    makeRodValueEditable('rod2Read', 'rod2', rod2Nixie, lever2);

    // v3.13 — по замечанию пользователя: вместо рычага-верёвки ZIP и
    // кнопки SCRAM под откидной крышкой — два одинаковых двухпозиционных
    // тумблера. Снятие блокировки движением стержня (было раньше) убрано —
    // теперь и постановка, и снятие А.ЗАЩИТЫ — явное действие оператора
    // тем же тумблером, а не побочный эффект другого органа управления.
    const zipToggle = shadowRoot.getElementById('zipToggle');
    on(zipToggle, 'click', () => {
      if (rodControlsLocked) return;
      state.zipOut = !state.zipOut;
      zipToggle.classList.toggle('on', state.zipOut);
      // v3.17 — ре-арм автоматического ZIP: как исторически (после обеда
      // порог подняли и запустили заново вручную), сброс "тревожного"
      // состояния — только явным включением тумблера оператором, не сам
      // по себе течением времени.
      if (state.zipOut && state.zipTripped) {
        state.zipTripped = false;
        diagnostics.log(state.t, 'info', 'Авто-ZIP взведён оператором заново — стержень выведен', 'auto-zip', buildSnapshot());
      } else {
        diagnostics.log(
          state.t,
          'info',
          state.zipOut ? 'ЗАПУСК РЕАКТОРА включён — стержень ZIP выведен, критика физически возможна' : 'ЗАПУСК РЕАКТОРА выключен — стержень ZIP введён, реактор заперт',
          'rods',
          buildSnapshot()
        );
      }
    });

    const scramToggle = shadowRoot.getElementById('scramToggle');
    on(scramToggle, 'click', () => {
      if (rodControlsLocked) return;
      if (!state.scram) {
        onScram();
      } else {
        state.scram = false;
        scramToggle.classList.remove('on');
        shadowRoot.getElementById('lampScram').classList.remove('on');
        diagnostics.log(state.t, 'info', 'Аварийная защита снята оператором, управление возвращено', 'scram', buildSnapshot());
      }
    });

    // v3.17 — слайдер порога тросового ZIP, та же лог-шкала, что у уставки
    // автомата (0..600 -> 0.001..1000). Оператор может выставить его
    // слишком низко и получить ложную сработку, как у Зинна.
    const zipThreshInput = shadowRoot.getElementById('zipThreshInput');
    const zipThreshVal = shadowRoot.getElementById('zipThreshVal');
    function applyZipThreshFromSlider() {
      const raw = Number(zipThreshInput.value);
      state.zipTripThreshold = Math.pow(10, raw / 100 - 3);
      zipThreshVal.textContent = state.zipTripThreshold < 1 ? state.zipTripThreshold.toFixed(3) : state.zipTripThreshold.toFixed(1);
    }
    on(zipThreshInput, 'input', applyZipThreshFromSlider);
    applyZipThreshFromSlider();

    // v3.16 — переключатель диапазона шунта прибора (см. AGENT_HANDOFF.md,
    // разбор графика 2 декабря 1942): чисто отображение, меняет ТОЛЬКО
    // растяжку шкалы стрелки, не физику потока. Индекс 0 — самый
    // чувствительный (высокое Ω, для малых потоков), больше индекс —
    // грубее диапазон (для больших потоков).
    const rangeVal = shadowRoot.getElementById('rangeVal');
    function applyRangeIdx(idx) {
      state.meterRangeIdx = Math.max(0, Math.min(METER_RANGES.length - 1, idx));
      rangeVal.textContent = METER_RANGES[state.meterRangeIdx].ohms;
      rebuildFluxGaugeLabels();
    }
    on(shadowRoot.getElementById('rangeUpBtn'), 'click', () => {
      if (state.meterRangeIdx > 0) {
        applyRangeIdx(state.meterRangeIdx - 1);
        diagnostics.log(state.t, 'info', `Переключение прибора на шкалу ${METER_RANGES[state.meterRangeIdx].ohms} Ω (более чувствительно)`, 'system', buildSnapshot());
      }
    });
    on(shadowRoot.getElementById('rangeDownBtn'), 'click', () => {
      if (state.meterRangeIdx < METER_RANGES.length - 1) {
        applyRangeIdx(state.meterRangeIdx + 1);
        diagnostics.log(state.t, 'info', `Переключение прибора на шкалу ${METER_RANGES[state.meterRangeIdx].ohms} Ω (менее чувствительно)`, 'system', buildSnapshot());
      }
    });
    applyRangeIdx(state.meterRangeIdx);

    // v3.17 — переключатель режима осциллографа: "развёртка" (текущее
    // скользящее окно, state.history) / "весь эксперимент" (state.fullHistory,
    // растянут по времени на всю ширину, см. drawScope()). Переиспользован
    // существующий элемент подписи #scopeSpeed (раньше был статичным текстом,
    // ни на что не влиявшим).
    const scopeSpeedEl = shadowRoot.getElementById('scopeSpeed');
    if (scopeSpeedEl) {
      scopeSpeedEl.style.cursor = 'pointer';
      scopeSpeedEl.title = 'Клик — переключить режим осциллографа';
      on(scopeSpeedEl, 'click', () => {
        state.scopeMode = state.scopeMode === 'full' ? 'sweep' : 'full';
        scopeSpeedEl.textContent = state.scopeMode === 'full' ? 'ВЕСЬ ЭКСПЕРИМЕНТ' : 'РАЗВЁРТКА: МЕДЛ.';
        diagnostics.log(
          state.t,
          'info',
          state.scopeMode === 'full' ? 'Осциллограф: показан весь эксперимент с начала' : 'Осциллограф: возврат к скользящей развёртке',
          'system',
          buildSnapshot()
        );
      });
    }

    // v3.15 — органы управления (стержни I/II, ЗАПУСК РЕАКТОРА, А.ЗАЩИТА)
    // заблокированы до нажатия «Старт», см. setRodControlsLocked()/onStart().
    setRodControlsLocked(true);

    diagnostics.log(0, 'info', 'Стенд CP-1 готов. Реактор заглушён — регулирующие стержни введены, ЗАПУСК РЕАКТОРА выключен', 'system', buildSnapshot());
    renderOwnLog();

    ControlsPanel.initRunControl(onStart, onPauseToggle);
    ControlsPanel.resetRunControl(); // у CP-1 нет отдельного Х/Г-старта — «Старт» доступен сразу
    // v3.19 — возвращено ускорение времени, но со своим потолком ×10
    // (не ×3600 от РБМК) — см. CP1_SPEED_PRESETS выше и История.md v3.18.
    // Раньше (v3.13) initSpeedControl() для CP-1 не вызывался вообще —
    // была ошибка трактовки: пользователь просил убрать только ×3600,
    // а не ускорение целиком.
    ControlsPanel.initSpeedControl((speed) => {
      simSpeed = speed;
      diagnostics.log(state.t, 'info', `Скорость моделирования: ×${speed}`, 'system', buildSnapshot());
    }, CP1_SPEED_PRESETS);

    on(document.getElementById('btn-save-state'), 'click', exportStateToJson);
    on(shadowRoot.getElementById('instructionCloseBtn'), 'click', () => {
      _instructionDismissed = true;
      renderInstructionPopup();
    });
    on(shadowRoot.getElementById('instructionReopenBtn'), 'click', () => {
      _instructionDismissed = false;
      renderInstructionPopup();
    });
    on(document.getElementById('btn-reset-scenario'), 'click', () => {
      if (!scenarioEngine.isLoaded()) return;
      scenarioEngine.resetAll();
      _instructionDismissed = false;
      _lastRenderedGoalId = null;
      diagnostics.log(state.t, 'info', 'Прогресс целей урока сброшен к началу — сам урок остался загружен', 'scenario', buildSnapshot());
    });

    lastTs = null;
    rafHandle = requestAnimationFrame(frame);
  }

  function unmount() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    rafHandle = null;
    offAll();
    lastTs = null;
    scopeCtx = null;
    scopeCanvasEl = null;
    if (shadowRoot) shadowRoot.innerHTML = '';
  }

  return {
    mount,
    unmount,
    start: () => onStart(),
    pause: () => onPauseToggle(),
    scram: () => onScram(),
    reset: () => {
      state.rod1 = 0;
      state.rod2 = 0;
      state.zipOut = false;
      state.scram = false;
      state.power = 0.001;
      state.precursor = 0;
      state.graphiteTemp = 22;
      state.meterRangeIdx = 1;
      state.zipTripThreshold = 10;
      state.zipTripped = false;
      state.fullHistory = [];
      state.scopeMode = 'sweep';
      lastFullSampleT = -Infinity;
      state.t = 0;
      state.history = [];
      applyStateToDom();
      const scopeSpeedEl = shadowRoot.getElementById('scopeSpeed');
      if (scopeSpeedEl) scopeSpeedEl.textContent = 'РАЗВЁРТКА: МЕДЛ.';
      diagnostics.log(0, 'info', 'CP-1 сброшен к исходному состоянию — реактор заглушён', 'system', buildSnapshot());
    },
    getSnapshot: () => buildSnapshot(),
    loadState: (payload, label) => applyStatePayload(payload, label || `Состояние CP-1 загружено (сохранено: ${payload.savedAt || 'неизвестно'})`),
    loadScenario: (payload) => scenarioEngine.load(payload),
    loadLesson: (payload) => {
      // v3.19 — тот же порядок, что у РБМК (см. js/reactors/rbmk/index.js):
      // сценарий проверяем первым, чтобы битый файл не трогал состояние
      // реактора.
      if (!payload || typeof payload !== 'object' || !payload.state || !payload.scenario) {
        return { ok: false, error: 'файл повреждён — отсутствует state или scenario' };
      }
      const scenarioResult = scenarioEngine.load(payload.scenario);
      if (!scenarioResult.ok) {
        return { ok: false, error: `сценарий повреждён (${scenarioResult.error}), состояние реактора не трогали` };
      }
      _instructionDismissed = false;
      _lastRenderedGoalId = null;
      document.getElementById('btn-reset-scenario').disabled = false;
      const label = `Урок загружен: «${payload.title || payload.id || 'без названия'}» — состояние и сценарий применены`;
      return applyStatePayload(payload.state, label);
    },
    isDestroyed: () => false,
  };
}
