// event_log.js
// Общее хранилище журнала событий — реактор-агностично. Раньше было частью
// DiagnosticsEngine (js/core/diagnostics.js), но та фактически была системой
// тревог РБМК (пороги/зоны читали RBMK_PARAMS и специфичные для РБМК поля
// снапшота) с попутно встроенным хранилищем. Разделено (см. AGENT_HANDOFF.md,
// рефакторинг «модуль на реактор», п.4 — уточнение границы): классификация
// тревог переехала в js/reactors/rbmk/alarms.js (RbmkAlarms), здесь остаётся
// только сам журнал — то, что действительно общее на все реакторы и должно
// пережить переключение между ними ("Лог един").

class EventLog {
  constructor() {
    this.events = []; // {t, severity: 'info'|'caution'|'alarm', text, source, snap} — кольцевой буфер для ленты в UI
    // Версия журнала — инкрементируется на КАЖДЫЙ log() и на reset(). Рендер
    // (SharedLogPanel.renderEventLog) сравнивает именно её, не events.length —
    // reset() обнуляет массив, а следующая же запись может вернуть ту же
    // ДЛИНУ (например 1), при этом содержимое единственной записи другое;
    // сравнение по length тогда ошибочно пропускало бы рендер (было найдено
    // headless-проверкой при добавлении «Загрузить урок», см. AGENT_HANDOFF.md).
    this._logVersion = 0;
    this.maxEvents = 200;

    // Полная история сессии — БЕЗ потолка, для экспорта в файл. events
    // (выше) намеренно ограничен для ленты на экране, но экспорт должен
    // отдавать всё, что реально произошло за сессию.
    this.fullHistory = [];

    // Минимальный интервал между НЕ-alarm записями — по РЕАЛЬНОМУ времени
    // (мс на часах пользователя), не по модельному: модельное время
    // масштабируется регулятором скорости (×1..×3600), и троттлинг в
    // модельных секундах на высокой скорости фактически переставал работать.
    // Alarm-события пишутся без задержки.
    this.minLogIntervalRealMs = 200;
    this._lastNonAlarmLogRealMs = -Infinity;
  }

  reset() {
    this.events = [];
    this._logVersion++;
    this.fullHistory = [];
    this._lastNonAlarmLogRealMs = -Infinity;
  }

  log(t, severity, text, source, snap) {
    if (severity !== 'alarm') {
      const nowMs = performance.now();
      if (nowMs - this._lastNonAlarmLogRealMs < this.minLogIntervalRealMs) return; // слишком часто по реальным часам — пропускаем
      this._lastNonAlarmLogRealMs = nowMs;
    }
    const entry = { t, severity, text, source, snap: snap || null };
    this.events.push(entry);
    this._logVersion++;
    if (this.events.length > this.maxEvents) this.events.shift();
    // fullHistory получает ТОТ ЖЕ объект (не копию) — троттлинг выше уже
    // отфильтровал спам, дублировать проверку не нужно; общая для
    // events/fullHistory ссылка на snap экономит память на длинных сессиях.
    this.fullHistory.push(entry);
  }
}
