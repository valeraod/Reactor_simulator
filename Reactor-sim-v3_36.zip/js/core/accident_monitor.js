// accident_monitor.js
//
// v2.3 — терминальная авария ("повреждение активной зоны"), см.
// AGENT_HANDOFF.md, "План новой физики". Не часть scenario_engine.js —
// работает ВСЕГДА, независимо от того, загружен ли сценарий (роль
// "исследователь аварий" должна действовать и в свободном режиме, см.
// обсуждение с пользователем). Чистый модуль без DOM/kinetics — принимает
// готовые булевы условия и реальные секунды, как и остальные core-модули
// (condition_lang.js/scenario_engine.js), тестируется node напрямую.
//
// РЕАЛЬНЫЕ секунды, не модельные — тот же принцип, что и в
// scenario_engine.js tick() (см. комментарий там): иначе на ×3600 авария
// "случалась" бы за долю реальной секунды, оператор физически не успел бы
// среагировать.
//
// Публичный API:
//   new AccidentMonitor(thresholds)  — thresholds: см. RBMK_PARAMS.accidentThresholds
//   tick(conditions, realDtSec) -> { triggered, reason, mostUrgent }
//     conditions: { fuelTempAlarm, overpower, promptCritical, coolantFlowRisk } — все boolean
//     mostUrgent: {key, label, remainingSec, limitSec} | null — для баннера обратного отсчёта
//   isTriggered() -> boolean
//   getReason() -> string | null
//   reset()

const CONDITION_DEFS = [
  { key: 'fuelTemp', thresholdKey: 'fuelTempAlarmSec', label: 'Топливо выше предела оболочки твэла' },
  { key: 'overpower', thresholdKey: 'overpowerSec', label: 'Мощность выше 150% N0' },
  { key: 'promptCritical', thresholdKey: 'promptCriticalSec', label: 'Промгновенная критичность (ρ > β)' },
  { key: 'coolantFlowRisk', thresholdKey: 'coolantFlowRiskSec', label: 'Риск пережога — расход теплоносителя критически низок' },
];

const CONDITION_TO_FIELD = {
  fuelTemp: 'fuelTempAlarm',
  overpower: 'overpower',
  promptCritical: 'promptCritical',
  coolantFlowRisk: 'coolantFlowRisk',
};

class AccidentMonitor {
  constructor(thresholds) {
    this.thresholds = thresholds;
    this.timers = { fuelTemp: 0, overpower: 0, promptCritical: 0, coolantFlowRisk: 0 };
    this._triggered = false;
    this._reason = null;
  }

  isTriggered() {
    return this._triggered;
  }

  getReason() {
    return this._reason;
  }

  reset() {
    this._triggered = false;
    this._reason = null;
    Object.keys(this.timers).forEach((k) => {
      this.timers[k] = 0;
    });
  }

  /**
   * @param conditions {{fuelTempAlarm:boolean, overpower:boolean, promptCritical:boolean, coolantFlowRisk:boolean}}
   * @param realDtSec {number} реальные секунды с прошлого tick()
   * @returns {{triggered:boolean, reason:string|null, mostUrgent:({key,label,remainingSec,limitSec}|null)}}
   */
  tick(conditions, realDtSec) {
    if (this._triggered) {
      return { triggered: true, reason: this._reason, mostUrgent: null };
    }
    const dt = Math.max(0, realDtSec);
    let mostUrgent = null;

    for (const def of CONDITION_DEFS) {
      const active = !!conditions[CONDITION_TO_FIELD[def.key]];
      const limitSec = this.thresholds[def.thresholdKey];
      if (active) {
        this.timers[def.key] += dt;
        if (this.timers[def.key] >= limitSec && !this._triggered) {
          this._triggered = true;
          this._reason = def.label;
        }
        const remainingSec = Math.max(0, limitSec - this.timers[def.key]);
        if (!mostUrgent || remainingSec < mostUrgent.remainingSec) {
          mostUrgent = { key: def.key, label: def.label, remainingSec, limitSec };
        }
      } else {
        this.timers[def.key] = 0;
      }
    }

    return { triggered: this._triggered, reason: this._reason, mostUrgent: this._triggered ? null : mostUrgent };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { AccidentMonitor };
}
