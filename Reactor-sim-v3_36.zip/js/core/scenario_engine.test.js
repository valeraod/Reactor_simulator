// scenario_engine.test.js — запуск: node js/core/scenario_engine.test.js
//
// v1.19: тесты переписаны под новую модель времени — tick(snapshot, dtSec)
// принимает РЕАЛЬНУЮ дельту секунд с прошлого вызова, а не абсолютное
// модельное время. load()/rebase() больше не принимают время вообще.
//
// Регрессия по плану, зафиксированному в AGENT_HANDOFF.md (v1.13, раздел
// "План тестов для будущей реализации ScenarioEngine") — 7 пунктов,
// специфичных для самого движка целей/сообщений (условия уже покрыты
// отдельно в condition_lang.test.js), плюс новый тест №8 на регрессию
// найденного пользователем бага (модельное vs реальное время).

const assert = require('assert');
const { ScenarioEngine } = require('./scenario_engine.js');

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`OK   ${name}`);
  } catch (e) {
    console.log(`FAIL ${name}`);
    console.log('     ' + e.message);
    process.exitCode = 1;
  }
}

function makeSnapshot(overrides = {}) {
  return Object.assign({
    power: 0.5,
    rhoBeta: 0.0,
    period: null,
    xenonLevel: 3.0,
    fuelTemp: 750,
    scramActive: false,
    rodGroups: [
      { id: 'group1', position: 40 },
      { id: 'group2', position: 40 },
      { id: 'group3', position: 40 },
      { id: 'usp', position: 0 },
    ],
  }, overrides);
}

function goalStateById(engine, id) {
  return engine.getGoalsState().find((g) => g.id === id);
}

// ---------------------------------------------------------------------
// 1. type:"task" откатывается, type:"exercise" — нет.
// ---------------------------------------------------------------------
test('type task: completed идёт false->true->false->true, таймер обнуляется при выходе', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's1', title: 'T1', goals: [
      {
        id: 'hold-task', title: 'x', goalText: 'x', hintText: 'x',
        type: 'task', kind: 'hold',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 }, durationSec: 10 },
      },
    ], messages: [],
  };
  const r = engine.load(scenario);
  assert.strictEqual(r.ok, true);

  engine.tick(makeSnapshot({ power: 0.6 }), 5);
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, false);
  engine.tick(makeSnapshot({ power: 0.6 }), 5); // итого 10с
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, true, 'должно завершиться после 10с подряд');

  engine.tick(makeSnapshot({ power: 0.3 }), 2);
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, false, 'task должен откатиться при потере условия');

  engine.tick(makeSnapshot({ power: 0.6 }), 3); // ещё не 10
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, false);
  engine.tick(makeSnapshot({ power: 0.6 }), 7); // итого 10 с момента возврата true
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, true, 'должен снова завершиться после нового полного интервала');
});

test('type exercise: completed остаётся true после первого попадания, не откатывается', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's2', title: 'T2', goals: [
      {
        id: 'hold-exercise', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'hold',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 }, durationSec: 10 },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.6 }), 10);
  assert.strictEqual(goalStateById(engine, 'hold-exercise').completed, true);

  engine.tick(makeSnapshot({ power: 0.1 }), 2);
  assert.strictEqual(goalStateById(engine, 'hold-exercise').completed, true, 'exercise не должен откатываться');
  engine.tick(makeSnapshot({ power: 0.0 }), 88);
  assert.strictEqual(goalStateById(engine, 'hold-exercise').completed, true, 'exercise должен остаться true навсегда');
});

// ---------------------------------------------------------------------
// 2. guarded-reach: срыв обнуляет reachedTarget, а не только failed.
// ---------------------------------------------------------------------
test('guarded-reach: forbid до цели -> цель не достигнута', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's3', title: 'T3', goals: [
      {
        id: 'gr', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'guarded-reach',
        params: {
          targetCondition: { field: 'power', op: 'gte', value: 0.8 },
          forbidCondition: { field: 'period', op: 'lt', value: 20 },
        },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.3, period: 10 }), 1);
  assert.strictEqual(goalStateById(engine, 'gr').completed, false);
  engine.tick(makeSnapshot({ power: 0.9, period: null }), 1);
  assert.strictEqual(goalStateById(engine, 'gr').completed, true, 'после снятия forbid цель должна засчитаться');
});

test('guarded-reach: срыв ПОСЛЕ успеха откатывает reachedTarget в false', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's4', title: 'T4', goals: [
      {
        id: 'gr2', title: 'x', goalText: 'x', hintText: 'x',
        type: 'task', kind: 'guarded-reach',
        params: {
          targetCondition: { field: 'power', op: 'gte', value: 0.8 },
          forbidCondition: { field: 'period', op: 'lt', value: 20 },
        },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.9, period: null }), 1);
  assert.strictEqual(goalStateById(engine, 'gr2').completed, true);
  engine.tick(makeSnapshot({ power: 0.9, period: 10 }), 1);
  assert.strictEqual(
    goalStateById(engine, 'gr2').completed,
    false,
    'reachedTarget должен откатиться в false, а не остаться true рядом с failed'
  );
});

// ---------------------------------------------------------------------
// 3. sequence: порядок transitions значим.
// ---------------------------------------------------------------------
test('sequence: при двух одновременно истинных переходах срабатывает первый по порядку', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's5', title: 'T5', goals: [
      {
        id: 'seq', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'sequence',
        params: {
          initial: 'idle',
          success: 'done-first',
          states: {
            idle: {
              transitions: [
                { if: { field: 'power', op: 'gte', value: 0.5 }, goto: 'done-first' },
                { if: { field: 'power', op: 'gte', value: 0.5 }, goto: 'done-second' },
              ],
            },
            'done-first': {},
            'done-second': {},
          },
        },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.9 }), 1);
  assert.strictEqual(goalStateById(engine, 'seq').completed, true, 'должен попасть в success (первый транзишн)');
});

// ---------------------------------------------------------------------
// 4. rebase() не трогает прогресс.
// ---------------------------------------------------------------------
test('rebase(): scenarioTimeSec пересчитан от нуля, но timerSec/completed не тронуты', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's6', title: 'T6', goals: [
      {
        id: 'hold-r', title: 'x', goalText: 'x', hintText: 'x',
        type: 'task', kind: 'hold',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 }, durationSec: 60 },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.6 }), 30);
  assert.strictEqual(goalStateById(engine, 'hold-r').completed, false);
  assert.ok(goalStateById(engine, 'hold-r').progress > 0.49 && goalStateById(engine, 'hold-r').progress < 0.51);

  engine.rebase();

  assert.ok(goalStateById(engine, 'hold-r').progress > 0.49 && goalStateById(engine, 'hold-r').progress < 0.51, 'rebase не должен трогать прогресс');

  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  const state = goalStateById(engine, 'hold-r');
  assert.ok(state.progress > 0.5 && state.progress < 0.55, `progress=${state.progress}`);
});

// ---------------------------------------------------------------------
// 5. resetGoal/resetAll изолированы друг от друга.
// ---------------------------------------------------------------------
test('resetGoal(id) не затрагивает другие цели', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's7', title: 'T7', goals: [
      {
        id: 'g1', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'reach',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 } },
      },
      {
        id: 'g2', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'reach',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 } },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.9 }), 1);
  assert.strictEqual(goalStateById(engine, 'g1').completed, true);
  assert.strictEqual(goalStateById(engine, 'g2').completed, true);

  engine.resetGoal('g1');
  assert.strictEqual(goalStateById(engine, 'g1').completed, false, 'g1 должна сброситься');
  assert.strictEqual(goalStateById(engine, 'g2').completed, true, 'g2 не должна быть затронута');
});

// ---------------------------------------------------------------------
// 6. getActiveMessages() — очередь, не повторный push.
// ---------------------------------------------------------------------
test('messages: repeat=false — сообщение отдаётся один раз, не повторяется, пока условие остаётся true', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's8', title: 'T8', goals: [], messages: [
      { id: 'm1', text: 'привет', severity: 'info', condition: { field: 'power', op: 'gte', value: 0.5 }, repeat: false },
    ],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  let msgs = engine.getActiveMessages();
  assert.strictEqual(msgs.length, 1);
  assert.strictEqual(msgs[0].id, 'm1');

  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  msgs = engine.getActiveMessages();
  assert.strictEqual(msgs.length, 0, 'не должно повторно отдаваться, пока условие остаётся true');
});

test('messages: repeat=true — отдаётся заново именно на новом переходе в true', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's9', title: 'T9', goals: [], messages: [
      { id: 'm2', text: 'внимание', severity: 'caution', condition: { field: 'xenonLevel', op: 'gte', value: 3.5 }, repeat: true },
    ],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ xenonLevel: 4.0 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 1);

  engine.tick(makeSnapshot({ xenonLevel: 4.0 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 0);

  engine.tick(makeSnapshot({ xenonLevel: 3.0 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 0);

  engine.tick(makeSnapshot({ xenonLevel: 4.0 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 1, 'repeat=true должен отдать сообщение заново на новом переходе');
});

// ---------------------------------------------------------------------
// 7. Битый файл сценария не роняет движок.
// ---------------------------------------------------------------------
test('load(): отсутствие обязательного поля -> {ok:false, error}, без исключения', () => {
  const engine = new ScenarioEngine();
  const broken = {
    id: 'broken', title: 'Broken', goals: [
      { id: 'no-type', title: 'x', goalText: 'x', hintText: 'x', kind: 'hold', params: { condition: {}, durationSec: 1 } },
    ], messages: [],
  };
  let result;
  assert.doesNotThrow(() => { result = engine.load(broken); });
  assert.strictEqual(result.ok, false);
  assert.ok(typeof result.error === 'string' && result.error.length > 0);
  assert.strictEqual(engine.isLoaded(), false, 'движок не должен считаться загруженным после неудачной валидации');
});

test('load(): не-объект целиком -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => { result = engine.load(null); });
  assert.strictEqual(result.ok, false);
  assert.doesNotThrow(() => { result = engine.load('строка, не объект'); });
  assert.strictEqual(result.ok, false);
});

// ---------------------------------------------------------------------
// НОВОЕ (v2.0): instructions[] — необязательное поле, отличающее урок
// (сценарий + явно объяснённая последовательность действий) от голого
// сценария (только состояние+цель, без instructions). См. AGENT_HANDOFF.md.
// ---------------------------------------------------------------------
test('load(): без instructions -> getMeta().instructions === []', () => {
  const engine = new ScenarioEngine();
  engine.load({ id: 's-no-instr', title: 'Без инструкций', goals: [], messages: [] });
  assert.deepStrictEqual(engine.getMeta().instructions, []);
});

test('load(): instructions — валидный массив строк -> сохраняется и отдаётся через getMeta()', () => {
  const engine = new ScenarioEngine();
  const steps = ['Шаг первый: вывести стержни группы 3 на 5%.', 'Шаг второй: удержать мощность в коридоре.'];
  const result = engine.load({ id: 's-instr', title: 'С инструкциями', goals: [], messages: [], instructions: steps });
  assert.strictEqual(result.ok, true);
  assert.deepStrictEqual(engine.getMeta().instructions, steps);
});

test('load(): instructions не массив -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => { result = engine.load({ id: 'bad', title: 'x', goals: [], messages: [], instructions: 'не массив' }); });
  assert.strictEqual(result.ok, false);
});

test('load(): instructions с пустой строкой внутри -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => { result = engine.load({ id: 'bad2', title: 'x', goals: [], messages: [], instructions: ['ok', ''] }); });
  assert.strictEqual(result.ok, false);
});

// ---------------------------------------------------------------------
// НОВОЕ (v2.0): sequentialGoals + per-goal instructions[] + авто-сообщение
// об успехе — игровой формат "одна цель за раз, у каждой своя инструкция".
// ---------------------------------------------------------------------
test('load(): без sequentialGoals -> getMeta().sequentialGoals === false (по умолчанию)', () => {
  const engine = new ScenarioEngine();
  engine.load({ id: 's-seq-default', title: 'x', goals: [], messages: [] });
  assert.strictEqual(engine.getMeta().sequentialGoals, false);
});

test('load(): sequentialGoals не boolean -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => { result = engine.load({ id: 'bad3', title: 'x', goals: [], messages: [], sequentialGoals: 'true' }); });
  assert.strictEqual(result.ok, false);
});

test('load(): goal.instructions — валидный массив строк -> отдаётся через getGoalsState()', () => {
  const engine = new ScenarioEngine();
  const steps = ['Выведите стержни группы 3.', 'Удержите мощность 30 секунд.'];
  const result = engine.load({
    id: 's-goal-instr', title: 'x', sequentialGoals: true, messages: [],
    goals: [{ id: 'g1', title: 'Цель 1', type: 'exercise', kind: 'reach', instructions: steps, params: { condition: { field: 'power', op: 'gte', value: 0.5 } } }],
  });
  assert.strictEqual(result.ok, true);
  assert.deepStrictEqual(goalStateById(engine, 'g1').instructions, steps);
});

test('load(): без goal.instructions -> getGoalsState()[].instructions === []', () => {
  const engine = new ScenarioEngine();
  engine.load({
    id: 's-goal-noinstr', title: 'x', messages: [],
    goals: [{ id: 'g1', title: 'Цель 1', type: 'exercise', kind: 'reach', params: { condition: { field: 'power', op: 'gte', value: 0.5 } } }],
  });
  assert.deepStrictEqual(goalStateById(engine, 'g1').instructions, []);
});

test('load(): goal.instructions не массив -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => {
    result = engine.load({
      id: 'bad4', title: 'x', messages: [],
      goals: [{ id: 'g1', title: 'Цель 1', type: 'exercise', kind: 'reach', instructions: 'не массив', params: { condition: { field: 'power', op: 'gte', value: 0.5 } } }],
    });
  });
  assert.strictEqual(result.ok, false);
});

test('tick(): sequentialGoals=true — при выполнении цели движок сам добавляет сообщение-подтверждение', () => {
  const engine = new ScenarioEngine();
  engine.load({
    id: 's-auto-msg', title: 'x', sequentialGoals: true, messages: [],
    goals: [{ id: 'g1', title: 'Цель раз', type: 'exercise', kind: 'reach', params: { condition: { field: 'power', op: 'gte', value: 0.5 } } }],
  });
  engine.tick(makeSnapshot({ power: 0.4 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 0, 'цель ещё не выполнена — сообщения не должно быть');

  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  const msgs = engine.getActiveMessages();
  assert.strictEqual(msgs.length, 1, 'цель выполнена именно на этом тике — должно появиться ровно одно авто-сообщение');
  assert.ok(msgs[0].text.indexOf('Цель раз') !== -1, 'текст сообщения должен упоминать название цели');

  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 0, 'повторно на том же (уже выполненном) состоянии — сообщения быть не должно');
});

test('tick(): sequentialGoals не задан (по умолчанию false) — авто-сообщений НЕТ (старое поведение не меняется)', () => {
  const engine = new ScenarioEngine();
  engine.load({
    id: 's-no-auto-msg', title: 'x', messages: [],
    goals: [{ id: 'g1', title: 'Цель раз', type: 'exercise', kind: 'reach', params: { condition: { field: 'power', op: 'gte', value: 0.5 } } }],
  });
  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 0, 'без sequentialGoals движок не должен ничего добавлять сам от себя');
});

// ---------------------------------------------------------------------
// НОВОЕ (v2.3): faults[] — аварийные триггеры сценария (расход
// теплоносителя и т.п., см. AGENT_HANDOFF.md, "План новой физики").
// ---------------------------------------------------------------------
function faultScenario(faultOverrides) {
  return {
    id: 's-fault', title: 'x', goals: [], messages: [],
    faults: [Object.assign({
      id: 'pump-trip',
      trigger: { field: 'scenarioTimeSec', op: 'gte', value: 10 },
      effect: { type: 'coolantFlowRamp', to: 0.2, durationSec: 15 },
    }, faultOverrides)],
  };
}

test('load(): валидный fault -> ok:true, getActiveFaultEffects()={} до срабатывания триггера', () => {
  const engine = new ScenarioEngine();
  const result = engine.load(faultScenario());
  assert.strictEqual(result.ok, true, result.error);
  engine.tick(makeSnapshot({}), 1, true); // scenarioTimeSec=1 < 10, триггер ещё не сработал
  assert.deepStrictEqual(engine.getActiveFaultEffects(), {});
});

test('load(): fault без id -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => { result = engine.load(faultScenario({ id: undefined })); });
  assert.strictEqual(result.ok, false);
});

test('load(): fault с недопустимым effect.type -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => {
    result = engine.load(faultScenario({ effect: { type: 'nonsense', to: 0.2, durationSec: 15 } }));
  });
  assert.strictEqual(result.ok, false);
});

test('load(): fault с effect.to вне диапазона 0..2 -> {ok:false}, без исключения', () => {
  // v2.7 — диапазон расширен до 0..2 (расход может подниматься выше
  // номинала — см. AGENT_HANDOFF.md, авария 1986), поэтому 1.5 теперь
  // ВАЛИДНО; проверяем настоящую границу — 2.5.
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => {
    result = engine.load(faultScenario({ effect: { type: 'coolantFlowRamp', to: 2.5, durationSec: 15 } }));
  });
  assert.strictEqual(result.ok, false);
});

test('load(): effect.to=1.5 (выше номинала) теперь ВАЛИДНО (v2.7)', () => {
  const engine = new ScenarioEngine();
  const result = engine.load(faultScenario({ effect: { type: 'coolantFlowRamp', to: 1.5, durationSec: 15 } }));
  assert.strictEqual(result.ok, true, result.error);
});

test('load(): fault с effect.durationSec <= 0 -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => {
    result = engine.load(faultScenario({ effect: { type: 'coolantFlowRamp', to: 0.2, durationSec: 0 } }));
  });
  assert.strictEqual(result.ok, false);
});

test('tick(): сразу после срабатывания value=1.0 (полный расход, рампа только начинается)', () => {
  const engine = new ScenarioEngine();
  engine.load(faultScenario());
  for (let i = 0; i < 10; i++) engine.tick(makeSnapshot({}), 1, true); // ровно 10с -> триггер сработал в этот же тик
  const effects = engine.getActiveFaultEffects();
  assert.ok('coolantFlowFraction' in effects, 'после срабатывания эффект должен присутствовать');
  assert.ok(Math.abs(effects.coolantFlowFraction - 1.0) < 1e-9, `ожидали ~1.0 (рампа только началась), получили ${effects.coolantFlowFraction}`);
});

test('tick(): на середине durationSec value ровно посередине между 1.0 и effect.to', () => {
  const engine = new ScenarioEngine();
  engine.load(faultScenario()); // to=0.2, durationSec=15
  for (let i = 0; i < 10; i++) engine.tick(makeSnapshot({}), 1, true); // срабатывание на t=10
  for (let i = 0; i < 7; i++) engine.tick(makeSnapshot({}), 1, true); // ещё 7.5с... используем 1с шаги, возьмём 7 (t=17, elapsed=7)
  const expected = 1 + (0.2 - 1) * (7 / 15);
  const effects = engine.getActiveFaultEffects();
  assert.ok(Math.abs(effects.coolantFlowFraction - expected) < 1e-9, `ожидали ${expected}, получили ${effects.coolantFlowFraction}`);
});

test('tick(): после durationSec value фиксируется РОВНО на effect.to (не переходит ниже)', () => {
  const engine = new ScenarioEngine();
  engine.load(faultScenario());
  for (let i = 0; i < 10; i++) engine.tick(makeSnapshot({}), 1, true); // срабатывание
  for (let i = 0; i < 100; i++) engine.tick(makeSnapshot({}), 1, true); // сильно больше durationSec=15
  const effects = engine.getActiveFaultEffects();
  assert.ok(Math.abs(effects.coolantFlowFraction - 0.2) < 1e-9, `ожидали ровно 0.2 (клампится), получили ${effects.coolantFlowFraction}`);
});

test('tick(): fault срабатывает РОВНО один раз — если условие триггера снова станет ложным, эффект не откатывается', () => {
  const engine = new ScenarioEngine();
  // Триггер по полю power (не по времени) — легко сделать условие снова ложным
  engine.load({
    id: 's-fault-oneshot', title: 'x', goals: [], messages: [],
    faults: [{ id: 'f1', trigger: { field: 'power', op: 'gte', value: 0.9 }, effect: { type: 'coolantFlowRamp', to: 0.5, durationSec: 10 } }],
  });
  engine.tick(makeSnapshot({ power: 0.95 }), 1, true); // срабатывает
  engine.tick(makeSnapshot({ power: 0.1 }), 1, true); // условие снова ложно
  const effects = engine.getActiveFaultEffects();
  assert.ok('coolantFlowFraction' in effects, 'эффект должен остаться активным после срабатывания, даже если условие триггера перестало быть истинным');
});

test('resetAll(): заново "взводит" faults — после сброса fault может сработать снова', () => {
  const engine = new ScenarioEngine();
  engine.load({
    id: 's-fault-reset', title: 'x', goals: [], messages: [],
    faults: [{ id: 'f1', trigger: { field: 'power', op: 'gte', value: 0.9 }, effect: { type: 'coolantFlowRamp', to: 0.5, durationSec: 10 } }],
  });
  engine.tick(makeSnapshot({ power: 0.95 }), 1, true);
  assert.ok('coolantFlowFraction' in engine.getActiveFaultEffects());
  engine.resetAll();
  assert.deepStrictEqual(engine.getActiveFaultEffects(), {}, 'после resetAll() fault должен быть снова не сработавшим');
});

test('resetFaults(): сбрасывает ТОЛЬКО faults, прогресс целей не трогает (в отличие от resetAll())', () => {
  const engine = new ScenarioEngine();
  engine.load({
    id: 's-fault-reset-only', title: 'x', messages: [],
    goals: [{ id: 'g1', title: 'Цель', type: 'exercise', kind: 'reach', params: { condition: { field: 'power', op: 'gte', value: 0.5 } } }],
    faults: [{ id: 'f1', trigger: { field: 'power', op: 'gte', value: 0.9 }, effect: { type: 'coolantFlowRamp', to: 0.5, durationSec: 10 } }],
  });
  engine.tick(makeSnapshot({ power: 0.95 }), 1, true); // и цель выполнена (0.95>=0.5), и fault сработал
  assert.strictEqual(goalStateById(engine, 'g1').completed, true);
  assert.ok('coolantFlowFraction' in engine.getActiveFaultEffects());

  engine.resetFaults();
  assert.deepStrictEqual(engine.getActiveFaultEffects(), {}, 'fault должен сброситься');
  assert.strictEqual(goalStateById(engine, 'g1').completed, true, 'прогресс цели НЕ должен был сброситься — это и есть отличие от resetAll()');
});

// v2.7 — coolantFlowStages: несколько последовательных ступеней (например,
// расход СНАЧАЛА растёт выше номинала, ПОТОМ падает — авария 1986 года).
test('load(): coolantFlowStages без stages -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => {
    result = engine.load(faultScenario({ effect: { type: 'coolantFlowStages', stages: [] } }));
  });
  assert.strictEqual(result.ok, false);
});

test('tick(): coolantFlowStages — первая ступень (рост выше номинала) считается ОТ 1.0', () => {
  const engine = new ScenarioEngine();
  engine.load(faultScenario({
    trigger: { field: 'scenarioTimeSec', op: 'gte', value: 0 },
    effect: { type: 'coolantFlowStages', stages: [{ to: 1.2, durationSec: 10 }, { to: 0.15, durationSec: 20 }] },
  }));
  engine.tick(makeSnapshot({}), 0, true); // триггерится с elapsed=0 (см. другие тесты faults — тот же паттерн)
  engine.tick(makeSnapshot({}), 5, true); // +5с в первую ступень (0..10)
  const expected = 1 + (1.2 - 1) * (5 / 10);
  const effects = engine.getActiveFaultEffects();
  assert.ok(Math.abs(effects.coolantFlowFraction - expected) < 1e-9, `ожидали ${expected}, получили ${effects.coolantFlowFraction}`);
});

test('tick(): coolantFlowStages — вторая ступень начинается с конца первой, а не с 1.0 заново', () => {
  const engine = new ScenarioEngine();
  engine.load(faultScenario({
    trigger: { field: 'scenarioTimeSec', op: 'gte', value: 0 },
    effect: { type: 'coolantFlowStages', stages: [{ to: 1.2, durationSec: 10 }, { to: 0.15, durationSec: 20 }] },
  }));
  engine.tick(makeSnapshot({}), 0, true); // триггерится с elapsed=0
  engine.tick(makeSnapshot({}), 10, true); // +10с -> ровно конец первой ступени -> 1.2
  engine.tick(makeSnapshot({}), 10, true); // +10с -> середина второй ступени (10..30)
  const expected = 1.2 + (0.15 - 1.2) * (10 / 20);
  const effects = engine.getActiveFaultEffects();
  assert.ok(Math.abs(effects.coolantFlowFraction - expected) < 1e-9, `ожидали ${expected} (от 1.2, не от 1.0), получили ${effects.coolantFlowFraction}`);
});

test('tick(): coolantFlowStages — после всех ступеней значение фиксируется на последнем to', () => {
  const engine = new ScenarioEngine();
  engine.load(faultScenario({
    trigger: { field: 'scenarioTimeSec', op: 'gte', value: 0 },
    effect: { type: 'coolantFlowStages', stages: [{ to: 1.2, durationSec: 10 }, { to: 0.15, durationSec: 20 }] },
  }));
  for (let i = 0; i < 10; i++) engine.tick(makeSnapshot({}), 10, true); // далеко за пределами обеих ступеней (t=100)
  const effects = engine.getActiveFaultEffects();
  assert.ok(Math.abs(effects.coolantFlowFraction - 0.15) < 1e-9, `ожидали ровно 0.15 (последняя ступень), получили ${effects.coolantFlowFraction}`);
});

test('load(): несколько faults одновременно -> getActiveFaultEffects() берёт ХУДШИЙ (наименьший) расход', () => {
  const engine = new ScenarioEngine();
  engine.load({
    id: 's-fault-multi', title: 'x', goals: [], messages: [],
    faults: [
      { id: 'f1', trigger: { field: 'scenarioTimeSec', op: 'gte', value: 0 }, effect: { type: 'coolantFlowRamp', to: 0.6, durationSec: 1 } },
      { id: 'f2', trigger: { field: 'scenarioTimeSec', op: 'gte', value: 0 }, effect: { type: 'coolantFlowRamp', to: 0.2, durationSec: 1 } },
    ],
  });
  for (let i = 0; i < 5; i++) engine.tick(makeSnapshot({}), 1, true); // оба давно завершили рампу
  const effects = engine.getActiveFaultEffects();
  assert.ok(Math.abs(effects.coolantFlowFraction - 0.2) < 1e-9, `ожидали худший вариант 0.2, получили ${effects.coolantFlowFraction}`);
});

// v2.3 — багфикс (найден при headless-проверке Х/Г-старта после аварии):
// faults[] не должны "тикать" на паузе — иначе Х/Г-старт лечит аварию лишь
// на мгновение, до следующего раза, когда время наберёт порог заново.
test('tick(): simRunning=false (пауза) — fault НЕ триггерится, даже если условие истинно', () => {
  const engine = new ScenarioEngine();
  engine.load(faultScenario({ trigger: { field: 'scenarioTimeSec', op: 'gte', value: 1 } }));
  for (let i = 0; i < 20; i++) engine.tick(makeSnapshot({}), 1, false); // 20с "прошло", но simRunning=false
  assert.deepStrictEqual(engine.getActiveFaultEffects(), {}, 'на паузе fault не должен был сработать, сколько бы времени ни "прошло"');
});

test('tick(): simRunning=false ПОСЛЕ срабатывания — рампа замирает на месте, не продолжает ползти к effect.to', () => {
  const engine = new ScenarioEngine();
  engine.load(faultScenario({ effect: { type: 'coolantFlowRamp', to: 0.2, durationSec: 10 } }));
  for (let i = 0; i < 10; i++) engine.tick(makeSnapshot({}), 1, true); // срабатывает (t=10), рампа началась
  for (let i = 0; i < 5; i++) engine.tick(makeSnapshot({}), 1, true); // 5с в рампу (из 10) -> ~0.6
  const midway = engine.getActiveFaultEffects().coolantFlowFraction;
  for (let i = 0; i < 100; i++) engine.tick(makeSnapshot({}), 1, false); // ПАУЗА — рампа не должна двигаться дальше
  const afterPause = engine.getActiveFaultEffects().coolantFlowFraction;
  assert.ok(Math.abs(midway - afterPause) < 1e-9, `на паузе рампа должна замереть: было ${midway}, стало ${afterPause}`);
});

test('tick(): goals/messages по-прежнему тикают на паузе (simRunning=false) — старое поведение НЕ затронуто', () => {
  const engine = new ScenarioEngine();
  engine.load({
    id: 's-goals-on-pause', title: 'x', messages: [],
    goals: [{ id: 'g1', title: 'x', type: 'exercise', kind: 'hold', params: { condition: { field: 'power', op: 'gte', value: 0.5 }, durationSec: 10 } }],
  });
  // simRunning=false (третий аргумент), но цель всё равно должна накапливать таймер удержания —
  // это поведение целей МЕНЯТЬ не просили, только faults.
  for (let i = 0; i < 10; i++) engine.tick(makeSnapshot({ power: 0.6 }), 1, false);
  assert.strictEqual(goalStateById(engine, 'g1').completed, true, 'цели должны тикать независимо от simRunning — это НЕ трогали');
});

// ---------------------------------------------------------------------
// 8. НОВОЕ (v1.19): hold считает по РЕАЛЬНОМУ dt, переданному в tick(), а
// не по какому-либо "модельному времени" — прямая регрессия на баг,
// найденный пользователем: при ускорении симуляции (simSpeed) 60 секунд
// МОДЕЛЬНОГО времени раньше пролетали за 1 реальную секунду. Теперь
// движок вообще не получает модельное время — только реальную дельту.
// ---------------------------------------------------------------------
test('hold: результат зависит только от суммы dt, не от модельного времени/simSpeed', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's10', title: 'T10', goals: [
      {
        id: 'hold-real', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'hold',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 }, durationSec: 60 },
      },
    ], messages: [],
  };
  engine.load(scenario);
  // 59 РЕАЛЬНЫХ секунд одним тиком (при simSpeed x60 модельное время
  // улетело бы на ~3540с за эти же 59 реальных секунд — но движок его
  // вообще не видит, только реальную дельту, поэтому цель ещё не готова)
  engine.tick(makeSnapshot({ power: 0.6 }), 59);
  assert.strictEqual(goalStateById(engine, 'hold-real').completed, false, '59 реальных секунд ещё не 60');
  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  assert.strictEqual(goalStateById(engine, 'hold-real').completed, true, 'ровно 60 реальных секунд — готово');
});

console.log(`\n${passed} тестов пройдено`);
