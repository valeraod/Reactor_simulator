// lesson_format.test.js — запуск: node js/core/lesson_format.test.js
//
// Проверяет НЕ формат на бумаге, а то, что реальные классы модели
// (PointKinetics/FastPoisons/ControlRodSystem/BurnupModel) принимают
// state, встроенный в lessons/demo-hold-and-guard.lesson.json, через свои
// настоящие loadState() без исключений — и что условия demo-сценария из
// того же файла корректно оцениваются против получившегося снапшота
// (используя уже протестированный condition_lang.js).
//
// main.js НЕ загружается и не трогается — классы модели запускаются
// headless через vm, ровно так же, как их реально проинициализировал бы
// main.js (та же последовательность конструкторов, что в реальном коде).

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const { evaluateCondition } = require('./condition_lang.js');

const ROOT = path.join(__dirname, '..', '..');
const jsBase = path.join(ROOT, 'js');

const modelFiles = [
  'reactors/rbmk/rbmk_params.js',
  'core/solver.js',
  'reactors/rbmk/kinetics.js',
  'reactors/rbmk/isotopes_params.js',
  'reactors/rbmk/isotopes.js',
  'reactors/rbmk/burnup.js',
  'reactors/rbmk/control_rods.js',
];

function loadModelClasses() {
  const sandbox = {};
  vm.createContext(sandbox);
  for (const f of modelFiles) {
    vm.runInContext(fs.readFileSync(path.join(jsBase, f), 'utf8'), sandbox, { filename: f });
  }
  return sandbox;
}

const lessonPath = path.join(ROOT, 'lessons', 'demo-hold-and-guard.lesson.json');
const lesson = JSON.parse(fs.readFileSync(lessonPath, 'utf8'));

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`OK   ${name}`);
  } catch (e) {
    console.log(`FAIL ${name}`);
    console.log('     ' + e.stack);
    process.exitCode = 1;
  }
}

test('lesson-файл содержит обязательные верхнеуровневые поля', () => {
  assert.ok(lesson.state, 'нет поля state');
  assert.ok(lesson.scenario, 'нет поля scenario');
  assert.strictEqual(typeof lesson.id, 'string');
});

test('state.kinetics грузится через настоящий PointKinetics.loadState() без исключений', () => {
  const S = loadModelClasses();
  const setup = `
    const rodSystem = new ControlRodSystem(RBMK_PARAMS);
    const fastPoisons = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power, RBMK_PARAMS.betaEff);
    const burnupModel = new BurnupModel(ISOTOPE_PARAMS.slow, () => kinetics.power, RBMK_PARAMS.betaEff);
    const designExcessReactivity = (fastPoisons.equilibrium.Xe + fastPoisons.equilibrium.Sm) * RBMK_PARAMS.betaEff;
    var kinetics = new PointKinetics(
      RBMK_PARAMS,
      () => rodSystem.getReactivity() + fastPoisons.getXenonReactivity() + fastPoisons.getSamariumReactivity() + burnupModel.getReactivity() + designExcessReactivity,
      'modern'
    );
  `;
  vm.runInContext(setup, S, { filename: 'setup.js' });
  S.__lessonState = lesson.state;
  // Реальный loadState(), не переписанный — регрессия ловит рассинхрон
  // формата, если кто-то поменяет сигнатуру loadState() и забудет про уроки.
  assert.doesNotThrow(() => {
    vm.runInContext('kinetics.loadState(__lessonState.kinetics);', S, { filename: 'apply.js' });
  });
  const power = vm.runInContext('kinetics.power', S);
  assert.ok(Math.abs(power - 1.0) < 1e-9, `ожидали n=1 (Горячий старт) после loadState, получили ${power}`);
});

test('state.isotopes/rods/burnup грузятся через настоящие loadState() без исключений', () => {
  const S = loadModelClasses();
  const setup = `
    var rodSystem = new ControlRodSystem(RBMK_PARAMS);
    var fastPoisons = new FastPoisons(ISOTOPE_PARAMS.fast, () => 1.0, RBMK_PARAMS.betaEff);
    var burnupModel = new BurnupModel(ISOTOPE_PARAMS.slow, () => 1.0, RBMK_PARAMS.betaEff);
  `;
  vm.runInContext(setup, S, { filename: 'setup.js' });
  S.__lessonState = lesson.state;
  assert.doesNotThrow(() => vm.runInContext('fastPoisons.loadState(__lessonState.isotopes);', S));
  assert.doesNotThrow(() => vm.runInContext('rodSystem.loadState(__lessonState.rods);', S));
  assert.doesNotThrow(() => vm.runInContext('burnupModel.loadState(__lessonState.burnup);', S));
  const rodPositions = vm.runInContext('rodSystem.groups.map(g => [g.id, g.position])', S);
  for (const [, pos] of rodPositions) {
    assert.strictEqual(pos, 50, 'все группы должны встать на 50% (Горячий старт)');
  }
});

test('scenario.goals[hold-50] условие ЛОЖНО сразу после загрузки (мощность 100%, не 50%)', () => {
  // Снапшот "как если бы buildSnapshot() отдал прямо сейчас" — строим вручную,
  // т.к. buildSnapshot() живёт внутри main.js (не изолирован), а для этой
  // проверки достаточно кинетической мощности, которую даёт loadState().
  const holdGoal = lesson.scenario.goals.find((g) => g.id === 'hold-50');
  assert.ok(holdGoal, 'нет цели hold-50 в сценарии урока');
  const snapshotRightAfterLoad = { power: 1.0 }; // n=1 сразу после Горячего старта
  assert.strictEqual(
    evaluateCondition(snapshotRightAfterLoad, holdGoal.params.condition),
    false,
    'при мощности 100% условие "45-55%" не должно быть истинным — иначе урок засчитывался бы сразу, без манёвра игрока'
  );
});

test('scenario.goals[hold-50] условие ИСТИННО, когда мощность реально снижена до 50%', () => {
  const holdGoal = lesson.scenario.goals.find((g) => g.id === 'hold-50');
  assert.strictEqual(evaluateCondition({ power: 0.50 }, holdGoal.params.condition), true);
});

console.log(`\n${passed} тестов пройдено`);
