// accident_monitor.test.js — запуск: node js/core/accident_monitor.test.js

const assert = require('assert');
const { AccidentMonitor } = require('./accident_monitor.js');

const THRESHOLDS = {
  fuelTempAlarmSec: 30,
  overpowerSec: 10,
  promptCriticalSec: 5,
  coolantFlowRiskSec: 15,
};

let passed = 0;
function test(name, fn) {
  try {
    fn();
    console.log(`OK   ${name}`);
    passed++;
  } catch (e) {
    console.error(`FAIL ${name}`);
    console.error(`     ${e.message}`);
    process.exitCode = 1;
  }
}

const NO_CONDITIONS = { fuelTempAlarm: false, overpower: false, promptCritical: false, coolantFlowRisk: false };

test('tick(): без активных условий — не срабатывает, mostUrgent=null', () => {
  const m = new AccidentMonitor(THRESHOLDS);
  const r = m.tick(NO_CONDITIONS, 5);
  assert.strictEqual(r.triggered, false);
  assert.strictEqual(r.mostUrgent, null);
});

test('tick(): условие активно, но времени накоплено меньше порога — не срабатывает', () => {
  const m = new AccidentMonitor(THRESHOLDS);
  const r = m.tick(Object.assign({}, NO_CONDITIONS, { overpower: true }), 9);
  assert.strictEqual(r.triggered, false);
  assert.ok(r.mostUrgent, 'при активном условии mostUrgent должен быть не null');
  assert.strictEqual(r.mostUrgent.key, 'overpower');
  assert.ok(Math.abs(r.mostUrgent.remainingSec - 1) < 1e-9, `ожидали remainingSec=1 (10-9), получили ${r.mostUrgent.remainingSec}`);
});

test('tick(): накопленное время достигло порога — срабатывает, reason соответствует условию', () => {
  const m = new AccidentMonitor(THRESHOLDS);
  m.tick(Object.assign({}, NO_CONDITIONS, { overpower: true }), 9);
  const r = m.tick(Object.assign({}, NO_CONDITIONS, { overpower: true }), 1); // итого 10с = порог
  assert.strictEqual(r.triggered, true);
  assert.ok(r.reason.indexOf('150%') !== -1, `reason должен упоминать мощность/150%, получили: ${r.reason}`);
  assert.strictEqual(m.isTriggered(), true);
});

test('tick(): условие пропадает ДО достижения порога — таймер сбрасывается, не срабатывает', () => {
  const m = new AccidentMonitor(THRESHOLDS);
  m.tick(Object.assign({}, NO_CONDITIONS, { overpower: true }), 9); // почти дошли (9 из 10)
  m.tick(NO_CONDITIONS, 100); // условие исчезло — сброс
  const r = m.tick(Object.assign({}, NO_CONDITIONS, { overpower: true }), 9); // снова с нуля
  assert.strictEqual(r.triggered, false, 'таймер должен был сброситься, а не продолжить копить с прошлого раза');
});

test('tick(): 4 условия независимы друг от друга — активность одного не двигает таймер другого', () => {
  const m = new AccidentMonitor(THRESHOLDS);
  // 20с fuelTempAlarm (меньше его собственного порога 30с — само по себе НЕ должно сработать)
  m.tick({ fuelTempAlarm: true, overpower: false, promptCritical: false, coolantFlowRisk: false }, 20);
  // переключаемся на overpower — если бы таймеры не были независимы, overpower мог бы
  // "унаследовать" накопленные 20с и сработать почти сразу (порог всего 10с)
  const r = m.tick({ fuelTempAlarm: false, overpower: true, promptCritical: false, coolantFlowRisk: false }, 9);
  assert.strictEqual(r.triggered, false, 'overpower не должен был "одолжить" накопленное время у fuelTempAlarm');
  assert.ok(Math.abs(r.mostUrgent.remainingSec - 1) < 1e-9, `overpower должен считать честно с нуля (9 из 10), получили remainingSec=${r.mostUrgent.remainingSec}`);
});

test('tick(): после срабатывания — состояние фиксируется навсегда (последующие tick() не сбрасывают)', () => {
  const m = new AccidentMonitor(THRESHOLDS);
  m.tick(Object.assign({}, NO_CONDITIONS, { promptCritical: true }), 5); // ровно порог (5с)
  assert.strictEqual(m.isTriggered(), true);
  const r = m.tick(NO_CONDITIONS, 1); // условие уже неактивно, но авария не отменяется
  assert.strictEqual(r.triggered, true, 'авария необратима — не должна сбрасываться, даже если условие пропало');
  assert.strictEqual(m.getReason() !== null, true);
});

test('tick(): mostUrgent выбирает условие с наименьшим оставшимся временем среди активных', () => {
  const m = new AccidentMonitor(THRESHOLDS);
  // overpower: осталось 10-8=2с; coolantFlowRisk: осталось 15-8=7с -> overpower ближе
  const r = m.tick({ fuelTempAlarm: false, overpower: true, promptCritical: false, coolantFlowRisk: true }, 8);
  assert.strictEqual(r.mostUrgent.key, 'overpower', `ожидали overpower как самый срочный, получили ${r.mostUrgent.key}`);
});

test('reset(): полностью обнуляет таймеры и снятие флага triggered (для Х/Г-старта)', () => {
  const m = new AccidentMonitor(THRESHOLDS);
  m.tick(Object.assign({}, NO_CONDITIONS, { promptCritical: true }), 5);
  assert.strictEqual(m.isTriggered(), true);
  m.reset();
  assert.strictEqual(m.isTriggered(), false);
  assert.strictEqual(m.getReason(), null);
  const r = m.tick(Object.assign({}, NO_CONDITIONS, { promptCritical: true }), 1);
  assert.strictEqual(r.triggered, false, 'после reset() таймер должен снова копить с нуля');
});

test('tick(): реальные секунды — при "х3600" ничего специального не происходит, если вызывающий код передаёт честные realDtSec (не масштабированные)', () => {
  // Модуль ничего не знает про simSpeed — это ответственность main.js
  // (передавать РЕАЛЬНЫЕ, не масштабированные секунды). Тест документирует
  // этот контракт: 1 реальная секунда — это 1 реальная секунда для таймера,
  // независимо от того, сколько модельного времени она "стоит".
  const m = new AccidentMonitor(THRESHOLDS);
  const r = m.tick(Object.assign({}, NO_CONDITIONS, { coolantFlowRisk: true }), 1);
  assert.ok(Math.abs(r.mostUrgent.remainingSec - 14) < 1e-9);
});

console.log(`\n${passed} тестов пройдено`);
