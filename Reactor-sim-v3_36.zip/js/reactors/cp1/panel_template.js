// panel_template.js (CP-1)
// Разметка панели Chicago Pile-1 — перенесена из
// mockups/cp1-steampunk-panel.html (v3.9, подшаг C плана «CP-1 + Shadow
// DOM», см. AGENT_HANDOFF.md). Отличия от макета:
//  - Панель журнала (`.log-panel`/`#log`) — РАЗМЕТКА и СТИЛЬ те же, что в
//    макете (v3.9 их убирал в пользу общего журнала снаружи Shadow DOM —
//    пользователь указал, что это ошибка: у CP-1 свой дизайн, журнал
//    должен быть частью панели, см. AGENT_HANDOFF.md v3.12). ДАННЫЕ
//    по-прежнему общие (общий EventLog оркестратора, «Лог един»), просто
//    рендерятся здесь собственным кодом (см. renderOwnLog() в index.js),
//    а не общим SharedLogPanel.
//  - Обёрнуто в `.cp1-page` (фон/паддинг, которые в макете были на
//    `<body>` — здесь такого элемента нет, см. css/cp1-panel.css).
//  - Собственные табло-лампы (Крит./Подкрит./АВАРИЯ) ОСТАВЛЕНЫ как есть
//    (не переведены на общий annunciator-grid РБМК) — у них совсем другая
//    визуальная природа (физические лампы, не плитки), общий компонент их
//    бы визуально обеднил. Общий annunciator-grid при активном CP-1
//    остаётся скрытым вместе со всей левой колонкой РБМК.
//  - v3.13 (по отзыву пользователя, читавшего Википедию про CP-1 и
//    исторический график): рычаг ZIP (верёвка+груз) и кнопка SCRAM под
//    откидной крышкой заменены на два одинаковых двухпозиционных тумблера
//    "ЗАПУСК РЕАКТОРА" / "А.ЗАЩИТА" — были "странно и непонятно нарисованы".
//    Лампа "Топор наготове" убрана (не несла понятного смысла), "Авар.
//    останов" переименована в "АВАРИЯ". Осциллограф стал прямоугольным
//    (был странной линзообразной формы из-за border-radius:50%/18%).
//    v3.26 — слайдер уставки автоматического стержня (setpointInput) и
//    вторая стрелка "НОМИНАЛ" убраны вместе с самим авторегулятором (см.
//    index.js, AGENT_HANDOFF.md v3.26) — остался только слайдер порога
//    тросового ZIP (тот же .setpoint-row/.setpoint-slider CSS, теперь
//    единственный жилец этого блока).
//    Правый прибор переименован "Запас реактивности (ich)" → "Период
//    разгона, с" (реактивность в центах/долларах — терминология из более
//    позднего времени, в 1942-м не существовала; период — то, что Ферми
//    реально считал по ходу эксперимента).

const CP1_TEMPLATE_MAIN = `
<div class="cp1-page">
<div class="console">
  <div class="rivet" style="top:14px;left:14px;"></div>
  <div class="rivet" style="top:14px;right:14px;"></div>
  <div class="rivet" style="bottom:14px;left:14px;"></div>
  <div class="rivet" style="bottom:14px;right:14px;"></div>

  <!-- v3.19 — указания оператору по уроку "повтор эксперимента 2 дек.
       1942" (CP1_HISTORICAL_OVERLAY + lessons/cp1-historical-run.lesson.json).
       Приколотая записка поверх панели, в стиле бумажного журнала
       наблюдений (см. .log-panel ниже) — не отдельное окно браузера
       (canvas/DOM ограничены панелью), но по смыслу и поведению это
       именно всплывающее указание: появляется само по мере хода урока,
       не завязано на то, насколько точно оператор повторяет историю
       (см. История.md, обсуждение v3.18→v3.19). Скрыта, пока урок не
       загружен (см. renderInstructionPopup() в index.js). -->
  <div class="instruction-popup" id="instructionPopup" hidden>
    <div class="instruction-popup-header">
      <span class="instruction-popup-count" id="instructionCount"></span>
      <button type="button" class="instruction-popup-close" id="instructionCloseBtn" title="Свернуть указания">×</button>
    </div>
    <div class="instruction-popup-title" id="instructionTitle"></div>
    <div class="instruction-popup-text" id="instructionText"></div>
    <div class="instruction-popup-hint" id="instructionHint"></div>
  </div>
  <button type="button" class="instruction-reopen" id="instructionReopenBtn" hidden title="Показать указания урока">📜 Указания</button>

  <div class="nameplate">
    <div class="nameplate-clock" id="wallClock">0 00:00:00</div>
    <div class="sub">Chicago Pile-1 · Stagg Field · 2 декабря 1942 · Учебный стенд</div>
  </div>

  <!-- top row: round gauges + scope -->
  <div class="row top">
    <div class="panel-block gauge-wrap">
      <div class="gauge">
        <div class="gauge-face" id="gaugeFlux"></div>
      </div>
      <div class="label-tag">Нейтронный поток (log)</div>
      <div class="range-switch-row">
        <button type="button" class="range-btn" id="rangeDownBtn" title="Менее чувствительный диапазон">«</button>
        <span class="range-label">ШУНТ <span id="rangeVal">10¹⁰</span> Ω</span>
        <button type="button" class="range-btn" id="rangeUpBtn" title="Более чувствительный диапазон">»</button>
      </div>
      <!-- v3.17 — по историческому эпизоду 2 декабря 1942 (ложное срабатывание
           ZIP до обеда — порог у Зинна был выставлен слишком низко). Отдельный
           слайдер: порог тросового ZIP-стержня, регулируется оператором,
           поэтому его можно (сознательно или по ошибке) выставить слишком
           низко — см. AGENT_HANDOFF.md. -->
      <div class="setpoint-row">
        <span class="setpoint-label">ПОРОГ ZIP, <span id="zipThreshVal">10.0</span></span>
        <input type="range" class="setpoint-slider" id="zipThreshInput" min="0" max="600" value="400">
      </div>
    </div>

    <div class="panel-block scope-wrap">
      <div class="scope-bezel">
        <div class="scope-glass"><canvas id="scope" width="640" height="200"></canvas></div>
        <div class="scope-caption"><span>Осциллограф мощности</span><span id="scopeSpeed">РАЗВЁРТКА: МЕДЛ.</span></div>
      </div>
    </div>

    <div class="panel-block gauge-wrap">
      <div class="gauge">
        <div class="gauge-face" id="gaugeReact"></div>
      </div>
      <div class="label-tag">Период разгона, с</div>
    </div>
  </div>

  <!-- indicators (left column, top) + compact lamp block (left column, bottom) + control panel (right column) -->
  <div class="row" style="display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr); align-items:stretch;">
    <div style="display:flex; flex-direction:column; gap:16px;">

      <div class="row" style="margin-bottom:0;">
        <div class="panel-block nixie-wrap">
          <div class="nixie-group" id="rod1Nixie"></div>
          <div class="nx-readout-label">Стержень I, % введён</div>
        </div>

        <div class="panel-block nixie-wrap">
          <div class="nixie-group" id="rod2Nixie"></div>
          <div class="nx-readout-label">Стержень II, % введён</div>
        </div>

        <div class="panel-block nixie-wrap">
          <div class="nixie-group" id="tempNixie"></div>
          <div class="nx-readout-label">Темп. графита, °C</div>
        </div>
      </div>

      <div class="row" style="margin-bottom:0;">
        <div class="panel-block" style="flex:1; padding:14px 16px;">
          <div class="lamp-row compact">
            <div class="lamp-item"><div class="lamp on green" id="lampCrit"></div><div class="label-tag">Крит.</div></div>
            <div class="lamp-item"><div class="lamp on amber" id="lampSub"></div><div class="label-tag">Подкрит.</div></div>
            <div class="lamp-item"><div class="lamp on amber" id="lampZipTrip"></div><div class="label-tag">Авто-ZIP</div></div>
            <div class="lamp-item"><div class="lamp on red" id="lampScram"></div><div class="label-tag">АВАРИЯ</div></div>
          </div>
        </div>
      </div>

    </div>

    <div class="panel-block" style="overflow-x:auto;">
      <div class="lever-panel">
        <div class="regulators-group">
          <div class="lever-unit">
            <div class="lever-track">
              <div class="lever-slot"></div>
              <div class="lever-handle" id="lever1"></div>
              <input class="lever-input" type="range" min="0" max="100" step="0.1" value="0" id="rod1Input">
            </div>
            <div class="lever-val" id="rod1Read">100%</div>
            <div class="label-tag">Регулир. стержень I</div>
          </div>
          <div class="lever-unit">
            <div class="lever-track">
              <div class="lever-slot"></div>
              <div class="lever-handle" id="lever2"></div>
              <input class="lever-input" type="range" min="0" max="100" step="0.1" value="0" id="rod2Input">
            </div>
            <div class="lever-val" id="rod2Read">100%</div>
            <div class="label-tag">Регулир. стержень II</div>
          </div>
        </div>

        <div class="emergency-group">
          <div class="toggle-unit">
            <div class="toggle-switch" id="zipToggle">
              <div class="toggle-tag on-tag">ВКЛ</div>
              <div class="toggle-slot"></div>
              <div class="toggle-handle"></div>
              <div class="toggle-tag off-tag">ВЫКЛ</div>
            </div>
            <div class="toggle-caption">ЗАПУСК<br>РЕАКТОРА</div>
          </div>

          <div class="toggle-unit">
            <div class="toggle-switch danger" id="scramToggle">
              <div class="toggle-tag on-tag">ВКЛ</div>
              <div class="toggle-slot"></div>
              <div class="toggle-handle"></div>
              <div class="toggle-tag off-tag">ВЫКЛ</div>
            </div>
            <div class="toggle-caption">А.ЗАЩИТА</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Журнал наблюдений — часть родного дизайна CP-1 (не общий журнал
       снаружи Shadow DOM, см. AGENT_HANDOFF.md v3.12: пользователь указал,
       что вынос журнала за пределы панели был ошибкой — у CP-1 свой
       дизайн). Данные всё ещё общие (общий EventLog, "Лог един"), но
       рендерятся здесь собственным кодом CP-1 в родном стиле макета
       (состаренная бумага, "Т+####с"), см. renderOwnLog() в index.js. -->
  <div class="row" style="margin-bottom:0;">
    <div class="panel-block" style="flex:1;">
      <div class="label-tag" style="text-align:left; margin-bottom:8px;">Журнал наблюдений</div>
      <div class="log-panel" id="log"></div>
    </div>
  </div>

  <div class="note">Макет панели · упрощённая точечная кинетика для демонстрации · не является точной моделью CP-1</div>
</div>
</div>
`;
