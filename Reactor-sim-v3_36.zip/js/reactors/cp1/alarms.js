// alarms.js (CP-1)
// Классификация тревог CP-1 — по аналогии с js/reactors/rbmk/alarms.js
// (тот же паттерн: пишет в общий EventLog через инжектированную ссылку),
// но сильно проще — физика CP-1 (js/reactors/cp1/index.js) сама учебная и
// без ксенона/доплера/термогидравлики, поэтому и тревог меньше. Повторяет
// события, которые логировал исходный макет (mockups/cp1-steampunk-panel.html)
// впрямую внутри обработчиков — здесь вынесены в edge-trigger метод
// evaluate(), а разовые события (щелчок ZIP/SCRAM) по-прежнему логируются
// напрямую в месте действия (см. index.js) — это не постоянные состояния,
// а мгновенные события, edge-trigger для них не нужен.

class Cp1Alarms {
  constructor(eventLog) {
    this.eventLog = eventLog;
    this._prevPowerHigh = false;
  }

  reset() {
    this._prevPowerHigh = false;
  }

  /**
   * @param {number} t - модельное время, с
   * @param {object} state - снимок состояния CP-1 (см. buildSnapshot() в index.js)
   */
  evaluate(t, state) {
    const powerHigh = state.power > 120;
    if (powerHigh && !this._prevPowerHigh) {
      this.eventLog.log(t, 'caution', 'Внимание: мощность превышает 120% номинала', 'power', state);
    }
    this._prevPowerHigh = powerHigh;
  }
}
