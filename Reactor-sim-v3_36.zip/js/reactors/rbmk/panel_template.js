// panel_template.js
// Разметка панели РБМК — вынесена из index.html (v3.8, Shadow DOM, план
// п.6, см. AGENT_HANDOFF.md). Рендерится reactor-модулем в mount() в
// четыре shadow root'а, каждый приклеен к своему слоту-якорю в общем
// index.html (`.shadow-slot`, display:contents — см. css/style.css):
//   #slot-core-readouts  -> RBMK_TEMPLATE_CORE_READOUTS  (внутри left-col)
//   #slot-console-main   -> RBMK_TEMPLATE_CONSOLE_MAIN   (внутри .console)
//   #slot-console-side   -> RBMK_TEMPLATE_CONSOLE_SIDE   (внутри .console-diagnostics)
//   #slot-console-thermal-> RBMK_TEMPLATE_THERMAL        (внутри .console-thermal)
//
// Содержимое — 1:1 копия того, что раньше было статикой в index.html,
// кроме одного отличия: панель "Активная зона · СУЗ" разделена на две —
// аннунциатор (annunciator-grid) остался в общей шапке (index.html,
// вне Shadow DOM — общий на все реакторы), а core-readouts получил
// собственную панель "Показания активной зоны" здесь (согласовано
// отдельно — см. AGENT_HANDOFF.md).

const RBMK_TEMPLATE_CORE_READOUTS = `
<div class="panel">
  <p class="panel-label">Показания активной зоны</p>
  <div class="core-readouts" id="core-readouts">
    <!-- заполняется dashboard.js: ЖК-табло Xe/Sm/ОЗР/перекосы -->
  </div>
</div>
`;

const RBMK_TEMPLATE_CONSOLE_MAIN = `
<div class="panel">
  <p class="panel-label">Параметры реактора</p>

  <div class="gauge-wrap">
    <svg viewBox="0 0 240 140" width="260" height="152">
      <defs>
        <filter id="needleGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2.2" result="blur"/>
          <feMerge>
            <feMergeNode in="blur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>

      <path d="M20,120 A100,100 0 0,1 170,33.4" fill="none" stroke="#1f7a4d" stroke-width="10" />
      <path d="M170,33.4 A100,100 0 0,1 200.9,61.22" fill="none" stroke="#a8710a" stroke-width="10" />
      <path d="M200.9,61.22 A100,100 0 0,1 220,120" fill="none" stroke="#8a1f18" stroke-width="10" />

      <text x="45" y="124" fill="#9aa4ad" font-size="11" font-family="ui-monospace, monospace" text-anchor="middle">0</text>
      <text x="82.5" y="59" fill="#9aa4ad" font-size="11" font-family="ui-monospace, monospace" text-anchor="middle">50</text>
      <text x="157.5" y="59" fill="#9aa4ad" font-size="11" font-family="ui-monospace, monospace" text-anchor="middle">100</text>
      <text x="195" y="124" fill="#9aa4ad" font-size="11" font-family="ui-monospace, monospace" text-anchor="middle">150</text>

      <line id="gauge-needle" x1="120" y1="120" x2="20" y2="120"
            stroke="#35e08a" stroke-width="3.5" stroke-linecap="round"
            filter="url(#needleGlow)" />
      <circle cx="120" cy="120" r="7" fill="#23282d" stroke="#3a4147" stroke-width="1.5"/>
    </svg>

    <div class="gauge-readout">
      <div class="readout">
        <span class="readout-label">% N0</span>
        <div class="lcd-screen">
          <span class="lcd-value" id="readout-power-pct">100.0</span>
          <span class="lcd-trend" id="trend-power-pct">&#8213;</span>
        </div>
      </div>
      <div class="readout">
        <span class="readout-label">МВт</span>
        <div class="lcd-screen">
          <span class="lcd-value" id="readout-power-mwt">3200</span>
          <span class="lcd-trend" id="trend-power-mwt">&#8213;</span>
        </div>
      </div>
      <div class="readout">
        <span class="readout-label no-caps">ρ, β</span>
        <div class="lcd-screen">
          <span class="lcd-value" id="readout-reactivity">0.00</span>
          <span class="lcd-trend" id="trend-reactivity">&#8213;</span>
        </div>
      </div>
      <div class="readout">
        <span class="readout-label">период, с</span>
        <div class="lcd-screen">
          <span class="lcd-value" id="readout-period">∞</span>
          <span class="lcd-trend" id="trend-period">&#8213;</span>
        </div>
      </div>
    </div>

    <div class="gauge-readout gauge-readout-secondary" id="gauge-readout-secondary"></div>
  </div>

  <div class="chart-wrap">
    <canvas id="power-chart" width="560" height="100"></canvas>
  </div>

  <p class="panel-label" style="margin-top:16px;">Уровни Xe-135 / Pm-149 / Sm-149 (<span class="no-caps">β</span>-экв.)</p>
  <div class="chart-row">
    <div class="chart-wrap">
      <canvas id="poison-chart" width="560" height="100"></canvas>
    </div>
    <div class="chart-legend">
      <span class="legend-item"><span class="swatch swatch-xe"></span>Xe-135</span>
      <span class="legend-item"><span class="swatch swatch-pm"></span>Pm-149</span>
      <span class="legend-item"><span class="swatch swatch-sm"></span>Sm-149</span>
    </div>
  </div>

  <p class="panel-label" style="margin-top:16px;">Доплер ρ / Паровой ρ (<span class="no-caps">β</span>)</p>
  <div class="chart-row">
    <div class="chart-wrap">
      <canvas id="doppler-void-chart" width="560" height="100"></canvas>
    </div>
    <div class="chart-legend">
      <span class="legend-item"><span class="swatch swatch-doppler"></span>Доплер ρ</span>
      <span class="legend-item"><span class="swatch swatch-voidrho"></span>Паровой ρ</span>
    </div>
  </div>
</div>

<div class="panel">
  <p class="panel-label">Управление СУЗ</p>

  <div class="mnemonic-wrap" id="core-mnemonic">
    <div class="core-svg-cell core-frame">
      <svg id="core-svg" viewBox="0 0 300 300" width="240" height="240"></svg>
    </div>
    <div class="vgauge-cell core-frame">
      <svg id="vgauge-svg" viewBox="0 0 28 300" width="22" height="240"></svg>
    </div>
    <div class="hgauge-cell core-frame">
      <svg id="hgauge-svg" viewBox="0 0 300 28" width="240" height="22"></svg>
    </div>
  </div>
  <div class="mnemonic-legend">
    <span>◧ Верх = Г1/2/3 (сверху)</span>
    <span>◨ Низ = УСП (снизу)</span>
  </div>

  <div class="rod-bank" id="rod-bank">
    <!-- заполняется dashboard.js -->
  </div>

  <button class="btn btn-scram" id="btn-scram">АЗ-5 · Аварийная защита</button>
  <button class="btn btn-release-scram" id="btn-release-scram" disabled>Снять блокировку АЗ-5</button>
  <button class="btn btn-reset" id="btn-hot-start" title="Реактор уже работает: 100% мощности, стержни 50%, Xe/Sm в равновесии, топливо горячее">Горячий старт</button>
  <button class="btn btn-reset" id="btn-cold-start" title="Реактор никогда не работал: стержни введены, Xe/Sm=0, топливо холодное (270°C — контур уже на рабочей температуре, разогрев с нуля не моделируется) — нужно вручную вывести стержни и разогнать реактор с нуля">Холодный старт</button>

  <div class="status-line" id="status-line"></div>
</div>
`;

const RBMK_TEMPLATE_CONSOLE_SIDE = `
<div class="right-col">
  <div class="panel panel-collapsible panel-inactive" id="scenario-panel-wrap">
    <details id="scenario-details">
      <summary class="panel-summary panel-label">
        <span>Сценарий<span class="panel-state-tag" id="scenario-state-tag">не загружен</span></span>
      </summary>
      <div class="panel-collapsible-body">
        <div id="scenario-title" class="scenario-title">Сценарий не загружен</div>
        <div id="scenario-goals" class="scenario-goals"></div>
      </div>
    </details>
  </div>

  <div class="panel panel-collapsible">
    <details id="burnup-details">
      <summary class="panel-summary panel-label">Топливная кампания</summary>
      <div class="panel-collapsible-body">
        <p class="panel-label-row" style="margin:0 0 12px 0; padding:0; border:none;">
          <span></span>
          <span class="info-icon" tabindex="0">?
            <span class="info-tooltip">
              <strong>Фикс. возраст</strong> — наработка топлива не меняется во время сессии, задаётся вручную кнопками ниже.<br><br>
              <strong>Ускор. кампания</strong> — наработка растёт сама, пропорционально мощности реактора (и скорости моделирования).<br><br>
              <strong>Свежее / Середина / Конец</strong> — пресеты возраста топлива (доступны только в режиме «Фикс. возраст»): мгновенно переключают наработку на 0 / середину / конец типовой кампании. Активный пресет подсвечен.
            </span>
          </span>
        </p>
        <div id="burnup-controls"></div>
        <div class="composition-bar" id="composition-bar"></div>
        <div class="composition-legend" id="composition-legend"></div>
      </div>
    </details>
  </div>
</div>
`;

const RBMK_TEMPLATE_THERMAL = `
<div class="panel">
  <p class="panel-label">Термогидравлика (топливо ↔ теплоноситель)</p>
  <div class="thermal-readouts" id="thermal-readouts"></div>
  <div class="chart-wrap">
    <canvas id="thermal-chart" width="560" height="100"></canvas>
  </div>
  <div class="chart-legend">
    <span class="legend-item"><span class="swatch swatch-tfuel"></span>T топлива, °C</span>
  </div>
  <div class="void-gauge-wrap">
    <label>Паросодержание α</label>
    <div class="void-gauge"><div class="void-gauge-fill" id="void-gauge-fill"></div></div>
    <span class="val" id="void-gauge-val">0%</span>
  </div>
</div>
`;
