// js/reactors/rbmk/index.js
// РБМК-1000 — реактор-модуль (фабрика createRbmkReactor()).
//
// v3.6 — извлечено из main.js в рамках рефакторинга "модуль на реактор без
// общих импортов" (см. AGENT_HANDOFF.md, согласованный план, пункты 1-7).
// Логика физики/оркестрации перенесена почти без изменений по сравнению со
// старым main.js. Отличия, специально внесённые этим переносом:
//  - ФАБРИКА (createRbmkReactor()), не самозапускающийся IIFE — состояние
//    инстанс-локальное (в замыкании фабрики), не модуль-уровневые let, как
//    было в main.js. Согласовано явно ("сразу фабрика, надёжнее") — каждый
//    mount() строит физику заново "с нуля", не полагаясь на полноту reset().
//  - diagnostics (журнал) БОЛЬШЕ НЕ создаётся здесь — общий на все реакторы,
//    переживает переключение реакторов, инжектируется оркестратором через
//    mount(container, {logger}).
//  - Реализует контракт: mount(container, {logger}) / unmount() / start() /
//    pause() / scram() / reset(mode) / getSnapshot() / loadState(payload) /
//    loadScenario(payload).
//  - scenarioEngine/accidentMonitor — код общий (js/core/scenario_engine.js,
//    js/core/accident_monitor.js), но ИНСТАНС свой на каждый mount() —
//    интерпретатор один на всех реакторов, состояние — нет (см. обсуждение
//    в AGENT_HANDOFF.md: "интерпретатор остаётся один общий").
//  - Dashboard/ControlsPanel — БЕЗ изменений, по-прежнему глобальные объекты,
//    вызываются как раньше. Shadow DOM/изоляция вёрстки — ОТДЕЛЬНЫЙ шаг
//    плана (п.3, п.6), в этот перенос сознательно не входит.
//  - Дропдаун выбора реактора (ControlsPanel.initReactorSelect) СЮДА не
//    переехал — переключение реакторов теперь дело оркестратора (main.js),
//    который вызывает unmount() текущего модуля и mount() нового.

function createRbmkReactor() {
  // --- инстанс-состояние: пусто до mount(), заполняется там же ---
  let rodSystem, fastPoisons, burnupModel;
  let fastPoisonsTop, fastPoisonsBottom, fastPoisonsLeft, fastPoisonsRight;
  let kinetics, diagnostics, alarms, scenarioEngine, accidentMonitor;
  let designExcessReactivity = 0;
  let reactorDestroyed = false;
  let simRunning = false; // физика не шагает до нажатия "Старт"
  let simSpeed = 1;
  let speedLocked = false; // защита от разбалансировки на невнимательности
  let rodControlsLocked = true;
  let reactorTimerEl = null;
  let lastTs = null;
  let rafHandle = null;

  // Debounce записей "оператор установил X%" — см. пояснение у onRodChange().
  const ROD_LOG_DEBOUNCE_MS = 1200;
  let _rodChangePending = {}; // id -> { fromPct, toPct, lastChangeRealMs }
  let _lastLoggedRodPosition = {};

  // DOM-слушатели, навешанные в mount() — снимаются в unmount(), чтобы
  // повторный mount() (после переключения реактора и обратно) не плодил
  // дубликаты обработчиков на тех же элементах шапки/меню.
  let _boundListeners = [];
  function on(el, type, fn) {
    if (!el) return;
    el.addEventListener(type, fn);
    _boundListeners.push({ el, type, fn });
  }
  function offAll() {
    _boundListeners.forEach(({ el, type, fn }) => el.removeEventListener(type, fn));
    _boundListeners = [];
  }

  /** Штрафная поправка к ρ от перекоса ксенона верх/низ (см. старый main.js, без изменений). */
  function zoneImbalanceReactivity() {
    const dXe = fastPoisonsTop.xenonLevel - fastPoisonsBottom.xenonLevel;
    return -RBMK_PARAMS.spatial.zoneImbalancePenaltyBeta * dXe * dXe * RBMK_PARAMS.betaEff;
  }

  /** То же самое для оси лево/право (v2.5, без изменений). */
  function azimuthImbalanceReactivity() {
    const dXe = fastPoisonsLeft.xenonLevel - fastPoisonsRight.xenonLevel;
    return -RBMK_PARAMS.spatial.azimuthImbalancePenaltyBeta * dXe * dXe * RBMK_PARAMS.betaEff;
  }

  function buildSnapshot() {
    const rhoExternal =
      rodSystem.getReactivity() +
      fastPoisons.getXenonReactivity() +
      fastPoisons.getSamariumReactivity() +
      burnupModel.getReactivity() +
      designExcessReactivity +
      zoneImbalanceReactivity();
    const dopplerBeta = kinetics.dopplerReactivityBeta;
    const voidBeta = kinetics.voidReactivityBeta;
    const rhoAbs = rhoExternal + (dopplerBeta + voidBeta) * rodSystem.betaTotal;
    const zoneFrac = rodSystem.getZonePowerFractions();
    const azimuthFrac = rodSystem.getAzimuthPowerFractions();
    return {
      t: kinetics.t,
      power: kinetics.power,
      rhoAbs,
      rhoBeta: rhoAbs / rodSystem.betaTotal,
      period: kinetics.period,
      rodGroups: rodSystem.groups.map((g) => ({ id: g.id, label: g.label, position: g.position })),
      scramActive: rodSystem.scramActive,
      scramComplete: rodSystem.isFullyInserted(),
      xenonLevel: fastPoisons.xenonLevel,
      promethiumLevel: fastPoisons.promethiumLevel,
      samariumLevel: fastPoisons.samariumLevel,
      burnupEFPD: burnupModel.burnupEFPD,
      burnupMode: burnupModel.mode,
      fuelTemp: kinetics.fuelTemp,
      voidFraction: kinetics.voidFraction,
      dopplerReactivityBeta: dopplerBeta,
      voidReactivityBeta: voidBeta,
      voidMode: kinetics.voidMode,
      ozrBeta: rodSystem.getOperationalMargin(),
      ozrMaxBeta: rodSystem.getMaxOperationalMargin(),
      axialXeTop: fastPoisonsTop.xenonLevel,
      axialXeBottom: fastPoisonsBottom.xenonLevel,
      axialOffsetBeta: fastPoisonsTop.xenonLevel - fastPoisonsBottom.xenonLevel,
      zoneFracTop: zoneFrac.top,
      zoneFracBottom: zoneFrac.bottom,
      azimuthXeLeft: fastPoisonsLeft.xenonLevel,
      azimuthXeRight: fastPoisonsRight.xenonLevel,
      azimuthOffsetBeta: fastPoisonsLeft.xenonLevel - fastPoisonsRight.xenonLevel,
      azimuthFracLeft: azimuthFrac.left,
      azimuthFracRight: azimuthFrac.right,
      coolantFlowFraction: kinetics.coolantFlowFraction,
    };
  }

  function onScram() {
    flushAllPendingRodChanges();
    rodSystem.groups.forEach((g) => {
      _lastLoggedRodPosition[g.id] = g.position;
    });
    rodSystem.scram();
    Dashboard.updateStatus('АЗ-5 ИНИЦИИРОВАНА — аварийный ввод стержней', true);
    if (simSpeed > 1) {
      simSpeed = 1;
      ControlsPanel.selectSpeed(1);
    }
    speedLocked = true;
    ControlsPanel.setSpeedButtonsLocked(true);
  }

  function onReleaseScram() {
    if (!rodSystem.scramActive) return;
    rodSystem.releaseScram();
    rodSystem.groups.forEach((g) => {
      _lastLoggedRodPosition[g.id] = g.position;
    });
    diagnostics.log(kinetics.t, 'info', 'Блокировка АЗ-5 снята оператором — ручное управление стержнями восстановлено', 'scram', buildSnapshot());
    Dashboard.updateStatus('Блокировка АЗ-5 снята — ручное управление восстановлено', false);
  }

  /** Общая часть Горячего/Холодного старта: диагностика/журнал/графики/скорость/пауза */
  function afterStartReset(label) {
    Object.keys(_rodChangePending).forEach((id) => delete _rodChangePending[id]);
    rodSystem.groups.forEach((g) => {
      _lastLoggedRodPosition[g.id] = g.position;
    });

    diagnostics.reset();
    alarms.reset();
    Dashboard.resetTrends();
    scenarioEngine.rebase();
    diagnostics.log(0, 'info', label, 'system', buildSnapshot());
    Dashboard.updateStatus(label, false);
    ControlsPanel.syncPresetButtonsAfterReset();

    simRunning = false;
    simSpeed = 1;
    speedLocked = false;
    rodControlsLocked = true;
    ControlsPanel.setScramButtonLocked(true);
    ControlsPanel.setSpeedButtonsLocked(false);
    ControlsPanel.selectSpeed(1);
    ControlsPanel.resetRunControl();
    kinetics.setCoolantFlowFraction(1.0);
    kinetics.setVoidMode('modern');
    accidentMonitor.reset();
    reactorDestroyed = false;
    if (scenarioEngine.isLoaded()) scenarioEngine.resetFaults();
    ControlsPanel.setStartModeButtonsLocked(false);
    ControlsPanel.setReactorSelectLocked(false);
  }

  /** Горячий старт: реактор уже работает на 100% N0, стержни 50%, Xe/Sm в равновесии */
  function onHotStart() {
    rodSystem.reset();
    kinetics.reset();
    fastPoisons.reset(false);
    fastPoisonsTop.reset(false);
    fastPoisonsBottom.reset(false);
    fastPoisonsLeft.reset(false);
    fastPoisonsRight.reset(false);
    burnupModel.clearHistory();
    afterStartReset('Горячий старт — реактор в стационарном режиме на 100% N0');
  }

  /** Холодный старт: топливо ещё не работало — стержни введены, Xe/Sm=0, топливо холодное */
  function onColdStart() {
    rodSystem.reset(0);
    kinetics.initState(RBMK_PARAMS.coldStartSourceN0, RBMK_PARAMS.thermal.coolantTemp0);
    fastPoisons.reset(true);
    fastPoisonsTop.reset(true);
    fastPoisonsBottom.reset(true);
    fastPoisonsLeft.reset(true);
    fastPoisonsRight.reset(true);
    burnupModel.clearHistory();
    afterStartReset('Холодный старт — стержни введены, реактор заглушён, топливо холодное');
    diagnostics.log(
      0,
      'caution',
      'Внимание: контур первого контура уже на рабочей температуре (270°C) — разогрев с нуля в модели не воспроизводится. Этот сценарий соответствует пуску после короткого планового останова, а не после полного расхолаживания/перегрузки топлива (тот процесс — недели, иногда больше месяца — сюда не входит)',
      'system',
      buildSnapshot()
    );
  }

  function onStart() {
    if (reactorDestroyed) return;
    simRunning = true;
    rodControlsLocked = false;
    ControlsPanel.setScramButtonLocked(false);
    ControlsPanel.setStartModeButtonsLocked(true);
    ControlsPanel.setReactorSelectLocked(true);
    diagnostics.log(kinetics.t, 'info', 'Симуляция запущена оператором', 'system', buildSnapshot());
  }

  function onPauseToggle() {
    if (reactorDestroyed) return simRunning;
    simRunning = !simRunning;
    rodControlsLocked = !simRunning;
    ControlsPanel.setStartModeButtonsLocked(simRunning);
    diagnostics.log(kinetics.t, 'info', simRunning ? 'Симуляция продолжена оператором' : 'Симуляция поставлена на паузу оператором', 'system', buildSnapshot());
    return simRunning;
  }

  function flushRodChangeLog(id) {
    const pending = _rodChangePending[id];
    if (!pending) return;
    delete _rodChangePending[id];
    if (pending.toPct === pending.fromPct) return;
    const g = rodSystem.groups.find((x) => x.id === id);
    const label = g ? g.label : id;
    diagnostics.log(
      kinetics.t,
      'info',
      `${label}: оператор изменил положение с ${pending.fromPct}% до ${pending.toPct}%`,
      'rods',
      buildSnapshot()
    );
    _lastLoggedRodPosition[id] = pending.toPct;
  }

  function flushAllPendingRodChanges() {
    Object.keys(_rodChangePending).forEach(flushRodChangeLog);
  }

  function onRodChange(id, pct) {
    const g = rodSystem.groups.find((x) => x.id === id);
    if (!g) return;
    if (!_rodChangePending[id]) {
      _rodChangePending[id] = { fromPct: _lastLoggedRodPosition[id], toPct: pct, lastChangeRealMs: performance.now() };
    } else {
      _rodChangePending[id].toPct = pct;
      _rodChangePending[id].lastChangeRealMs = performance.now();
    }
  }

  function onPresetChange(presetKey, presetLabel, efpd) {
    diagnostics.log(kinetics.t, 'info', `Оператор выбрал пресет топлива «${presetLabel}» (${efpd.toFixed(1)} EFPD)`, 'burnup', buildSnapshot());
  }

  function formatModelTime(t) {
    const h = Math.floor(t / 3600).toString().padStart(2, '0');
    const m = Math.floor((t % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(t % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
  }

  function formatModelTimeLong(t) {
    const days = Math.floor(t / 86400);
    const h = Math.floor((t % 86400) / 3600).toString().padStart(2, '0');
    const m = Math.floor((t % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(t % 60).toString().padStart(2, '0');
    return `${days} ${h}:${m}:${s}`;
  }

  function snapToLines(snap) {
    if (!snap) return [];
    const rods = snap.rodGroups.map((g) => `${g.label.replace('Группа ', 'Г')} ${Math.round(100 - g.position)}%`).join(' · ');
    return [
      `Мощность: ${(snap.power * 100).toFixed(1)}% N0 · ${Math.round(snap.power * RBMK_PARAMS.nominalPowerMWt)} МВт · ρ: ${snap.rhoBeta >= 0 ? '+' : ''}${snap.rhoBeta.toFixed(3)}β · период: ${isFinite(snap.period) && snap.period !== 0 ? snap.period.toFixed(1) + ' с' : 'н/д'}`,
      `Xe-135: ${snap.xenonLevel.toFixed(2)}β (экв.) · Pm-149: ${snap.promethiumLevel.toFixed(2)}β (будущий Sm) · Sm-149: ${snap.samariumLevel.toFixed(2)}β (экв.)`,
      `Топливо: ${snap.fuelTemp.toFixed(0)}°C · паросодержание ${(snap.voidFraction * 100).toFixed(0)}% · ρ_доплер: ${snap.dopplerReactivityBeta.toFixed(3)}β · ρ_паровой: ${snap.voidReactivityBeta >= 0 ? '+' : ''}${snap.voidReactivityBeta.toFixed(3)}β`,
      `Осевой перекос: ΔXe(верх−низ) ${snap.axialOffsetBeta >= 0 ? '+' : ''}${snap.axialOffsetBeta.toFixed(2)}β · локальная мощность верх/низ ${(snap.zoneFracTop * 100).toFixed(0)}%/${(snap.zoneFracBottom * 100).toFixed(0)}%`,
      `СУЗ: ${snap.scramActive ? (snap.scramComplete ? 'АЗ-5, все группы введены' : 'АЗ-5, идёт аварийный ввод') : rods}`,
      `Наработка: ${snap.burnupEFPD.toFixed(1)} EFPD · ${snap.burnupMode === 'accelerated' ? 'ускоренный режим' : 'зафиксирован возраст'}`,
    ];
  }

  function exportLogToMarkdown() {
    const now = new Date();
    const header = ['# РБМК-1000 · Журнал учебной сессии', '', `Экспортировано: ${now.toLocaleString('ru-RU')}`, '', '---', ''];
    const body = diagnostics.fullHistory
      .map((e) => {
        const sevTag = { alarm: 'АВАРИЯ', caution: 'ВНИМАНИЕ', info: 'ИНФО' }[e.severity] || e.severity.toUpperCase();
        const lines = [`### t = ${formatModelTime(e.t)} (модельное время)`, '', `**[${sevTag}] ${e.text}**`];
        const snapLines = snapToLines(e.snap);
        if (snapLines.length) lines.push('', ...snapLines);
        lines.push('', '---', '');
        return lines.join('\n');
      })
      .join('\n');

    const md = header.join('\n') + body;
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const ts = now.toISOString().slice(0, 19).replace(/[:T]/g, '-');
    a.href = url;
    a.download = `reactor-log-${ts}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  function exportStateToJson() {
    const payload = {
      formatVersion: 1,
      reactor: 'rbmk',
      savedAt: new Date().toISOString(),
      simSpeed,
      kinetics: kinetics.getState(),
      isotopes: fastPoisons.getState(),
      rods: rodSystem.getState(),
      burnup: burnupModel.getState(),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    a.href = url;
    a.download = `reactor-state-${ts}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    diagnostics.log(kinetics.t, 'info', 'Состояние модели сохранено в файл', 'system', buildSnapshot());
  }

  /** Применяет уже распарсенный payload состояния (formatVersion:1) к модели. Не бросает исключение наружу. */
  function applyStatePayload(payload, label) {
    try {
      kinetics.loadState(payload.kinetics);
      fastPoisons.loadState(payload.isotopes);
      rodSystem.loadState(payload.rods);
      burnupModel.loadState(payload.burnup);
      fastPoisonsTop.loadState(payload.isotopes);
      fastPoisonsBottom.loadState(payload.isotopes);
      fastPoisonsLeft.loadState(payload.isotopes);
      fastPoisonsRight.loadState(payload.isotopes);
      afterStartReset(label);
      return { ok: true };
    } catch (e) {
      diagnostics.log(
        kinetics.t,
        'alarm',
        `Не удалось загрузить состояние: ${e.message}. Модель могла остаться в смешанном состоянии — рекомендуется Горячий или Холодный старт`,
        'system',
        buildSnapshot()
      );
      return { ok: false, error: e.message };
    }
  }

  function frame(ts) {
    if (lastTs === null) lastTs = ts;
    let realDt = (ts - lastTs) / 1000;
    lastTs = ts;
    realDt = Math.min(realDt, 0.25);

    if (scenarioEngine.isLoaded()) {
      const faultEffects = scenarioEngine.getActiveFaultEffects();
      if (typeof faultEffects.coolantFlowFraction === 'number') {
        kinetics.setCoolantFlowFraction(faultEffects.coolantFlowFraction);
      }
    }

    if (simRunning) {
      const dt = realDt * simSpeed;
      rodSystem.update(dt);
      kinetics.step(dt);
      fastPoisons.step(dt);
      fastPoisonsTop.step(dt);
      fastPoisonsBottom.step(dt);
      fastPoisonsLeft.step(dt);
      fastPoisonsRight.step(dt);
      burnupModel.update(dt);
    }

    const nowMs = performance.now();
    Object.keys(_rodChangePending).forEach((id) => {
      if (nowMs - _rodChangePending[id].lastChangeRealMs >= ROD_LOG_DEBOUNCE_MS) {
        flushRodChangeLog(id);
      }
    });

    const snap = buildSnapshot();
    alarms.evaluate(kinetics.t, snap);

    let accidentResult = { triggered: accidentMonitor.isTriggered(), reason: accidentMonitor.getReason(), mostUrgent: null };
    if (simRunning && !accidentMonitor.isTriggered()) {
      const accidentConditions = {
        fuelTempAlarm: alarms._fuelTempZone(snap.fuelTemp) === 'alarm',
        overpower: snap.power >= 1.5,
        promptCritical: snap.rhoBeta >= 1.0,
        coolantFlowRisk: alarms._coolantFlowZone(snap.coolantFlowFraction) === 'alarm',
      };
      accidentResult = accidentMonitor.tick(accidentConditions, realDt);
      if (accidentResult.triggered) {
        reactorDestroyed = true;
        simRunning = false;
        rodControlsLocked = true;
        ControlsPanel.setScramButtonLocked(true);
        ControlsPanel.setSpeedButtonsLocked(true);
        ControlsPanel.lockRunControlsForAccident();
        ControlsPanel.setStartModeButtonsLocked(false);
        ControlsPanel.setReactorSelectLocked(false);
        const msg = `АВАРИЯ: повреждение активной зоны — причина: ${accidentResult.reason}`;
        diagnostics.log(kinetics.t, 'alarm', msg, 'system', snap);
        Dashboard.updateStatus(msg, true);
      }
    }
    Dashboard.updateDangerCountdown(accidentResult.mostUrgent);

    if (scenarioEngine.isLoaded()) {
      scenarioEngine.tick(snap, realDt, simRunning);
      scenarioEngine.getActiveMessages().forEach((m) => {
        diagnostics.log(kinetics.t, m.severity, m.text, 'scenario', snap);
      });
    }
    Dashboard.renderScenarioPanel(scenarioEngine.isLoaded() ? scenarioEngine.getMeta() : null, scenarioEngine.isLoaded() ? scenarioEngine.getGoalsState() : []);

    Dashboard.updateGauge(kinetics.power);
    Dashboard.updateReadouts(kinetics, kinetics.t, alarms.isStuckInPit());
    Dashboard.updateReactivity(snap.rhoAbs, rodSystem.betaTotal, kinetics.t);
    Dashboard.renderRodBank(rodSystem, rodControlsLocked, snap);
    Dashboard.renderChart(kinetics.history);
    Dashboard.renderPoisonChart(fastPoisons.history);
    Dashboard.renderDopplerVoidChart(kinetics.history);
    Dashboard.renderComposition(burnupModel.getComposition());
    Dashboard.renderThermal(kinetics.history, snap);
    Dashboard.renderCoreReadouts(snap, kinetics.t);
    Dashboard.renderReactorSecondaryReadouts(snap, kinetics.t);
    ControlsPanel.updateBurnupReadout(burnupModel);

    SharedLogPanel.renderEventLog(diagnostics.events, diagnostics._logVersion);
    SharedLogPanel.renderAnnunciator(alarms.getAnnunciatorState(snap));
    ControlsPanel.updateReleaseScramButton(rodSystem.scramActive);

    if (reactorTimerEl) reactorTimerEl.textContent = formatModelTimeLong(kinetics.t);

    if (simRunning && !speedLocked && simSpeed > 1 && alarms.hasSpeedLockAlarm(snap)) {
      simSpeed = 1;
      speedLocked = true;
      ControlsPanel.selectSpeed(1);
      ControlsPanel.setSpeedButtonsLocked(true);
      diagnostics.log(kinetics.t, 'alarm', 'Автоматический сброс скорости до ×1 — параметр вышел за допустимый диапазон, регулятор скорости заблокирован до стабилизации', 'system', snap);
    }
    if (speedLocked && alarms.isFullyNormal(snap)) {
      speedLocked = false;
      ControlsPanel.setSpeedButtonsLocked(false);
      diagnostics.log(kinetics.t, 'info', 'Реактор стабилизирован — регулятор скорости разблокирован', 'system', snap);
    }

    if (reactorDestroyed) {
      // ничего не делаем — сообщение уже выставлено в момент срабатывания аварии выше
    } else if (kinetics.power > 1.5) {
      Dashboard.updateStatus('ПРЕВЫШЕНИЕ ШКАЛЫ ИНДИКАТОРА — мощность выше 150%', true);
    } else if (rodSystem.scramActive && rodSystem.isFullyInserted()) {
      Dashboard.updateStatus('АЗ-5 завершена — стержни полностью введены', false);
    } else if (rodSystem.scramActive) {
      Dashboard.updateStatus('АЗ-5 ИНИЦИИРОВАНА — аварийный ввод стержней', true);
    } else if (!simRunning) {
      Dashboard.updateStatus('', false);
    } else {
      Dashboard.updateStatus('', false);
    }

    rafHandle = requestAnimationFrame(frame);
  }

  /**
   * mount(container, {logger}) — контракт. `container` по-прежнему не
   * используется напрямую (панель ищет свои слоты-якоря в общем document по
   * фиксированным id "slot-*" — см. ниже), оставлен в сигнатуре ради
   * стабильности контракта. Реальная изоляция панели — через Shadow DOM
   * (v3.8, см. AGENT_HANDOFF.md, план п.6): четыре shadow root'а, по одному
   * на каждый слот-якорь общего index.html.
   */
  function mount(container, opts = {}) {
    diagnostics = opts.logger;
    if (!diagnostics) throw new Error('createRbmkReactor().mount(): нужен opts.logger (общий EventLog оркестратора)');

    rodSystem = new ControlRodSystem(RBMK_PARAMS);
    fastPoisons = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power, RBMK_PARAMS.betaEff);
    burnupModel = new BurnupModel(ISOTOPE_PARAMS.slow, () => kinetics.power, RBMK_PARAMS.betaEff);
    fastPoisonsTop = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power * 2 * rodSystem.getZonePowerFractions().top, RBMK_PARAMS.betaEff);
    fastPoisonsBottom = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power * 2 * rodSystem.getZonePowerFractions().bottom, RBMK_PARAMS.betaEff);
    fastPoisonsLeft = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power * 2 * rodSystem.getAzimuthPowerFractions().left, RBMK_PARAMS.betaEff);
    fastPoisonsRight = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power * 2 * rodSystem.getAzimuthPowerFractions().right, RBMK_PARAMS.betaEff);

    designExcessReactivity = (fastPoisons.equilibrium.Xe + fastPoisons.equilibrium.Sm) * RBMK_PARAMS.betaEff;

    kinetics = new PointKinetics(
      RBMK_PARAMS,
      () =>
        rodSystem.getReactivity() +
        fastPoisons.getXenonReactivity() +
        fastPoisons.getSamariumReactivity() +
        burnupModel.getReactivity() +
        designExcessReactivity +
        zoneImbalanceReactivity() +
        azimuthImbalanceReactivity(),
      'modern'
    );
    scenarioEngine = new ScenarioEngine();
    alarms = new RbmkAlarms(diagnostics);
    accidentMonitor = new AccidentMonitor(RBMK_PARAMS.accidentThresholds);
    reactorDestroyed = false;
    simRunning = false;
    simSpeed = 1;
    speedLocked = false;
    rodControlsLocked = true;
    _rodChangePending = {};
    _lastLoggedRodPosition = {};

    rodSystem.reset(0);
    kinetics.initState(0, RBMK_PARAMS.thermal.coolantTemp0);
    fastPoisons.reset(true);
    fastPoisonsTop.reset(true);
    fastPoisonsBottom.reset(true);
    fastPoisonsLeft.reset(true);
    fastPoisonsRight.reset(true);

    rodSystem.groups.forEach((g) => {
      _lastLoggedRodPosition[g.id] = g.position;
    });

    // --- v3.8: Shadow DOM (см. AGENT_HANDOFF.md, план п.6) ---
    // Панель РБМК рендерится в четыре shadow root'а, каждый приклеен к
    // своему слоту-якорю в общем index.html (id начинаются с "slot-",
    // класс .shadow-slot — display:contents, см. css/style.css: контент
    // shadow root'а становится прямыми детьми родительского flex/grid, как
    // если бы Shadow DOM не было — исходная раскладка не меняется, а DOM/CSS
    // реактора физически изолирован). Слоты — статичные элементы общего
    // документа, не пересоздаются между mount()/unmount(); attachShadow()
    // можно вызвать только один раз на элемент, поэтому переиспользуем уже
    // существующий shadowRoot при повторном mount() (после переключения
    // реактора и обратно), а не падаем на повторном attachShadow().
    function shadowFor(slotId) {
      const el = document.getElementById(slotId);
      return el.shadowRoot || el.attachShadow({ mode: 'open' });
    }
    const shadowCoreReadouts = shadowFor('slot-core-readouts');
    const shadowConsoleMain = shadowFor('slot-console-main');
    const shadowConsoleSide = shadowFor('slot-console-side');
    const shadowThermal = shadowFor('slot-console-thermal');
    const shadowRoots = [shadowCoreReadouts, shadowConsoleMain, shadowConsoleSide, shadowThermal];
    // Общий css/style.css подключается в каждый shadow root через <link> —
    // тот же URL, что и у основного документа, значит браузер отдаёт его из
    // кэша (реального дублирования байт по сети нет), а CSS custom
    // properties (--accent-green и т.п.) наследуются сквозь границу shadow
    // DOM в любом случае, даже без этого <link>. adoptedStyleSheets
    // (единый CSSStyleSheet-объект на все root'а) был бы чуть эффективнее
    // (один парсинг CSS вместо четырёх), но требует async fetch() при
    // старте — не стал усложнять ради страницы такого размера.
    const styleLinkHtml = '<link rel="stylesheet" href="css/style.css">';
    shadowCoreReadouts.innerHTML = styleLinkHtml + RBMK_TEMPLATE_CORE_READOUTS;
    shadowConsoleMain.innerHTML = styleLinkHtml + RBMK_TEMPLATE_CONSOLE_MAIN;
    shadowConsoleSide.innerHTML = styleLinkHtml + RBMK_TEMPLATE_CONSOLE_SIDE;
    shadowThermal.innerHTML = styleLinkHtml + RBMK_TEMPLATE_THERMAL;

    // Фасад с getElementById(), который ищет по всем четырём root'ам —
    // Dashboard.js/controls_panel.js не должны знать, в каком именно из
    // четырёх слотов лежит конкретный id.
    const panelRoot = {
      getElementById(id) {
        for (const r of shadowRoots) {
          const el = r.getElementById(id);
          if (el) return el;
        }
        return null;
      },
    };

    Dashboard.init(panelRoot);
    Dashboard.renderRodBank(rodSystem, rodControlsLocked, buildSnapshot());

    // v3.11 — по договорённости с пользователем: панели времени и
    // "Активная зона · СУЗ" (обе внутри #console-row) специфичны для РБМК
    // по смыслу, CP-1 их прячет целиком (см. createCp1Reactor().mount()).
    // Показываем их здесь на случай, если до этого был смонтирован CP-1.
    document.getElementById('console-row').style.display = '';
    document.getElementById('console-diagnostics-row').style.display = '';
    document.getElementById('console-thermal-row').style.display = '';
    // Общий журнал — возвращаем на своё место рядом со сценарием/наработкой
    // (CP-1 переносит его под свою панель, см. createCp1Reactor().mount()).
    const eventLogPanel = document.getElementById('event-log-panel');
    const consoleDiagnosticsRow = document.getElementById('console-diagnostics-row');
    if (eventLogPanel.parentElement !== consoleDiagnosticsRow) {
      consoleDiagnosticsRow.insertBefore(eventLogPanel, consoleDiagnosticsRow.firstChild);
    }

    diagnostics.log(0, 'info', 'Симулятор загружен — реактор остановлен. Выберите режим пуска (Горячий/Холодный старт) и нажмите «Старт»', 'system', buildSnapshot());

    ControlsPanel.init(panelRoot, rodSystem, onScram, onHotStart, onColdStart, onReleaseScram, onRodChange);
    ControlsPanel.initBurnupControls(panelRoot, burnupModel, onPresetChange);
    ControlsPanel.initRunControl(onStart, onPauseToggle);
    ControlsPanel.initSpeedControl((speed) => {
      simSpeed = speed;
      diagnostics.log(kinetics.t, 'info', `Скорость моделирования: ×${speed}`, 'system', buildSnapshot());
    });

    reactorTimerEl = document.getElementById('reactor-timer');

    on(document.getElementById('btn-save-log'), 'click', exportLogToMarkdown);
    on(document.getElementById('btn-save-state'), 'click', exportStateToJson);
    on(document.getElementById('btn-reset-scenario'), 'click', () => {
      if (!scenarioEngine.isLoaded()) return;
      scenarioEngine.resetAll();
      diagnostics.log(kinetics.t, 'info', 'Прогресс целей сценария сброшен к началу — сам сценарий остался загружен', 'scenario', buildSnapshot());
    });

    lastTs = null;
    rafHandle = requestAnimationFrame(frame);
  }

  function unmount() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    rafHandle = null;
    offAll();
    lastTs = null;
    // Чистим содержимое всех четырёх shadow root'ов — сами root'ы не
    // удаляются (attachShadow() можно вызвать только раз на элемент, см.
    // shadowFor() в mount()), но их контент должен исчезнуть вместе со
    // всеми обработчиками, навешанными на него напрямую (rod-inc-*/
    // rod-dec-*, btn-scram и т.д. — они не отслеживаются через on()/offAll(),
    // а просто перестают существовать вместе с DOM-узлами).
    ['slot-core-readouts', 'slot-console-main', 'slot-console-side', 'slot-console-thermal'].forEach((slotId) => {
      const el = document.getElementById(slotId);
      if (el && el.shadowRoot) el.shadowRoot.innerHTML = '';
    });
  }

  return {
    mount,
    unmount,
    start: () => onStart(),
    pause: () => onPauseToggle(),
    scram: () => onScram(),
    releaseScram: () => onReleaseScram(),
    reset: (mode) => (mode === 'cold' ? onColdStart() : onHotStart()),
    getSnapshot: () => buildSnapshot(),
    loadState: (payload, label) => applyStatePayload(payload, label || `Состояние загружено (сохранено: ${payload.savedAt || 'неизвестно'})`),
    loadScenario: (payload) => scenarioEngine.load(payload),
    loadLesson: (payload) => {
      // Тот же порядок и та же логика, что раньше была в importLessonFromFile():
      // сценарий первым (см. LESSON_FORMAT_SPEC.md — порядок сознательно
      // выбран так, чтобы битый scenario не трогал состояние реактора).
      if (!payload || typeof payload !== 'object' || !payload.state || !payload.scenario) {
        return { ok: false, error: 'файл повреждён — отсутствует state или scenario' };
      }
      const scenarioResult = scenarioEngine.load(payload.scenario);
      if (!scenarioResult.ok) {
        return { ok: false, error: `сценарий повреждён (${scenarioResult.error}), состояние реактора не трогали` };
      }
      const label = `Урок загружен: «${payload.title || payload.id || 'без названия'}» — состояние и сценарий применены`;
      return applyStatePayload(payload.state, label);
    },
    isDestroyed: () => reactorDestroyed,
  };
}
