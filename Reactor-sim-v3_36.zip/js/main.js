// main.js
// Оркестратор (v3.9). main.js больше не физика — это тонкий слой: реестр
// реакторов + общий журнал (EventLog) + переключение через unmount()/mount()
// + чтение файлов состояния/сценария/урока с автовыбором реактора по полю
// `reactor` в заголовке (см. AGENT_HANDOFF.md, план 1-7).
//
// Что здесь осталось намеренно (общее для всех реакторов):
//  - EventLog — ОДИН экземпляр, переживает переключение реакторов
//    ("Лог един", см. AGENT_HANDOFF.md).
//  - Реестр РЕАКТОРОВ (REACTORS) — добавление нового реактора = новая
//    запись здесь, без правок логики переключения (план, п.3).
//  - Дропдаун выбора реактора (шапка).
//  - Чтение файлов (.state.json/.scenario.json/.lesson.json) — ЗДЕСЬ, не
//    внутри reactor-модуля: нужно прочитать поле `reactor` из файла ДО
//    решения, какому модулю отдавать разобранный payload (план, п.5).
//    Старые файлы без поля `reactor` (сохранённые до v3.7) — считаются
//    `rbmk` (см. resolveFileReactorId ниже).
//
// v3.9 — CP-1 (`js/reactors/cp1/`) зарегистрирован как реальный
// reactor-модуль (подшаг C плана «CP-1 + Shadow DOM»). У CP-1 пока нет
// собственных сценариев/уроков (`loadScenario`/`loadLesson` возвращают
// `{ok:false}` с понятной причиной) — загрузка `.scenario.json`/
// `.lesson.json` при активном CP-1 корректно отказывает через обычный
// путь ошибки `wireFileLoad()`, ничего специально обрабатывать здесь не
// нужно. Оба реактора теперь честно поддерживают переключение — ветка
// "неизвестный id" в ensureReactor() ниже осталась на случай будущего
// третьего реактора, который ещё не зарегистрирован.

(function () {
  const diagnostics = new EventLog();
  SharedLogPanel.init();

  const REACTORS = {
    rbmk: { label: 'РБМК-1000', create: () => createRbmkReactor() },
    cp1: { label: 'Chicago Pile-1', create: () => createCp1Reactor() },
  };
  const DEFAULT_REACTOR_ID = 'rbmk';
  const KIND_LABEL = { state: 'состояние', scenario: 'сценарий', lesson: 'урок' };

  // Панель РБМК сейчас разбросана по фиксированным id всего document (нет
  // единого враппера — Shadow DOM/контейнеризация панели каждого реактора
  // это отдельный шаг плана, п.6, ещё не сделан). document.body — временная
  // заглушка вместо реального контейнера, только чтобы контракт mount(container, ...)
  // уже сейчас принимал второй параметр правильной формы.
  const container = document.body;

  let activeReactorId = null;
  let activeReactor = null;

  function currentT() {
    return activeReactor ? activeReactor.getSnapshot().t : 0;
  }

  function mountReactor(id) {
    const entry = REACTORS[id];
    if (!entry) return false;
    SharedLogPanel.resetAnnunciator();
    activeReactor = entry.create();
    activeReactor.mount(container, { logger: diagnostics });
    activeReactorId = id;
    // v3.24 — БАГФИКС: раньше дропдаун реакторов синхронизировался с
    // activeReactorId только когда переключение шло ЧЕРЕЗ сам дропдаун
    // (его onChange и так уже показывает выбор). Если переключение
    // происходило другим путём (напр. загрузка файла другого реактора —
    // см. wireFileLoad → ensureReactor), подпись в дропдауне могла разойтись
    // с реально смонтированным реактором. Теперь синхронизируем всегда,
    // при любом успешном mountReactor().
    ControlsPanel.selectReactor(id);
    return true;
  }

  // v3.24 — БАГФИКС: найден реальный кейс, когда панель СТАРОГО реактора
  // оставалась видна на экране поверх/рядом с только что смонтированным
  // новым (репорт пользователя — переключились на РБМК, но CP-1 со своим
  // попапом урока остался висеть, а общий журнал вперемешку получил
  // стартовые строки ОБОИХ реакторов). У каждого реактора — фиксированный
  // Shadow DOM слот (#slot-cp1-panel у CP-1, четыре #slot-console-* у
  // РБМК, см. index.html) — единственное, что мешает им "просвечивать"
  // друг через друга, это то, что unmount() СТАРОГО реактора сам вычищает
  // свой shadowRoot.innerHTML. Никакого запасного скрытия на уровне CSS
  // нет — если unmount() не отработал (исключение внутри, либо просто не
  // был вызван на актуальном объекте), старая панель провисает вечно.
  // Точную причину конкретного случая воспроизвести не удалось (нужен
  // браузер), поэтому чиним НАДЁЖНО, а не гоняемся за первопричиной:
  // принудительно чистим ВСЕ известные слоты перед каждым переключением,
  // независимо от того, кто их занимал и почему.
  function clearAllReactorSlots() {
    document.querySelectorAll('.shadow-slot').forEach((slot) => {
      if (slot.shadowRoot) slot.shadowRoot.innerHTML = '';
    });
  }

  /** true — уже на нужном реакторе или успешно переключились; false — отказ (неизвестный id, дропдаун откатывается). */
  function ensureReactor(id, refuseMessage) {
    if (id === activeReactorId) return true;
    if (!REACTORS[id]) {
      diagnostics.log(currentT(), 'caution', refuseMessage, 'system', activeReactor ? activeReactor.getSnapshot() : null);
      ControlsPanel.selectReactor(activeReactorId);
      return false;
    }
    if (activeReactor) {
      try {
        activeReactor.unmount();
      } catch (e) {
        // v3.24 — раньше исключение здесь тихо прерывало ensureReactor()
        // ЦЕЛИКОМ (mountReactor(id) ниже просто не вызывался бы) — новый
        // реактор не появлялся вообще, при этом старый мог остаться в
        // частично разобранном состоянии. Теперь ошибка не блокирует
        // переключение — clearAllReactorSlots() ниже подчищает независимо
        // от того, чем закончился unmount().
        diagnostics.log(currentT(), 'caution', `Ошибка при закрытии предыдущего реактора: ${e.message} (переключение продолжено)`, 'system', null);
      }
    }
    clearAllReactorSlots();
    mountReactor(id);
    return true;
  }

  function switchReactor(id) {
    ensureReactor(id, `Реактор «${id}» не зарегистрирован в этой сборке как реальный модуль — переключение отменено, реактор не менялся`);
  }

  ControlsPanel.initReactorSelect(switchReactor);

  // --- Загрузка файлов (состояние/сценарий/урок), план п.5 ---
  //
  // Поле `reactor` в заголовке файла: для .state.json — верхнеуровневое
  // (см. exportStateToJson() в reactor-модуле), для .lesson.json — тоже
  // верхнеуровневое ЛИБО внутри вложенного state (на случай, если урок
  // собрали вручную из отдельно сохранённого файла состояния, где поле
  // есть только там). Для .scenario.json поля `reactor` в текущей
  // реализации нет — сценарий сам по себе не содержит state, поэтому при
  // его загрузке реактор НЕ переключаем, накладываем на уже активный.
  function resolveFileReactorId(payload, hasOwnField) {
    if (!hasOwnField) return activeReactorId || DEFAULT_REACTOR_ID;
    return payload.reactor || (payload.state && payload.state.reactor) || DEFAULT_REACTOR_ID;
  }

  function readJsonFile(file, onOk, onErr) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        onOk(JSON.parse(reader.result));
      } catch (e) {
        onErr(e.message);
      }
    };
    reader.readAsText(file);
  }

  function wireFileLoad(btnId, inputId, kind, onPayload) {
    const input = document.getElementById(inputId);
    document.getElementById(btnId).addEventListener('click', () => input.click());
    input.addEventListener('change', () => {
      if (!input.files || !input.files[0]) return;
      const file = input.files[0];
      input.value = '';
      readJsonFile(
        file,
        (payload) => {
          const targetId = resolveFileReactorId(payload, kind !== 'scenario');
          const refuseMsg = `Файл (${KIND_LABEL[kind]}) рассчитан на реактор «${targetId}», которого нет в этой сборке как реального модуля — загрузка отменена, реактор не менялся`;
          if (!ensureReactor(targetId, refuseMsg)) return;
          onPayload(payload);
        },
        (errMsg) => {
          diagnostics.log(
            currentT(),
            'alarm',
            `Не удалось загрузить ${KIND_LABEL[kind]}: файл повреждён или не JSON (${errMsg})`,
            kind === 'state' ? 'system' : 'scenario',
            activeReactor ? activeReactor.getSnapshot() : null
          );
        }
      );
    });
  }

  wireFileLoad('btn-load-state', 'load-state-input', 'state', (payload) => {
    activeReactor.loadState(payload, `Состояние загружено из файла (сохранено: ${payload.savedAt || 'неизвестно'})`);
  });

  wireFileLoad('btn-load-scenario', 'load-scenario-input', 'scenario', (payload) => {
    const result = activeReactor.loadScenario(payload);
    diagnostics.log(
      currentT(),
      result.ok ? 'info' : 'alarm',
      result.ok ? `Сценарий загружен: «${payload.title || payload.id || 'без названия'}»` : `Не удалось загрузить сценарий: ${result.error}`,
      'scenario',
      activeReactor.getSnapshot()
    );
  });

  wireFileLoad('btn-load-lesson', 'load-lesson-input', 'lesson', (payload) => {
    const result = activeReactor.loadLesson(payload);
    if (!result.ok) {
      diagnostics.log(currentT(), 'alarm', `Не удалось загрузить урок: ${result.error}`, 'scenario', activeReactor.getSnapshot());
    }
  });

  mountReactor(DEFAULT_REACTOR_ID);
})();
