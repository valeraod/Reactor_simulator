// shared_log_panel.js
// Отрисовка общего журнала событий и мнемопанели тревог — вынесено из
// js/ui/dashboard.js (тот целиком принадлежит РБМК). Сама отрисовка ничего
// не знает о конкретном реакторе — просто рисует {t,severity,text} и
// {key,label,severity}, которые ей передают. Инициализируется ОДИН раз
// оркестратором (main.js), переживает переключение реакторов — как и общий
// EventLog, который эти данные хранит.

const SharedLogPanel = {
  init() {
    this.eventLogEl = document.getElementById('event-log');
    this.annunciatorEl = document.getElementById('annunciator-grid');
    this._annunciatorBuilt = false;
    this._annunciatorEls = {};
    this._lastLogVersion = -1;
  },

  /** Вызывается оркестратором при переключении реактора — новый реактор
   *  может прислать другой набор плиток (другие key/label), грид нужно
   *  перестроить с нуля, а не пытаться переиспользовать старые id. */
  resetAnnunciator() {
    this._annunciatorBuilt = false;
    this._annunciatorEls = {};
    if (this.annunciatorEl) this.annunciatorEl.innerHTML = '';
  },

  renderAnnunciator(items) {
    if (!this.annunciatorEl) return;
    if (!this._annunciatorBuilt) {
      this.annunciatorEl.innerHTML = items
        .map((it) => `<div class="annun-tile" id="annun-${it.key}">${it.label}</div>`)
        .join('');
      this._annunciatorEls = {};
      items.forEach((it) => {
        this._annunciatorEls[it.key] = document.getElementById(`annun-${it.key}`);
      });
      this._annunciatorBuilt = true;
    }
    items.forEach((it) => {
      const el = this._annunciatorEls[it.key];
      if (!el) return;
      el.className = 'annun-tile' + (it.severity !== 'normal' ? ' annun-' + it.severity : '');
    });
  },

  renderEventLog(events, logVersion) {
    if (!this.eventLogEl) return;
    if (logVersion === this._lastLogVersion) return; // без изменений — не трогаем DOM
    this._lastLogVersion = logVersion;
    const rows = events
      .slice()
      .reverse()
      .map((e) => {
        const mm = Math.floor(e.t / 60).toString().padStart(2, '0');
        const ss = Math.floor(e.t % 60).toString().padStart(2, '0');
        return `<div class="event-item ${e.severity}"><span class="event-time">${mm}:${ss}</span><span class="event-text">${e.text}</span></div>`;
      })
      .join('');
    this.eventLogEl.innerHTML = rows;
  },
};
