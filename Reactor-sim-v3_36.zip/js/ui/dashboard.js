// dashboard.js
// Отвечает только за отрисовку — не трогает физику модели.

const Dashboard = {
  gaugeMaxValue: 1.5, // 150% по шкале индикатора
  gaugeCx: 120,
  gaugeCy: 120,
  gaugeR: 90,

  chartCtx: null,
  chartCanvas: null,

  init(root) {
    // v3.8 — Shadow DOM (см. AGENT_HANDOFF.md, п.6): `root` — фасад с
    // getElementById(), который ищет по всем shadow root'ам панели РБМК
    // (см. createRbmkReactor().mount() в js/reactors/rbmk/index.js).
    // ИСКЛЮЧЕНИЯ — два элемента остаются в общей шапке (вне Shadow DOM,
    // общие на все реакторы), ищутся через обычный document как раньше:
    // danger-countdown и btn-reset-scenario (кнопка "Сбросить прогресс" в
    // меню "Загрузить" общей шапки).
    this.root = root;

    this.needleEl = root.getElementById('gauge-needle');
    this.powerPctEl = root.getElementById('readout-power-pct');
    this.powerMwtEl = root.getElementById('readout-power-mwt');
    this.reactivityEl = root.getElementById('readout-reactivity');
    this.periodEl = root.getElementById('readout-period');
    this.statusEl = root.getElementById('status-line');
    // v2.3 — терминальная авария: отдельный от status-line баннер обратного
    // отсчёта (status-line уже занята другими сообщениями и конфликтовала
    // бы с ним, см. обсуждение с пользователем). Общий элемент — вне Shadow
    // DOM (см. комментарий выше), ищется через document, не root.
    this.dangerCountdownEl = document.getElementById('danger-countdown');

    this.chartCanvas = root.getElementById('power-chart');
    this.chartCtx = this.chartCanvas.getContext('2d');

    this.rodBankEl = root.getElementById('rod-bank');

    this.poisonChartCanvas = root.getElementById('poison-chart');
    this.poisonChartCtx = this.poisonChartCanvas.getContext('2d');

    this.compositionBarEl = root.getElementById('composition-bar');
    this.compositionLegendEl = root.getElementById('composition-legend');
    this.burnupControlsEl = root.getElementById('burnup-controls');

    this.thermalChartCanvas = root.getElementById('thermal-chart');
    this.thermalChartCtx = this.thermalChartCanvas.getContext('2d');
    this.thermalReadoutsEl = root.getElementById('thermal-readouts');
    this.voidGaugeFillEl = root.getElementById('void-gauge-fill');
    this.voidGaugeValEl = root.getElementById('void-gauge-val');

    // v3.0 §2/§3 — вторая строка индикаторов (Топливо/Доплер ρ/Паровой ρ/
    // Паросодерж) над графиком мощности, и новый график обратных связей.
    this.secondaryReadoutsEl = root.getElementById('gauge-readout-secondary');
    this.dopplerVoidChartCanvas = root.getElementById('doppler-void-chart');
    this.dopplerVoidChartCtx = this.dopplerVoidChartCanvas.getContext('2d');

    this.trendPowerPctEl = root.getElementById('trend-power-pct');
    this.trendPowerMwtEl = root.getElementById('trend-power-mwt');
    this.trendReactivityEl = root.getElementById('trend-reactivity');
    this.trendPeriodEl = root.getElementById('trend-period');

    this.coreReadoutsEl = root.getElementById('core-readouts');

    this.scenarioTitleEl = root.getElementById('scenario-title');
    this.scenarioGoalsEl = root.getElementById('scenario-goals');
    // Кнопка "Сбросить прогресс" — общая (меню "Загрузить" в шапке), не в Shadow DOM.
    this.scenarioResetBtnEl = document.getElementById('btn-reset-scenario');
    this.scenarioDetailsEl = root.getElementById('scenario-details');
    this.scenarioPanelWrapEl = root.getElementById('scenario-panel-wrap');

    // Буфер сглаженного тренда (▲/▼/—): для каждого параметра храним историю
    // {t, v} и сравниваем текущее значение с точкой ~trendWindowSec назад —
    // сравнение с предыдущим кадром рендера было бы слишком "дёрганым"
    this._trendBuf = {};
    this._trendWindowSec = 10;
  },

  /** Сбрасывает буфер трендов — вызывается при Горячем/Холодном старте, т.к. модельное время обнуляется */
  resetTrends() {
    this._trendBuf = {};
  },

  /**
   * Сглаженный тренд параметра: ▲ рост / ▼ падение / — без изменений,
   * относительно значения ~trendWindowSec модельных секунд назад (не относительно
   * предыдущего кадра рендера — иначе стрелка дёргалась бы на шумных величинах).
   * @param {string} key - уникальный ключ параметра
   * @param {number} value - текущее значение
   * @param {number} t - текущее модельное время, с
   * @param {number} eps - порог нечувствительности (в единицах value) — стрелка
   *   появляется только если изменение заметно на отображаемой точности числа
   */
  _trend(key, value, t, eps) {
    if (!isFinite(value)) return 'flat';
    const buf = this._trendBuf[key] || (this._trendBuf[key] = []);
    buf.push({ t, v: value });
    const windowSec = this._trendWindowSec;
    // Не даём буферу расти бесконечно — не нужна история глубже пары окон
    while (buf.length > 2 && t - buf[0].t > windowSec * 4) buf.shift();
    let ref = buf[0];
    for (const p of buf) {
      if (t - p.t >= windowSec) ref = p;
      else break;
    }
    const diff = value - ref.v;
    if (!isFinite(diff)) return 'flat';
    if (diff > eps) return 'up';
    if (diff < -eps) return 'down';
    return 'flat';
  },

  _trendArrow(trend) {
    return trend === 'up' ? '▲' : trend === 'down' ? '▼' : '—';
  },

  _setTrendEl(el, trend) {
    if (!el) return;
    el.textContent = this._trendArrow(trend);
  },

  /**
   * v1.9 — "живой" индикатор вместо стрелки тренда мощности, пока диагностика
   * (RbmkAlarms.isStuckInPit()) сигналит, что реактор застрял ниже
   * порога отображения мощности. Обычная стрелка тренда в этом диапазоне
   * показывала бы "—" неотличимо от настоящего зависания интерфейса — этот
   * шеврон мигает по CSS-анимации (реальное время, не завязано на скорость
   * моделирования и на частоту кадров рендера) специально, чтобы оператор
   * видел: движок жив, просто абсолютная мощность пока не видна на шкале.
   */
  _setAliveChevron(el) {
    if (!el) return;
    el.textContent = '›';
    el.className = 'lcd-trend alive';
  },

  _angleForValue(v) {
    if (!isFinite(v)) v = this.gaugeMaxValue; // защита: NaN/Infinity не должны ронять отрисовку стрелки
    const clamped = Math.max(0, Math.min(this.gaugeMaxValue, v));
    // 180deg (v=0) -> 0deg (v=max), проходя через верх
    return 180 - (clamped / this.gaugeMaxValue) * 180;
  },

  updateGauge(powerRel) {
    const angleDeg = this._angleForValue(powerRel);
    const rad = (angleDeg * Math.PI) / 180;
    const x2 = this.gaugeCx + this.gaugeR * Math.cos(rad);
    const y2 = this.gaugeCy - this.gaugeR * Math.sin(rad);
    this.needleEl.setAttribute('x2', x2.toFixed(1));
    this.needleEl.setAttribute('y2', y2.toFixed(1));

    // Цвет стрелки меняется в зависимости от зоны
    let color = '#35e08a';
    if (powerRel > 1.2) color = '#ff3b30';
    else if (powerRel > 1.0) color = '#ffb020';
    this.needleEl.setAttribute('stroke', color);
  },

  updateReadouts(kinetics, t, stuckInPit) {
    const pct = kinetics.power * 100;
    this.powerPctEl.textContent = pct.toFixed(1);
    this.powerPctEl.className = 'lcd-value' + (pct > 120 ? ' alarm' : pct > 100 ? ' caution' : '');
    if (stuckInPit) {
      this._setAliveChevron(this.trendPowerPctEl);
    } else {
      // _setTrendEl трогает только textContent — className нужно вернуть к
      // базовому явно, иначе после выхода из "живого" состояния зелёный
      // мигающий класс остался бы навсегда на этом элементе.
      if (this.trendPowerPctEl) this.trendPowerPctEl.className = 'lcd-trend';
      this._setTrendEl(this.trendPowerPctEl, this._trend('powerPct', pct, t, 0.05));
    }

    this.powerMwtEl.textContent = Math.round(kinetics.powerMWt);
    this._setTrendEl(this.trendPowerMwtEl, this._trend('powerMwt', kinetics.powerMWt, t, 0.5));

    const period = kinetics.period;
    if (!isFinite(period) || Math.abs(period) > 999) {
      this.periodEl.textContent = '∞';
      this.periodEl.className = 'lcd-value';
      this._setTrendEl(this.trendPeriodEl, 'flat');
    } else {
      this.periodEl.textContent = period.toFixed(1);
      this.periodEl.className = 'lcd-value' + (period > 0 && period < 5 ? ' alarm' : period > 0 && period < 20 ? ' caution' : '');
      this._setTrendEl(this.trendPeriodEl, this._trend('period', period, t, 0.5));
    }
  },

  updateReactivity(rhoAbs, betaTotal, t) {
    const rhoBeta = rhoAbs / betaTotal;
    this.reactivityEl.textContent = (rhoBeta >= 0 ? '+' : '') + rhoBeta.toFixed(3);
    this.reactivityEl.className = 'lcd-value' + (rhoBeta >= 1.0 ? ' alarm' : rhoBeta > 0.3 ? ' caution' : '');
    this._setTrendEl(this.trendReactivityEl, this._trend('reactivity', rhoBeta, t, 0.0005));
  },

  updateStatus(text, isAlarm) {
    this.statusEl.textContent = text || '';
    this.statusEl.className = 'status-line' + (isAlarm ? ' alarm' : '');
  },

  /**
   * v2.3 — драматичный обратный отсчёт до терминальной аварии (отдельный
   * баннер, не переиспользует status-line — см. init()). mostUrgent —
   * {label, remainingSec, limitSec} | null, см. accident_monitor.js.
   */
  updateDangerCountdown(mostUrgent) {
    if (!this.dangerCountdownEl) return;
    if (!mostUrgent) {
      this.dangerCountdownEl.textContent = '';
      this.dangerCountdownEl.classList.remove('visible');
      return;
    }
    this.dangerCountdownEl.textContent = `⚠ ${mostUrgent.label} — до необратимых последствий: ${mostUrgent.remainingSec.toFixed(1)} с`;
    this.dangerCountdownEl.classList.add('visible');
  },

  // Геометрия — фиксированная раскладка под 4 реальных привода из
  // rbmk_params.rodGroups (Г1 верх-лево, Г2 верх-право, Г3 верх-центр,
  // УСП низ-центр). Зазоры между Г1/Г3/Г2 равны (было замечено пользователем
  // на скриншоте — 15 и 35 у.е., исправлено на 20/20).
  _MNEMONIC_LAYOUT: {
    group1: { x: 25,  w: 70 },
    group2: { x: 205, w: 70 },
    group3: { x: 115, w: 70 },
    usp:    { x: 90,  w: 120 },
  },
  _MNEMONIC_CORE_TOP: 20,
  _MNEMONIC_CORE_BOTTOM: 280,

  _svgEl(tag, attrs) {
    const NS = 'http://www.w3.org/2000/svg';
    const e = document.createElementNS(NS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  },

  buildCoreMnemonicSvg(rodSystem) {
    const L = this._MNEMONIC_LAYOUT;
    const CORE_TOP = this._MNEMONIC_CORE_TOP;
    const CORE_BOTTOM = this._MNEMONIC_CORE_BOTTOM;
    const CORE_H = CORE_BOTTOM - CORE_TOP;
    const TOP_ZONE_H = CORE_H * 0.62;
    const BOTTOM_ZONE_H = CORE_H - TOP_ZONE_H;
    const TOP_ZONE_Y0 = CORE_TOP;
    const BOTTOM_ZONE_Y0 = CORE_TOP + TOP_ZONE_H;
    this._mnemonicZones = { TOP_ZONE_H, BOTTOM_ZONE_H, TOP_ZONE_Y0, BOTTOM_ZONE_Y0, CORE_BOTTOM };

    const svg = this.root.getElementById('core-svg');
    svg.innerHTML = '';

    // Градиенты заливки: норма/предупреждение (тот же порог, что раньше был
    // у полос — position < 20%, т.е. стержень почти полностью введён)/АЗ-5.
    const defs = this._svgEl('defs', {});
    const gNorm = this._svgEl('linearGradient', { id: 'mnemonicGradNorm', x1: '0', y1: '0', x2: '0', y2: '1' });
    gNorm.appendChild(this._svgEl('stop', { offset: '0%', 'stop-color': 'var(--accent-green)' }));
    gNorm.appendChild(this._svgEl('stop', { offset: '100%', 'stop-color': 'var(--accent-green-dim)' }));
    const gWarn = this._svgEl('linearGradient', { id: 'mnemonicGradWarn', x1: '0', y1: '0', x2: '0', y2: '1' });
    gWarn.appendChild(this._svgEl('stop', { offset: '0%', 'stop-color': 'var(--accent-amber)' }));
    gWarn.appendChild(this._svgEl('stop', { offset: '100%', 'stop-color': '#a8710a' }));
    const gScram = this._svgEl('linearGradient', { id: 'mnemonicGradScram', x1: '0', y1: '0', x2: '0', y2: '1' });
    gScram.appendChild(this._svgEl('stop', { offset: '0%', 'stop-color': 'var(--accent-red)' }));
    gScram.appendChild(this._svgEl('stop', { offset: '100%', 'stop-color': '#8a1f18' }));
    defs.appendChild(gNorm); defs.appendChild(gWarn); defs.appendChild(gScram);
    svg.appendChild(defs);

    svg.appendChild(this._svgEl('rect', { x: 10, y: CORE_TOP - 10, width: 280, height: CORE_H + 20, class: 'core-outline', rx: 3 }));
    svg.appendChild(this._svgEl('line', { x1: 10, y1: BOTTOM_ZONE_Y0, x2: 290, y2: BOTTOM_ZONE_Y0, class: 'zone-divider' }));

    this._mnemonicFillEls = {};

    ['group1', 'group2', 'group3'].forEach((id) => {
      const g = rodSystem.groups.find((x) => x.id === id);
      const pos = L[id];
      svg.appendChild(this._svgEl('rect', { x: pos.x, y: TOP_ZONE_Y0, width: pos.w, height: TOP_ZONE_H, fill: 'var(--bg-panel)', stroke: 'var(--border-hairline-light)', 'stroke-width': 1 }));
      const fill = this._svgEl('rect', { x: pos.x, y: TOP_ZONE_Y0, width: pos.w, height: 0, class: 'rod-fill-rect' });
      svg.appendChild(fill);
      const label = this._svgEl('text', { x: pos.x + pos.w / 2, y: TOP_ZONE_Y0 - 4, 'text-anchor': 'middle', class: 'rod-label-svg' });
      label.textContent = g ? g.label : id;
      svg.appendChild(label);
      const pct = this._svgEl('text', { x: pos.x + pos.w / 2, y: TOP_ZONE_Y0 + TOP_ZONE_H / 2, 'text-anchor': 'middle', class: 'rod-pct-svg' });
      svg.appendChild(pct);
      this._mnemonicFillEls[id] = { fill, pct };
    });

    {
      const g = rodSystem.groups.find((x) => x.id === 'usp');
      const pos = L.usp;
      svg.appendChild(this._svgEl('rect', { x: pos.x, y: BOTTOM_ZONE_Y0, width: pos.w, height: BOTTOM_ZONE_H, fill: 'var(--bg-panel)', stroke: 'var(--border-hairline-light)', 'stroke-width': 1 }));
      const fill = this._svgEl('rect', { x: pos.x, y: CORE_BOTTOM, width: pos.w, height: 0, class: 'rod-fill-rect' });
      svg.appendChild(fill);
      const label = this._svgEl('text', { x: pos.x + pos.w / 2, y: CORE_BOTTOM + 14, 'text-anchor': 'middle', class: 'rod-label-svg' });
      label.textContent = g ? g.label : 'усп';
      svg.appendChild(label);
      const pct = this._svgEl('text', { x: pos.x + pos.w / 2, y: BOTTOM_ZONE_Y0 + BOTTOM_ZONE_H / 2, 'text-anchor': 'middle', class: 'rod-pct-svg' });
      svg.appendChild(pct);
      this._mnemonicFillEls.usp = { fill, pct };
    }

    // Шкалы перекоса. Полный ход условно ±4β, зона "caution" от |2|β —
    // ровно порог diagnostics/dashboard (axialSeverity/azimuthSeverity),
    // не выдуманное число.
    const v = this.root.getElementById('vgauge-svg');
    v.innerHTML = '';
    v.appendChild(this._svgEl('rect', { x: 8, y: 10, width: 8, height: 280, class: 'gauge-track', rx: 2 }));
    v.appendChild(this._svgEl('rect', { x: 8, y: 10, width: 8, height: 70, class: 'gauge-caution-zone' }));
    v.appendChild(this._svgEl('rect', { x: 8, y: 220, width: 8, height: 70, class: 'gauge-caution-zone' }));
    v.appendChild(this._svgEl('line', { x1: 4, y1: 150, x2: 24, y2: 150, class: 'gauge-zero-line' }));
    const vNeedle = this._svgEl('polygon', { points: '0,150 8,145 8,155', class: 'gauge-needle' });
    v.appendChild(vNeedle);

    const h = this.root.getElementById('hgauge-svg');
    h.innerHTML = '';
    h.appendChild(this._svgEl('rect', { x: 10, y: 8, width: 280, height: 8, class: 'gauge-track', rx: 2 }));
    h.appendChild(this._svgEl('rect', { x: 10, y: 8, width: 70, height: 8, class: 'gauge-caution-zone' }));
    h.appendChild(this._svgEl('rect', { x: 220, y: 8, width: 70, height: 8, class: 'gauge-caution-zone' }));
    h.appendChild(this._svgEl('line', { x1: 150, y1: 4, x2: 150, y2: 24, class: 'gauge-zero-line' }));
    const hNeedle = this._svgEl('polygon', { points: '150,0 145,8 155,8', class: 'gauge-needle' });
    h.appendChild(hNeedle);

    this._mnemonicNeedles = { v: vNeedle, h: hNeedle };
  },

  updateCoreMnemonic(rodSystem, snap) {
    const Z = this._mnemonicZones;
    rodSystem.groups.forEach((g) => {
      const els = this._mnemonicFillEls[g.id];
      if (!els) return;
      const insertedFrac = (100 - g.position) / 100;
      const gradId = rodSystem.scramActive ? 'mnemonicGradScram' : g.position < 20 ? 'mnemonicGradWarn' : 'mnemonicGradNorm';
      if (g.zone === 'bottom') {
        const hgt = insertedFrac * Z.BOTTOM_ZONE_H;
        els.fill.setAttribute('y', Z.CORE_BOTTOM - hgt);
        els.fill.setAttribute('height', hgt);
      } else {
        const hgt = insertedFrac * Z.TOP_ZONE_H;
        els.fill.setAttribute('y', Z.TOP_ZONE_Y0);
        els.fill.setAttribute('height', hgt);
      }
      els.fill.setAttribute('fill', `url(#${gradId})`);
      // Показываем "% введено" (100 - position), а не сырое position
      // (которое физически 0=введён/100=выведен, т.е. по факту "%
      // выведенности") — иначе оператор читает число как "% ввода" и
      // ошибается в направлении (см. обсуждение с пользователем).
      els.pct.textContent = `${Math.round(100 - g.position)}%`;
    });

    // Перекос — НАСТОЯЩИЕ значения из snap (axialOffsetBeta/azimuthOffsetBeta,
    // считаются в kinetics.js из накопленного Xe-135 по зонам, с реальной
    // инерцией в часы) — никакой иллюстративной формулы от положений
    // стержней здесь больше нет (см. обсуждение — демо-версия такое
    // использовала, реальная панель обязана брать готовый snap).
    const axial = snap ? snap.axialOffsetBeta : 0;
    const azimuth = snap ? snap.azimuthOffsetBeta : 0;
    const axialClamped = Math.max(-4, Math.min(4, axial));
    const azimuthClamped = Math.max(-4, Math.min(4, azimuth));

    const vNeedleY = 150 - (axialClamped / 4) * 140;
    this._mnemonicNeedles.v.setAttribute('points', `0,${vNeedleY} 8,${vNeedleY - 5} 8,${vNeedleY + 5}`);
    const hNeedleX = 150 + (azimuthClamped / 4) * 140;
    this._mnemonicNeedles.h.setAttribute('points', `${hNeedleX},0 ${hNeedleX - 5},8 ${hNeedleX + 5},8`);
  },

  renderRodBank(rodSystem, controlsLocked, snap) {
    if (!this._coreMnemonicBuilt) {
      this.buildCoreMnemonicSvg(rodSystem);
      this._coreMnemonicBuilt = true;
    }
    this.updateCoreMnemonic(rodSystem, snap);

    // Компактные степперы под мнемосхемой — заменили вертикальные полосы
    // (сама заливка теперь видна на SVG-схеме выше, дублировать бар здесь
    // избыточно — см. обсуждение "занимает много места").
    if (!this._rodBankBuilt) {
      this.rodBankEl.innerHTML = '';
      this._rodFillEls = {};
      rodSystem.groups.forEach((g) => {
        const row = document.createElement('div');
        row.className = 'rod-ctrl-row';

        const zoneParts = [];
        if (g.zone === 'top') zoneParts.push('верх');
        if (g.zone === 'bottom') zoneParts.push('низ');
        if (g.azimuthZone === 'left') zoneParts.push('лево');
        if (g.azimuthZone === 'right') zoneParts.push('право');

        const name = document.createElement('div');
        name.className = 'rod-ctrl-name';
        name.textContent = g.label;
        const zoneLabel = document.createElement('span');
        zoneLabel.className = 'rod-zone-label';
        zoneLabel.textContent = zoneParts.join(' · ');
        name.appendChild(zoneLabel);

        const stepper = document.createElement('div');
        stepper.className = 'rod-ctrl-stepper';

        const decBtn = document.createElement('button');
        decBtn.type = 'button';
        decBtn.className = 'rod-step-btn';
        decBtn.id = `rod-dec-${g.id}`;
        decBtn.textContent = '−';
        decBtn.title = `${g.label}: вывести на 1%`;

        const pctLabel = document.createElement('span');
        pctLabel.className = 'rod-ctrl-val';
        pctLabel.id = `rod-pct-${g.id}`;
        // "% введено" (100 - position) — см. комментарий в updateCoreMnemonic()
        pctLabel.textContent = `${Math.round(100 - g.position)}%`;

        const incBtn = document.createElement('button');
        incBtn.type = 'button';
        incBtn.className = 'rod-step-btn';
        incBtn.id = `rod-inc-${g.id}`;
        incBtn.textContent = '+';
        incBtn.title = `${g.label}: ввести на 1%`;

        stepper.appendChild(decBtn);
        stepper.appendChild(pctLabel);
        stepper.appendChild(incBtn);
        row.appendChild(name);
        row.appendChild(stepper);
        this.rodBankEl.appendChild(row);

        this._rodFillEls[g.id] = { pctLabel, incBtn, decBtn };
      });
      this._rodBankBuilt = true;
    }

    rodSystem.groups.forEach((g) => {
      const els = this._rodFillEls[g.id];
      els.pctLabel.textContent = `${Math.round(100 - g.position)}%`;
      els.pctLabel.className = 'rod-ctrl-val' + (rodSystem.scramActive ? ' scram' : g.position < 20 ? ' warn' : '');
      // Во время АЗ-5 ручное управление заблокировано (см. control_rods.js) —
      // кнопки визуально неактивны, а не молча ничего не делают. Аналогично —
      // до первого нажатия «Старт» (controlsLocked) органы управления
      // стержнями недоступны: реактор ещё не запущен оператором.
      // "+" теперь вводит стержень (position -> 0) — недоступна, когда уже
      // полностью введён; "−" выводит (position -> 100) — недоступна, когда
      // уже полностью выведен. Соответствует новой подписи "% введено".
      els.incBtn.disabled = controlsLocked || rodSystem.scramActive || g.position <= 0;
      els.decBtn.disabled = controlsLocked || rodSystem.scramActive || g.position >= 100;
    });
  },

  /**
   * Мнемопанель БЩУ: набор плиток-табло, которые в норме приглушены и
   * загораются нужным цветом только когда параметр вышел за допустимый
   * диапазон — не текст для чтения, а состояние "окинул взглядом".
   */
  renderChart(history) {
    const ctx = this.chartCtx;
    const w = this.chartCanvas.width;
    const h = this.chartCanvas.height;
    ctx.clearRect(0, 0, w, h);

    // фон + сетка
    ctx.fillStyle = '#171a1d';
    ctx.fillRect(0, 0, w, h);

    if (history.length < 2) return;

    const tMax = history[history.length - 1].t;
    const tMin = Math.max(0, tMax - 120); // окно 120 секунд
    const visible = history.filter((p) => p.t >= tMin);

    let nMax = 1.5;
    for (const p of visible) if (p.n > nMax) nMax = p.n * 1.1;

    ctx.strokeStyle = '#2f363c';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = (h / 4) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // линия мощности
    ctx.strokeStyle = '#35e08a';
    ctx.lineWidth = 2;
    ctx.beginPath();
    visible.forEach((p, idx) => {
      const x = ((p.t - tMin) / (tMax - tMin || 1)) * w;
      const y = h - (p.n / nMax) * h;
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // подпись оси Y
    ctx.fillStyle = '#9aa4ad';
    ctx.font = '11px ui-monospace, monospace';
    ctx.fillText(`${(nMax * 100).toFixed(0)}%`, 4, 10);
    ctx.fillText('0%', 4, h - 4);
  },

  _drawMultiLineChart(ctx, canvas, series, opts) {
    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#171a1d';
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = '#2f363c';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = (h / 4) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    const allPoints = series.flatMap((s) => s.points);
    if (allPoints.length < 2) return;

    const xMin = opts.xMin !== undefined ? opts.xMin : Math.min(...allPoints.map((p) => p.x));
    const xMax = opts.xMax !== undefined ? opts.xMax : Math.max(...allPoints.map((p) => p.x));
    const yMin = opts.yMin !== undefined ? opts.yMin : 0;
    const yMax = opts.yMax !== undefined ? opts.yMax : Math.max(1, ...allPoints.map((p) => p.y)) * 1.15;

    series.forEach((s) => {
      if (s.points.length < 2) return;
      ctx.strokeStyle = s.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      s.points.forEach((p, idx) => {
        const x = ((p.x - xMin) / (xMax - xMin || 1)) * w;
        const y = h - ((p.y - yMin) / (yMax - yMin || 1)) * h;
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    });

    ctx.fillStyle = '#9aa4ad';
    ctx.font = '11px ui-monospace, monospace';
    const yUnit = opts.yUnit !== undefined ? opts.yUnit : 'β';
    ctx.fillText(`${yMax.toFixed(1)}${yUnit}`, 4, 10);
    ctx.fillText(`${yMin.toFixed(yMin === 0 ? 0 : 1)}${yUnit}`, 4, h - 4);
    // Промежуточные подписи на сетке (75%/50%/25% от диапазона) — без них разные
    // по масштабу линии (напр. Xe и Sm при сильно отличающихся значениях)
    // визуально выглядят "не синхронизированными", хотя данные верны: глазом
    // трудно оценить долю высоты без промежуточных делений на маленьком графике.
    ctx.fillStyle = '#6b7379';
    ctx.font = '9px ui-monospace, monospace';
    for (let i = 1; i <= 3; i++) {
      const y = (h / 4) * i;
      const val = yMax - (yMax - yMin) * (i / 4);
      ctx.fillText(`${val.toFixed(2)}${yUnit}`, 4, y - 2);
    }
    if (opts.xLabel) {
      ctx.fillStyle = '#9aa4ad';
      ctx.font = '11px ui-monospace, monospace';
      ctx.fillText(opts.xLabel, w - ctx.measureText(opts.xLabel).width - 4, h - 4);
    }
  },

  renderPoisonChart(history) {
    if (history.length < 2) return;
    const tMax = history[history.length - 1].t;
    const windowSec = 8 * 3600; // показываем последние 8 часов модельного времени
    const tMin = Math.max(0, tMax - windowSec);
    const visible = history.filter((p) => p.t >= tMin);

    const xeSeries = { points: visible.map((p) => ({ x: p.t, y: p.Xe })), color: '#ff3b30' };
    const pmSeries = { points: visible.map((p) => ({ x: p.t, y: p.Pm })), color: '#ffb020' };
    const smSeries = { points: visible.map((p) => ({ x: p.t, y: p.Sm })), color: '#4fa3d1' };

    this._drawMultiLineChart(this.poisonChartCtx, this.poisonChartCanvas, [xeSeries, pmSeries, smSeries], {
      xMin: tMin,
      xMax: tMax,
      xLabel: 'последние 8ч',
    });
  },

  /**
   * v3.0 §3 — Доплер ρ (всегда отрицателен) и Паровой ρ (может быть и +, и -)
   * на одном графике, в единицах β. В отличие от остальных _drawMultiLineChart
   * потребителей здесь нужен yMin < 0 — используем те же точки, что и
   * renderReactorSecondaryReadouts (kinetics.history, поля dopplerBeta/voidBeta,
   * см. kinetics.js:_pushHistory).
   */
  renderDopplerVoidChart(history) {
    if (!this.dopplerVoidChartCtx || history.length < 2) return;
    const tMax = history[history.length - 1].t;
    const windowSec = 120; // то же окно, что и у графика температуры топлива
    const tMin = Math.max(0, tMax - windowSec);
    const visible = history.filter((p) => p.t >= tMin);

    const dopplerSeries = { points: visible.map((p) => ({ x: p.t, y: p.dopplerBeta })), color: '#8a6fd1' };
    const voidSeries = { points: visible.map((p) => ({ x: p.t, y: p.voidBeta })), color: '#ffb020' };

    const allY = dopplerSeries.points.concat(voidSeries.points).map((p) => p.y);
    const yMin = Math.min(0, ...allY) * 1.15;
    const yMax = Math.max(0.05, ...allY) * 1.15;

    this._drawMultiLineChart(this.dopplerVoidChartCtx, this.dopplerVoidChartCanvas, [dopplerSeries, voidSeries], {
      xMin: tMin,
      xMax: tMax,
      yMin,
      yMax,
      xLabel: 'последние 2 мин',
    });
  },

  renderComposition(comp) {
    const items = [
      { key: 'u235', label: 'U-235', color: '#35e08a' },
      { key: 'u238', label: 'U-238', color: '#3a4147' },
      { key: 'pu239', label: 'Pu-239', color: '#ffb020' },
      { key: 'pu240', label: 'Pu-240', color: '#c97c0a' },
      { key: 'pu241', label: 'Pu-241', color: '#8a5206' },
      { key: 'fp', label: 'Осколки', color: '#4fa3d1' },
    ];
    this.compositionBarEl.innerHTML = items
      .map((it) => `<div class="seg" style="width:${(comp[it.key] * 100).toFixed(2)}%; background:${it.color};" title="${it.label}: ${(comp[it.key] * 100).toFixed(2)}%"></div>`)
      .join('');
    this.compositionLegendEl.innerHTML = items
      .map((it) => `<span><span class="swatch" style="background:${it.color}"></span> ${it.label} ${(comp[it.key] * 100).toFixed(2)}%</span>`)
      .join('');
  },

  renderThermal(history, snap) {
    if (history.length >= 2) {
      const tMax = history[history.length - 1].t;
      const windowSec = 120; // последние 2 минуты модельного времени (совпадает с окном графика мощности)
      const tMin = Math.max(0, tMax - windowSec);
      const visible = history.filter((p) => p.t >= tMin);
      const tFuelSeries = { points: visible.map((p) => ({ x: p.t, y: p.tFuel })), color: '#ff8a3d' };

      this._drawMultiLineChart(this.thermalChartCtx, this.thermalChartCanvas, [tFuelSeries], {
        xMin: tMin,
        xMax: tMax,
        yMax: RBMK_PARAMS.thermal.fuelTempAlarmC * 1.15,
        yUnit: '°C',
        xLabel: 'последние 2 мин',
      });
    }

    const tempSeverity = snap.fuelTemp >= RBMK_PARAMS.thermal.fuelTempAlarmC ? 'alarm' : snap.fuelTemp >= RBMK_PARAMS.thermal.fuelTempCautionC ? 'caution' : 'normal';
    const readouts = [
      { label: 'Топливо', value: `${snap.fuelTemp.toFixed(0)}°C`, severity: tempSeverity },
      {
        label: 'Паросодержание',
        value: `${(snap.voidFraction * 100).toFixed(0)}%`,
        severity: 'normal',
        tooltip:
          'Паросодержание α — доля объёма теплоносителя в канале, занятая паром (0% — однофазная вода, 100% — сухой пар). Растёт с мощностью реактора и напрямую влияет на паровой коэффициент реактивности (см. «Паровой ρ»).',
      },
      {
        label: 'Расход',
        value: `${(snap.coolantFlowFraction * 100).toFixed(0)}%`,
        severity:
          snap.coolantFlowFraction < RBMK_PARAMS.thermal.coolantFlowRiskFraction ? 'alarm' : snap.coolantFlowFraction < 0.6 ? 'caution' : 'normal',
        tooltip:
          'Относительный расход теплоносителя (100% — номинал). Падает только при аварии (отказ ГЦН и т.п.) — это не орган ручного управления. Меньше расход при той же мощности — больше паросодержание при той же мощности (хуже охлаждение). Ниже определённого порога — риск пережога (смена режима теплообмена на паровую плёнку у поверхности твэла).',
      },
    ];
    this.thermalReadoutsEl.innerHTML = readouts
      .map(
        (r) =>
          `<div class="thermal-readout"><span class="label">${r.label}${
            r.tooltip
              ? `<span class="info-icon" tabindex="0">?<span class="info-tooltip">${r.tooltip}</span></span>`
              : ''
          }</span><span class="value ${r.severity}">${r.value}</span></div>`
      )
      .join('');

    this.voidGaugeFillEl.style.width = `${(snap.voidFraction * 100).toFixed(1)}%`;
    this.voidGaugeValEl.textContent = `${(snap.voidFraction * 100).toFixed(0)}%`;
  },

  /**
   * ЖК-табло левой панели (под мнемопанелью): числовые значения Xe-135,
   * Sm-149, температуры топлива и паросодержания — те же данные, что уже
   * идут в график отравления и панель термогидравлики, просто продублированы
   * здесь для считывания одним взглядом рядом с диагностикой. Порог
   * нечувствительности (eps) у каждого параметра соответствует его
   * отображаемой точности — иначе стрелка тренда дёргалась бы от шума
   * младшего разряда, не видимого на самом табло.
   */
  /**
   * Экранирование текста перед вставкой в innerHTML — goalText/hintText/
   * title приходят из пользовательского .scenario.json, а не сгенерированы
   * кодом (в отличие от большинства других render*() в этом файле, где
   * текст собирается самим движком). Минимальная защита от случайно (или
   * намеренно) вставленной разметки в файле сценария.
   */
  _esc(str) {
    if (str === undefined || str === null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  },

  /**
   * v1.17 — панель «Задание сценария». meta=null/goalsState=[] — сценарий не
   * загружен (плейсхолдер). progress не null только у kind:"hold" — там
   * прогресс имеет смысл (доля от durationSec); для остальных kind
   * показываем только текстовый статус.
   */
  renderScenarioPanel(meta, goalsState) {
    if (!this.scenarioTitleEl || !this.scenarioGoalsEl) return;

    if (this.scenarioResetBtnEl) this.scenarioResetBtnEl.disabled = !meta;

    if (this.scenarioDetailsEl) this.scenarioDetailsEl.open = !!meta;
    if (this.scenarioPanelWrapEl) this.scenarioPanelWrapEl.classList.toggle('panel-inactive', !meta);

    if (!meta) {
      this.scenarioTitleEl.textContent = 'Сценарий не загружен';
      this.scenarioGoalsEl.innerHTML = '';
      return;
    }

    this.scenarioTitleEl.innerHTML =
      this._esc(meta.title) +
      (meta.description ? `<span class="scenario-subtitle">${this._esc(meta.description)}</span>` : '');

    // v2.0 — instructions[]: явная, пронумерованная последовательность
    // действий оператора. Присутствует только в УРОКАХ (не в голом
    // сценарии) — это и есть видимая, функциональная разница между
    // "Загрузить сценарий" (состояние+цель) и "Загрузить урок" (сценарий +
    // объяснение, как её достигать), см. LESSON_FORMAT_SPEC.md.
    const instructionsHtml =
      meta.instructions && meta.instructions.length
        ? `<div class="scenario-instructions">
            <div class="scenario-instructions-title">Порядок действий</div>
            <ol class="scenario-instructions-list">${meta.instructions.map((step) => `<li>${this._esc(step)}</li>`).join('')}</ol>
          </div>`
        : '';

    if (!goalsState || goalsState.length === 0) {
      this.scenarioGoalsEl.innerHTML = instructionsHtml + '<div class="scenario-goal-empty">В этом сценарии нет целей — только информационные сообщения в журнале событий.</div>';
      return;
    }

    // v2.0 — sequentialGoals: игровой формат "одна цель за раз" (см.
    // scenario_engine.js). Порядок целей = порядок в goals[] файла —
    // движок это же самое порядок и использует как индекс завершения.
    if (meta.sequentialGoals) {
      this.scenarioGoalsEl.innerHTML = instructionsHtml + this._renderSequentialGoals(goalsState);
      return;
    }

    this.scenarioGoalsEl.innerHTML = instructionsHtml + goalsState.map((g) => this._renderGoalCard(g)).join('');
  },

  /** Полная карточка одной цели — общий markup для обычного и sequential-режима. */
  _renderGoalCard(g) {
    const classes = ['scenario-goal'];
    if (g.completed) classes.push('completed');
    if (g.failed) classes.push('failed'); // guarded-reach: срыв после успеха — отличимо от "ещё не начато"

    const progressHtml =
      g.progress !== null
        ? `<div class="scenario-goal-progress-track"><div class="scenario-goal-progress-fill" style="width:${Math.round(g.progress * 100)}%"></div></div>`
        : '';
    const metaText = g.progress !== null ? `${Math.round(g.progress * 100)}%` : g.completed ? 'выполнено' : g.failed ? 'сорвано' : '';

    // v2.0 — инструкция КОНКРЕТНОЙ цели (goal.instructions), отдельно от
    // общего лесонного instructionsHtml (тот — на весь урок сразу). Только
    // в sequential-режиме это реально используется (см. _renderSequentialGoals).
    const goalInstructionsHtml =
      g.instructions && g.instructions.length
        ? `<div class="scenario-goal-instructions">
            <div class="scenario-instructions-title">Как сделать</div>
            <ol class="scenario-instructions-list">${g.instructions.map((step) => `<li>${this._esc(step)}</li>`).join('')}</ol>
          </div>`
        : '';

    return `<div class="${classes.join(' ')}">
      <div class="scenario-goal-dot"></div>
      <div class="scenario-goal-body">
        <div class="scenario-goal-text" title="${this._esc(g.hintText || '')}">${this._esc(g.goalText || g.title || '')}</div>
        ${goalInstructionsHtml}
        ${progressHtml}
      </div>
      <div class="scenario-goal-meta">${metaText}</div>
    </div>`;
  },

  /** Свёрнутая строка уже пройденной цели (только заголовок + галочка) — история над активной целью. */
  _renderGoalCollapsedDone(g) {
    return `<div class="scenario-goal-collapsed">
      <span class="scenario-goal-collapsed-dot">✓</span>
      <span class="scenario-goal-collapsed-title">${this._esc(g.title || g.goalText || '')}</span>
    </div>`;
  },

  /**
   * v2.0 — рендер "одна цель за раз": уже пройденные цели сворачиваются в
   * короткую историю сверху (без текста цели/инструкции — чтобы не грузить
   * панель), первая невыполненная цель по порядку файла показывается
   * полностью (с её персональной instructions[]), всё, что идёт ПОСЛЕ неё,
   * вообще не рендерится — не спойлерим следующие шаги. Если пройдены
   * ВСЕ цели — вместо активной карточки показывается баннер завершения.
   */
  _renderSequentialGoals(goalsState) {
    const activeIndex = goalsState.findIndex((g) => !g.completed);
    const doneGoals = activeIndex === -1 ? goalsState : goalsState.slice(0, activeIndex);
    const historyHtml = doneGoals.length
      ? `<div class="scenario-goals-history">${doneGoals.map((g) => this._renderGoalCollapsedDone(g)).join('')}</div>`
      : '';

    if (activeIndex === -1) {
      return historyHtml + '<div class="scenario-complete-banner">🎉 Урок пройден — все цели выполнены.</div>';
    }

    return historyHtml + this._renderGoalCard(goalsState[activeIndex]);
  },

  renderCoreReadouts(snap, t) {
    if (!this.coreReadoutsEl) return;

    // v1.7 — Пространственная модель, п.2: осевой перекос ксенона
    // (верх-низ, β). Знак сохраняется (может быть и +, и -) — в отличие от
    // остальных readout'ов этой панели, это НЕ уровень отравления, а именно
    // разница/асимметрия. Severity нарочито не строгая (только caution) —
    // сам по себе перекос не авария, опасен лишь в сочетании с низким ОЗР
    // (см. AGENT_HANDOFF.md) — эту связь показывает диагностика/журнал, а не
    // цвет этого конкретного числа.
    const axialAbs = Math.abs(snap.axialOffsetBeta);
    const axialSeverity = axialAbs >= 2.0 ? 'caution' : '';
    // v2.5 — вторая ось (лево/право): та же логика, что и у осевой версии.
    const azimuthAbs = Math.abs(snap.azimuthOffsetBeta);
    const azimuthSeverity = azimuthAbs >= 2.0 ? 'caution' : '';

    const rows = [
      { key: 'xe', label: 'Xe-135', value: snap.xenonLevel, decimals: 2, unit: 'β', eps: 0.005, severity: '' },
      { key: 'pm', label: 'Pm-149', value: snap.promethiumLevel, decimals: 2, unit: 'β', eps: 0.005, severity: '' },
      { key: 'sm', label: 'Sm-149', value: snap.samariumLevel, decimals: 2, unit: 'β', eps: 0.005, severity: '' },
      // v3.0 §3 — ОЗР, нейтральный LCD без severity (аннунциатор annun-ozr
      // уже сигналит отдельно при падении маржина — решение пользователя:
      // не дублировать цвет на самом числе).
      { key: 'ozr', label: 'ОЗР', value: snap.ozrBeta, decimals: 2, unit: 'β', eps: 0.02, severity: '' },
      { key: 'axial', label: 'Перекос в-н', value: snap.axialOffsetBeta, decimals: 2, unit: 'β', eps: 0.02, severity: axialSeverity, signed: true },
      { key: 'azimuth', label: 'Перекос л-п', value: snap.azimuthOffsetBeta, decimals: 2, unit: 'β', eps: 0.02, severity: azimuthSeverity, signed: true },
    ];

    this.coreReadoutsEl.innerHTML = rows
      .map((r) => {
        const trend = this._trend(r.key, r.value, t, r.eps);
        const valueClass = 'lcd-value' + (r.severity ? ' ' + r.severity : '');
        const displayValue = (r.signed && r.value >= 0 ? '+' : '') + r.value.toFixed(r.decimals);
        return (
          `<div class="core-readout">` +
          `<span class="core-readout-label">${r.label}</span>` +
          `<div class="lcd-screen">` +
          `<span class="${valueClass}">${displayValue}</span>` +
          `<span class="lcd-unit">${r.unit}</span>` +
          `<span class="lcd-trend">${this._trendArrow(trend)}</span>` +
          `</div></div>`
        );
      })
      .join('');
  },

  /**
   * v3.0 §2 — вторая строка индикаторов над графиком мощности: Топливо и
   * Паросодерж перенесены с левой панели (renderCoreReadouts), Доплер ρ и
   * Паровой ρ — с панели термогидравлики (renderThermal). Метка/severity
   * Парового ρ при историчном режиме (см. AGENT_HANDOFF.md, kinetics.js:
   * setVoidMode) сохранены — единственный видимый индикатор доаварийной
   * конфигурации.
   */
  renderReactorSecondaryReadouts(snap, t) {
    if (!this.secondaryReadoutsEl) return;
    const th = RBMK_PARAMS.thermal;
    const tempSeverity = snap.fuelTemp >= th.fuelTempAlarmC ? 'alarm' : snap.fuelTemp >= th.fuelTempCautionC ? 'caution' : '';
    const isHistorical = snap.voidMode === 'historical';
    const voidLabel = isHistorical ? 'Паровой ρ (ДОАВАРИЙНЫЙ РЕЖИМ)' : 'Паровой ρ';
    const voidSeverity = isHistorical ? 'caution' : '';

    const rows = [
      { key: 'tfuel2', label: 'Топливо', noCaps: false, value: snap.fuelTemp, decimals: 0, unit: '°C', eps: 0.5, severity: tempSeverity },
      { key: 'doppler', label: 'Доплер ρ', noCaps: true, value: snap.dopplerReactivityBeta, decimals: 3, unit: 'β', eps: 0.002, severity: '', signed: true },
      { key: 'voidrho', label: voidLabel, noCaps: true, value: snap.voidReactivityBeta, decimals: 3, unit: 'β', eps: 0.002, severity: voidSeverity, signed: true },
      { key: 'void2', label: 'Паросодерж', noCaps: false, value: snap.voidFraction * 100, decimals: 0, unit: '%', eps: 0.5, severity: '' },
    ];

    this.secondaryReadoutsEl.innerHTML = rows
      .map((r) => {
        const trend = this._trend(r.key, r.value, t, r.eps);
        const valueClass = 'lcd-value' + (r.severity ? ' ' + r.severity : '');
        const displayValue = (r.signed && r.value >= 0 ? '+' : '') + r.value.toFixed(r.decimals);
        const capClass = r.noCaps ? ' no-caps' : '';
        return (
          `<div class="readout">` +
          `<span class="readout-label${capClass}">${r.label}</span>` +
          `<div class="lcd-screen">` +
          `<span class="${valueClass}">${displayValue}</span>` +
          `<span class="lcd-unit${capClass}">${r.unit}</span>` +
          `<span class="lcd-trend">${this._trendArrow(trend)}</span>` +
          `</div></div>`
        );
      })
      .join('');
  },
};
