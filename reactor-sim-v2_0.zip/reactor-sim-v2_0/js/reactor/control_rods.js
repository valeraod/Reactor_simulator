// control_rods.js
// Stage 1: упрощённая модель стержней — линейная зависимость worth от положения
// (S-образная кривая эффективности стержня появится в более поздних этапах, если
// потребуется для точности сценариев).
//
// position: 0..100, где 0 = полностью введён (максимальное поглощение),
//                     100 = полностью выведен.
// Начальное положение каждой группы выбрано так, чтобы суммарная ρ от стержней
// в момент старта была равна нулю (реактор стартует в критическом состоянии).

class ControlRodSystem {
  constructor(params) {
    this.params = params;
    this.betaTotal = params.betaEff;
    this.initialPositionPct = 50;

    this.groups = params.rodGroups.map((g) => ({
      id: g.id,
      label: g.label,
      maxWorthBeta: g.maxWorthBeta,
      zone: g.zone, // 'top' | 'bottom' — см. AGENT_HANDOFF.md, "Пространственная модель"
      position: this.initialPositionPct, // %
      targetPosition: this.initialPositionPct,
    }));

    this.scramActive = false;
    this.scramInsertionRate = params.scramInsertionRate; // доля хода/с
  }

  setGroupPosition(id, pct) {
    if (this.scramActive) return; // во время АЗ-5 ручное управление заблокировано
    const g = this.groups.find((x) => x.id === id);
    if (!g) return;
    g.targetPosition = Math.max(0, Math.min(100, pct));
    g.position = g.targetPosition; // Stage 1: мгновенная реакция слайдера
  }

  scram() {
    this.scramActive = true;
  }

  /**
   * Снимает блокировку АЗ-5 и возвращает ручное управление стержнями,
   * НЕ трогая при этом мощность/яды/наработку (в отличие от reset()).
   * Стержни остаются там, где их оставила защита (как правило — введены);
   * дальше оператор поднимает их вручную слайдерами.
   */
  releaseScram() {
    this.scramActive = false;
    this.groups.forEach((g) => {
      g.targetPosition = g.position; // не допускаем скачка при следующем setGroupPosition
    });
  }

  /** @param {number} [positionPct] - Горячий старт: initialPositionPct (50%, по умолчанию). Холодный старт: 0 (полностью введены) */
  reset(positionPct = this.initialPositionPct) {
    this.scramActive = false;
    this.groups.forEach((g) => {
      g.position = positionPct;
      g.targetPosition = positionPct;
    });
  }

  /** Снапшот состояния для сохранения/выгрузки (загрузка сценария) */
  getState() {
    const positions = {};
    this.groups.forEach((g) => {
      positions[g.id] = g.position;
    });
    return { positions, scramActive: this.scramActive };
  }

  loadState(saved) {
    if (!saved || typeof saved.positions !== 'object') {
      throw new Error('rods.loadState: отсутствует positions');
    }
    // v1.7: файлы, сохранённые ДО добавления группы УСП (v1.6 и раньше), не
    // содержат её позицию — это не повреждённый файл, а старый формат.
    // Раньше здесь была жёсткая проверка "нет позиции — ошибка" для ЛЮБОЙ
    // группы; теперь отсутствующая группа просто встаёт в initialPositionPct
    // (50%, как при обычном старте), а не роняет всю загрузку. Причины,
    // из-за которых это оправдано именно как fallback, а не ошибка: (а) это
    // единственная группа, которая могла отсутствовать по историческим, а не
    // случайным причинам, (б) 50% — safe-значение, ничего не подкручивает.
    for (const g of this.groups) {
      if (!(g.id in saved.positions) && g.id !== 'usp') {
        throw new Error(`rods.loadState: нет позиции для группы "${g.id}" в файле`);
      }
    }
    this.scramActive = !!saved.scramActive;
    this.groups.forEach((g) => {
      const raw = g.id in saved.positions ? Number(saved.positions[g.id]) : this.initialPositionPct;
      const pct = Math.max(0, Math.min(100, raw));
      g.position = pct;
      g.targetPosition = pct;
    });
  }

  update(dt) {
    if (this.scramActive) {
      const stepPct = this.scramInsertionRate * 100 * dt;
      this.groups.forEach((g) => {
        g.position = Math.max(0, g.position - stepPct);
      });
    }
  }

  /**
   * Концевой эффект (см. AGENT_HANDOFF.md, "Пространственная модель
   * активной зоны", п.3) — грубая версия, без честной привязки к геометрии
   * зон/вытеснителя. Положительный "зубец" реактивности на первых
   * endEffect.widthPct% хода группы от полностью выведенного положения
   * (position=100). Функция от АБСОЛЮТНОГО положения группы, не от
   * начальной (критической) точки — физически зубец там, где вытеснитель
   * начинает выходить из активной зоны, независимо от того, где стержень
   * стоял на старте сессии.
   *
   * Форма — сглаженный импульс sin²(π·x), а не треугольник: значение И
   * производная равны нулю на обеих границах (x=0 и x=1), поэтому "зубец"
   * плавно сливается с базовой линейной кривой без излома — в отличие от
   * треугольника, у которого производная терпит разрыв в трёх точках
   * (вершина + два стыка с базовой кривой). Симметрична по направлению
   * движения (не зависит от знака dposition/dt — только от текущего
   * положения) — сознательное упрощение, гистерезис не моделируется.
   */
  _endEffectBeta(g) {
    const cfg = this.params.endEffect;
    if (!cfg) return 0;
    const depthPct = 100 - g.position; // 0 = полностью выведен, растёт при вводе
    if (depthPct <= 0 || depthPct >= cfg.widthPct) return 0;
    const x = depthPct / cfg.widthPct; // (0, 1)
    const bump = Math.sin(Math.PI * x);
    return cfg.amplitudeBeta * bump * bump; // всегда >= 0
  }

  /**
   * Суммарный вклад стержней в реактивность (абсолютные единицы, dk/k),
   * относительно начального (критического) положения. С v1.7 включает
   * концевой эффект (см. _endEffectBeta) — при обычных положениях
   * (вдали от полностью выведенного) вклад строго нулевой, поведение
   * идентично более ранним версиям.
   */
  getReactivity() {
    let rho = 0;
    for (const g of this.groups) {
      const deltaFraction = (g.position - this.initialPositionPct) / 100;
      rho += g.maxWorthBeta * this.betaTotal * deltaFraction;
      rho += this._endEffectBeta(g) * this.betaTotal;
    }
    return rho;
  }

  /**
   * Локальная доля потока верх/низ (см. AGENT_HANDOFF.md, п.2) —
   * стилизованная, НЕ честная диффузия. Зависит от относительного
   * рассогласования среднего положения групп "верх" и УСП ("низ"):
   * если УСП выведен больше (относительно) верхних групп — поглощение
   * внизу меньше, локальный поток смещается вниз, и наоборот.
   *
   * При точной симметрии (posBottom === posTop) возвращает ровно {top:0.5,
   * bottom:0.5} — это и есть условие "спящей" новой части: при frac=0.5
   * локальная мощность зоны (см. main.js, getPower для зонных FastPoisons)
   * равна 2·n·0.5 = n, т.е. ТОЧНО совпадает с тем, что видела бы одна
   * общая (без зон) модель — требование регрессии выполнено по построению,
   * а не приближённо.
   */
  getZonePowerFractions() {
    const cfg = this.params.spatial;
    const topGroups = this.groups.filter((g) => g.zone === 'top');
    const bottomGroups = this.groups.filter((g) => g.zone === 'bottom');
    const avgPos = (arr) => (arr.length ? arr.reduce((s, g) => s + g.position, 0) / arr.length : this.initialPositionPct);
    const posTop = avgPos(topGroups);
    const posBottom = avgPos(bottomGroups);
    let fracBottom = 0.5 + (cfg ? cfg.zoneFluxSensitivity : 0) * ((posBottom - posTop) / 100);
    fracBottom = Math.max(0, Math.min(1, fracBottom));
    return { top: 1 - fracBottom, bottom: fracBottom };
  }

  isFullyInserted() {
    return this.groups.every((g) => g.position < 0.5);
  }

  /**
   * ОЗР — оперативный запас реактивности (β), НЕ физика, чисто расчётная
   * диагностическая величина (см. AGENT_HANDOFF.md, раздел "Пространственная
   * модель активной зоны"). Определение (проверено отдельно, важно не
   * перепутать знак): ОЗР — это положительная реактивность, которую реактор
   * имел бы при полностью ИЗВЛЕЧЁННЫХ стержнях СУЗ, т.е. количество
   * реактивности, сейчас УДЕРЖИВАЕМОЕ вводом стержней. Поэтому считается от
   * "введённой" доли положения (не от "выведенной"!) — низкий ОЗР означает,
   * что стержни уже почти все выведены, значит удерживать почти нечего.
   * Именно так реактор оказывается уязвим: мало введённых стержней → мало
   * компенсирующей отрицательной реактивности "под рукой" → при АЗ-5 разом
   * срабатывает концевой эффект у большинства групп, которым нечем
   * компенсироваться.
   */
  getOperationalMargin() {
    let margin = 0;
    for (const g of this.groups) {
      const insertedFraction = (100 - g.position) / 100; // 0 = выведен, 1 = введён
      margin += g.maxWorthBeta * insertedFraction;
    }
    return margin;
  }

  /** Максимально возможный ОЗР (все группы введены на 100%) — знаменатель для доли/% на табло. */
  getMaxOperationalMargin() {
    return this.groups.reduce((sum, g) => sum + g.maxWorthBeta, 0);
  }
}
