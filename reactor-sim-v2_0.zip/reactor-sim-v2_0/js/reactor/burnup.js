// burnup.js
// Медленная группа (U-235 выгорание, наработка Pu-239/240/241, осколки).
// СТИЛИЗОВАННАЯ модель на основе накопленной наработки в EFPD (эффективные
// сутки на полной мощности) — не претендует на точность расчёта выгорания
// конкретной топливной загрузки, но качественно верно показывает:
//  - монотонное снижение U-235 по мере кампании
//  - насыщающееся накопление Pu-239 (и медленнее — Pu-240/241)
//  - результирующий эффект на реактивность (выгорание тянет вниз, наработка
//    Pu частично компенсирует — операторам приходится постепенно выводить
//    стержни по мере кампании, что и моделируется через ρ_burnup(t))
//
// Два режима:
//  'fixed'       — возраст топлива задаётся пресетом (свежее/середина/конец
//                   кампании) и НЕ меняется во время сессии
//  'accelerated' — burnupEFPD растёт физически корректно: dEFPD = n(t)*dt/86400
//                   (86400 с = 1 сутки). Скорость прохождения кампании в
//                   реальном времени теперь регулируется ОБЩИМ ускорением
//                   времени модели (см. main.js, simSpeed) — единым для
//                   кинетики, Xe/Sm и наработки, а не отдельным множителем.

class BurnupModel {
  /**
   * @param {object} params - ISOTOPE_PARAMS.slow
   * @param {() => number} getPower - функция, возвращающая текущее n (power/n0)
   * @param {number} betaTotal
   */
  constructor(params, getPower, betaTotal) {
    this.params = params;
    this.getPower = getPower;
    this.betaTotal = betaTotal;

    this.mode = 'fixed'; // 'fixed' | 'accelerated'
    this.burnupEFPD = params.presets.fresh;

    // Иллюстративные начальные массовые доли (не претендуют на конкретную
    // марку топлива РБМК) — используются только для отображения состава
    this.initialU235Fraction = 0.028; // ~2.8% обогащение (иллюстративно)
    this.initialU238Fraction = 1 - this.initialU235Fraction;
    this.pu239MaxFraction = 0.010;
    this.pu240MaxFraction = 0.003;
    this.pu241MaxFraction = 0.0015;
    this.fpMaxFraction = 0.022; // иллюстративная доля накопленных осколков к концу кампании

    this.history = [];
    this.historyMaxPoints = 600;
    this._pushHistory();
  }

  setMode(mode) {
    this.mode = mode;
  }

  setPreset(name) {
    if (this.params.presets[name] !== undefined) {
      this.burnupEFPD = this.params.presets[name];
    }
  }

  /**
   * @param {number} dt - шаг МОДЕЛЬНОГО времени в секундах (уже с учётом
   *   общего ускорения симуляции — см. main.js)
   */
  update(dt) {
    if (this.mode === 'accelerated') {
      const n = this.getPower();
      this.burnupEFPD += (Math.max(0, n) * dt) / 86400; // 86400 с = 1 сутки
      this._maybeSampleHistory();
    }
  }

  _pushHistory() {
    this.history.push({ efpd: this.burnupEFPD, comp: this.getComposition() });
    if (this.history.length > this.historyMaxPoints) this.history.shift();
  }

  _maybeSampleHistory() {
    // сэмплируем по накопленной наработке, а не по реальному времени —
    // иначе в fixed-режиме график был бы бессмысленным
    const lastEfpd = this.history.length ? this.history[this.history.length - 1].efpd : -Infinity;
    if (this.burnupEFPD - lastEfpd >= 1.0) this._pushHistory();
  }

  get u235Fraction() {
    return Math.exp(-this.burnupEFPD / this.params.charBurnupU235);
  }
  get pu239Fraction() {
    return 1 - Math.exp(-this.burnupEFPD / this.params.charBurnupPu239);
  }
  get pu240Fraction() {
    return 1 - Math.exp(-this.burnupEFPD / this.params.charBurnupPu240);
  }
  get pu241Fraction() {
    return 1 - Math.exp(-this.burnupEFPD / this.params.charBurnupPu241);
  }

  /** Массовые доли изотопов (иллюстративные, сумма примерно постоянна) */
  getComposition() {
    const u235 = this.initialU235Fraction * this.u235Fraction;
    const pu239 = this.pu239MaxFraction * this.pu239Fraction;
    const pu240 = this.pu240MaxFraction * this.pu240Fraction;
    const pu241 = this.pu241MaxFraction * this.pu241Fraction;
    const fp = this.fpMaxFraction * (1 - this.u235Fraction);
    const u238 = this.initialU238Fraction - pu239 - pu240 - pu241; // грубый баланс массы
    return { u235, u238, pu239, pu240, pu241, fp };
  }

  /** Вклад в реактивность (абсолютные единицы, dk/k) */
  getReactivity() {
    const depletionEffect = this.params.depletionWorthBeta * (1 - this.u235Fraction);
    const breedingEffect = this.params.breedingWorthBeta * this.pu239Fraction;
    return (depletionEffect + breedingEffect) * this.betaTotal;
  }

  /**
   * Очищает только график наработки — используется Горячим/Холодным стартом.
   * НЕ трогает burnupEFPD/mode: топливная кампания — независимая настройка,
   * которую сброс состояния реактора менять не должен (согласовано отдельно:
   * холодный старт должен уметь стартовать и на частично выгоревшем топливе).
   */
  clearHistory() {
    this.history = [];
    this._pushHistory();
  }

  reset() {
    this.burnupEFPD = this.params.presets.fresh;
    this.history = [];
    this._pushHistory();
  }

  /** Снапшот состояния для сохранения/выгрузки (загрузка сценария) */
  getState() {
    return { burnupEFPD: this.burnupEFPD, mode: this.mode };
  }

  loadState(saved) {
    if (!saved || typeof saved.burnupEFPD !== 'number') {
      throw new Error('burnup.loadState: отсутствует burnupEFPD');
    }
    this.burnupEFPD = Math.max(0, saved.burnupEFPD);
    this.mode = saved.mode === 'accelerated' ? 'accelerated' : 'fixed';
    this.history = [];
    this._pushHistory();
  }
}

