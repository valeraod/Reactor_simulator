// kinetics.js
// Точечная кинетика реактора + Stage 3: термогидравлическая обратная связь.
//
// Уравнения (стандартная система точечной кинетики):
//   dn/dt   = (ρ(t) - β) / Λ * n + Σ λ_i * C_i
//   dC_i/dt = (β_i / Λ) * n - λ_i * C_i
//
// n нормирована относительно номинальной мощности (n=1 соответствует n0).
// ρ_внешняя (стержни + Xe + Sm + выгорание + запас) приходит снаружи через
// getReactivity(); к ней здесь ДОБАВЛЯЕТСЯ доплеровская и паровая обратная
// связь, посчитанные от собственного состояния T_fuel — поэтому T_fuel войдёт
// в тот же вектор состояния ОДУ и тот же (быстрый, 0.01с) шаг RK4, что и n/Ci:
// доплер обязан реагировать в темпе кинетики, а не отдельным медленным тиком
// (иначе он не успеет остановить быстрый разгон — см. AGENT_HANDOFF.md,
// находка при тестировании v0.5).
//
//   dT_fuel/dt = (T_eq(n) − T_fuel) / τ_fuel,   T_eq(n) = T_coolant0 + n·ΔT_full
//   ρ_доплер   = −k_doppler·(T_fuel − T_fuel0)   (всегда ≤ 0)
//   ρ_паровой  = +k_void·(α(n) − α(n=1))          (относительно номинала;
//                может быть и отрицательным ниже номинальной мощности)
// Линейная релаксация T_fuel к n-зависимой цели — намеренно ЛИНЕЙНА (не
// билинейна, как было в isotopes.js с Xe/Sm), чтобы не повторить прошлую
// численную нестабильность: при любом ограниченном n температура топлива
// тоже гарантированно ограничена, без отдельного клэмпа.

class PointKinetics {
  /**
   * @param {object} params - RBMK_PARAMS
   * @param {() => number} getReactivity - функция, возвращающая ВНЕШНЮЮ ρ
   *   (стержни + Xe + Sm + выгорание + запас, БЕЗ доплера/парового эффекта —
   *   те считаются здесь же, внутри, от T_fuel)
   * @param {'modern'|'historical'} [voidMode='modern'] - режим парового коэффициента
   */
  constructor(params, getReactivity, voidMode = 'modern') {
    this.params = params;
    this.getReactivity = getReactivity;
    this.Lambda = params.promptNeutronLifetime;
    this.groups = params.delayedGroups;
    this.betaTotal = params.betaEff;
    this.thermal = params.thermal;
    this.voidMode = voidMode;
    this.n = 1 + this.groups.length + 1; // +1 — T_fuel в конце вектора состояния
    this.tFuelIdx = this.n - 1;

    // Начальное стационарное состояние: n=1, C_i = (beta_i / (Lambda * lambda_i)) * n,
    // T_fuel = T_eq(1) (реактор стартует "в работе давно", тепловое равновесие уже установлено)
    const n0 = 1.0;
    this.state = new Array(this.n);
    this.fuelTemp0 = this.thermal.coolantTemp0 + n0 * this.thermal.deltaTFullPower;
    // Паровой эффект тоже отсчитывается от номинала (n=1), а не от нуля —
    // иначе встроенное при n=1 паросодержание давало бы постоянную добавку
    // сверх калибровки designExcessReactivity (которая учитывает только
    // равновесные Xe/Sm) — реактор стартовал бы уже надкритичным. Так же, как
    // T_fuel0 для доплера. Это ФИКСИРОВАННАЯ точка отсчёта калибровки — не
    // пересчитывается при Холодном/Горячем старте (initState), только
    // начальное состояние меняется.
    this.voidFraction0 = Math.min(1, Math.max(0, n0 * this.thermal.voidFractionAtNominal));

    // Защита от численного переполнения при экстремальном разгоне без обратных
    // связей (Stage 1 ещё не имеет Doppler/парового ограничения мощности) —
    // без этой границы n может уйти в Infinity, а дальше вся арифметика
    // необратимо превращается в NaN даже после SCRAM.
    this.maxPower = 1e9; // 1e9 * n0 — заведомо превышает любой физичный сценарий
    this.maxFuelTempC = 5000; // °C, с большим запасом выше точки плавления UO2 (~2865°C) — свой потолок, не maxPower

    // Переиспользуемые буферы для RK4 — считать точечную кинетику приходится
    // очень много раз за кадр (жёсткая система требует шаг 0.01с даже при
    // сильном ускорении времени модели), поэтому аллокация нового массива на
    // каждый вызов (как было раньше, через spread-оператор) заметно грузила
    // GC и давала до ~400мс на кадр при ×3600. Здесь всё считается в
    // переиспользуемые буферы без единой аллокации в горячем цикле.
    this._k1 = new Array(this.n);
    this._k2 = new Array(this.n);
    this._k3 = new Array(this.n);
    this._k4 = new Array(this.n);
    this._s = new Array(this.n);
    this._next = new Array(this.n);

    // История для графика (время, мощность)
    this.history = [];
    this.historyMaxPoints = 1200;
    this.historySampleEvery = 0.1; // с
    this._lastSampleT = 0;

    this.initState(n0, this.fuelTemp0);
  }

  /**
   * Задаёт начальное состояние (используется конструктором, "Горячим" и
   * "Холодным" стартом — main.js). C_i всегда выставляются в стационар,
   * согласованный с n0 (иначе запаздывающие нейтроны не будут соответствовать
   * потоку, и период в первые секунды будет считаться неверно).
   * @param {number} n0 - начальная относительная мощность (для холодного
   *   старта — не буквальный 0, а RBMK_PARAMS.coldStartSourceN0: при n=0 и
   *   Ci=0 dn/dt тождественно равно нулю, и реактору не из чего разгоняться,
   *   сколько стержни ни выводи — нужен условный источник нейтронов)
   * @param {number} tFuel0 - начальная температура топлива, °C
   */
  initState(n0, tFuel0) {
    this.state[0] = n0;
    for (let i = 0; i < this.groups.length; i++) {
      const g = this.groups[i];
      this.state[1 + i] = (g.beta / (this.Lambda * g.lambda)) * n0;
    }
    this.state[this.tFuelIdx] = tFuel0;
    this.t = 0;
    this.history = [];
    this._lastSampleT = 0;
    this._pushHistory();
  }

  /** Снапшот состояния для сохранения/выгрузки (загрузка сценария) */
  getState() {
    return { state: this.state.slice(), t: this.t };
  }

  /**
   * Восстанавливает ТОЧНЫЙ вектор состояния (в отличие от initState, который
   * пересчитывает Ci как стационар для заданного n0 — при загрузке сохранённого
   * сценария Ci могут быть посреди переходного процесса, не в стационаре, и
   * пересчитывать их было бы неверно). fuelTemp0/voidFraction0 (калибровочные
   * константы) не трогаются — они всегда считаются от номинала n=1, не от
   * текущего состояния.
   */
  loadState(saved) {
    if (!saved || !Array.isArray(saved.state) || saved.state.length !== this.n) {
      throw new Error(`kinetics.loadState: ожидался вектор длины ${this.n}, получено ${saved && saved.state ? saved.state.length : 'null'}`);
    }
    this.state = saved.state.slice();
    this.t = typeof saved.t === 'number' ? saved.t : 0;
    this.history = [];
    this._lastSampleT = this.t;
    this._pushHistory();
  }

  /** Считает производные состояния `state` в момент t и пишет их в `out` (без аллокаций) */
  _derivativeInto(state, out) {
    const n = state[0];
    const Tfuel = state[this.tFuelIdx];
    const th = this.thermal;

    // Доплеровская (топливо, лаг через T_fuel) и паровая (квазимгновенная
    // функция мощности, см. header) обратные связи — складываются с внешней
    // реактивностью (стержни/Xe/Sm/выгорание/запас) здесь, а не снаружи.
    const rhoDopplerBeta = -th.dopplerWorthBeta * ((Tfuel - this.fuelTemp0) / th.deltaTFullPower);
    const voidFraction = Math.min(1, Math.max(0, n * th.voidFractionAtNominal));
    const rhoVoidBeta = th.voidWorthBeta[this.voidMode] * (voidFraction - this.voidFraction0);
    const rho = this.getReactivity() + (rhoDopplerBeta + rhoVoidBeta) * this.betaTotal;

    const beta = this.betaTotal;
    const Lambda = this.Lambda;
    const groups = this.groups;

    let delayedSource = 0;
    for (let i = 0; i < groups.length; i++) {
      const Ci = state[1 + i];
      const g = groups[i];
      const dCi = (g.beta / Lambda) * n - g.lambda * Ci;
      out[1 + i] = dCi;
      delayedSource += g.lambda * Ci;
    }
    out[0] = ((rho - beta) / Lambda) * n + delayedSource;

    const Teq = th.coolantTemp0 + n * th.deltaTFullPower;
    out[this.tFuelIdx] = (Teq - Tfuel) / th.fuelTimeConstant;
  }

  /** Один шаг RK4 длиной h, работает поверх this.state, пишет результат в this._next */
  _rk4SubStep(h) {
    const state = this.state;
    const k1 = this._k1,
      k2 = this._k2,
      k3 = this._k3,
      k4 = this._k4,
      s = this._s,
      next = this._next;
    const len = this.n;

    this._derivativeInto(state, k1);
    for (let i = 0; i < len; i++) s[i] = state[i] + (h / 2) * k1[i];

    this._derivativeInto(s, k2);
    for (let i = 0; i < len; i++) s[i] = state[i] + (h / 2) * k2[i];

    this._derivativeInto(s, k3);
    for (let i = 0; i < len; i++) s[i] = state[i] + h * k3[i];

    this._derivativeInto(s, k4);
    for (let i = 0; i < len; i++) {
      next[i] = state[i] + (h / 6) * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]);
    }
  }

  /**
   * Продвинуть модель на dt секунд (может быть вызвано несколько раз за кадр
   * с малым внутренним шагом для устойчивости RK4).
   */
  step(dt) {
    // Шаг фиксирован намеренно: эксперимент с адаптивным (крупным) подшагом
    // при больших dt показал числовой дрейф, который на резких переходных
    // процессах усиливался до качественно неверного результата (см.
    // AGENT_HANDOFF.md). Жёсткость системы (Λ~1e-3с) требует мелкого шага
    // всегда. Производительность при большом ускорении времени решается не
    // укрупнением шага, а быстрым решателем без аллокаций (см. выше).
    const maxSubStep = 0.01;
    let remaining = dt;
    while (remaining > 1e-9) {
      const h = Math.min(maxSubStep, remaining);
      this._rk4SubStep(h);
      // Защита от нефизичных отрицательных значений и от переполнения (см.
      // комментарий про maxPower в конструкторе) — держим состояние в разумных
      // границах, чтобы SCRAM всегда мог вернуть реактор к управляемому виду.
      // T_fuel (последний элемент) — физически другая величина (°C, не n/Ci) и
      // не должна клэмпиться тем же потолком maxPower=1e9 (иначе NaN/выброс в
      // T_fuel замораживался бы на "миллиарде градусов", что затем ломает
      // доплеровскую ОС и приводило к пропадающей стрелке индикатора — баг,
      // найденный при тестировании v0.6). У T_fuel свой, физически осмысленный
      // потолок — с большим запасом выше точки плавления UO2 (~2865°C).
      for (let i = 0; i < this.n; i++) {
        let v = this._next[i];
        const ceiling = i === this.tFuelIdx ? this.maxFuelTempC : this.maxPower;
        if (!isFinite(v) || v > ceiling) v = ceiling;
        if (v < 0) v = 0;
        this.state[i] = v;
      }
      this.t += h;
      remaining -= h;
    }
    this._maybeSampleHistory();
  }

  _pushHistory() {
    this.history.push({ t: this.t, n: this.state[0], tFuel: this.state[this.tFuelIdx] });
    if (this.history.length > this.historyMaxPoints) this.history.shift();
  }

  _maybeSampleHistory() {
    if (this.t - this._lastSampleT >= this.historySampleEvery) {
      this._lastSampleT = this.t;
      this._pushHistory();
    }
  }

  get power() {
    return this.state[0]; // относительная мощность n/n0
  }

  get powerMWt() {
    return this.power * this.params.nominalPowerMWt;
  }

  get fuelTemp() {
    return this.state[this.tFuelIdx];
  }

  get voidFraction() {
    return Math.min(1, Math.max(0, this.power * this.thermal.voidFractionAtNominal));
  }

  /** Вклад доплер-эффекта в реактивность, в единицах β (всегда ≤ 0) */
  get dopplerReactivityBeta() {
    return -this.thermal.dopplerWorthBeta * ((this.fuelTemp - this.fuelTemp0) / this.thermal.deltaTFullPower);
  }

  /** Вклад парового эффекта в реактивность, в единицах β (относительно номинала n=1, может быть и отрицательным при n<1) */
  get voidReactivityBeta() {
    return this.thermal.voidWorthBeta[this.voidMode] * (this.voidFraction - this.voidFraction0);
  }

  /**
   * Реакторный период (время e-кратного изменения мощности), приблизительно,
   * по мгновенной логарифмической производной. Возвращает Infinity при n~const.
   */
  get period() {
    this._derivativeInto(this.state, this._k1); // переиспользуем буфер как scratch
    const dn = this._k1[0];
    const n = this.state[0];
    if (Math.abs(dn) < 1e-12 || n < 1e-12) return Infinity;
    return n / dn;
  }

  /** Горячий старт: n=1 (реактор "уже работает"), T_fuel = равновесная при n=1 */
  reset() {
    this.initState(1.0, this.fuelTemp0);
  }
}
