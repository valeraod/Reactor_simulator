// isotopes.js
// Быстрая группа изотопов-отравителей: I-135 -> Xe-135, Pm-149 -> Sm-149.
// Всегда интегрируется в реальном времени (в отличие от медленной группы
// выгорания/наработки — см. burnup.js), т.к. эти процессы разворачиваются
// за часы, что укладывается в масштаб одной учебной сессии.
//
// Состояние: [I, Xe, Pm, Sm] — I и Pm в промежуточных ("модельных") единицах,
// Xe и Sm — НАПРЯМУЮ в единицах эквивалентной отрицательной реактивности (β),
// это упрощение позволяет не тащить отдельно микроскопические сечения/поток.

class FastPoisons {
  /**
   * @param {object} params - ISOTOPE_PARAMS.fast
   * @param {() => number} getPower - функция, возвращающая текущее n (power/n0)
   * @param {number} betaTotal - суммарная доля запаздывающих нейтронов (для перевода в абс. ед. ρ)
   */
  constructor(params, getPower, betaTotal) {
    this.params = params;
    this.getPower = getPower;
    this.betaTotal = betaTotal;

    // Стационарные начальные условия при n=1 (реактор стартует "в работе давно")
    const { lambdaI135, lambdaXe135, lambdaPm149, yieldI135, yieldXe135Direct, yieldPm149, xeBurnRateAtN1, smBurnRateAtN1 } = params;

    const I_eq = yieldI135 / lambdaI135;
    const Xe_eq = (yieldXe135Direct + lambdaI135 * I_eq) / (lambdaXe135 + xeBurnRateAtN1);
    const Pm_eq = yieldPm149 / lambdaPm149;
    const Sm_eq = (lambdaPm149 * Pm_eq) / smBurnRateAtN1;

    this.state = [I_eq, Xe_eq, Pm_eq, Sm_eq];
    this.equilibrium = { I: I_eq, Xe: Xe_eq, Pm: Pm_eq, Sm: Sm_eq };
    this.t = 0;

    this.history = [];
    this.historyMaxPoints = 3000;
    this.historySampleEvery = 10; // с — окно ~8.3 часа при 3000 точках; этого хватает
    // чтобы увидеть начало формирования йодной ямы, но не весь цикл (см.
    // AGENT_HANDOFF.md — без общего ускорения времени полный цикл (~30ч)
    // в реальном времени не поместится в разумную сессию наблюдения
    this._lastSampleT = 0;
    this._pushHistory();
  }

  _derivative(state, t) {
    const [I, Xe, Pm, Sm] = state;
    const n = this.getPower();
    const p = this.params;

    const dI = p.yieldI135 * n - p.lambdaI135 * I;
    const dXe = p.yieldXe135Direct * n + p.lambdaI135 * I - p.lambdaXe135 * Xe - p.xeBurnRateAtN1 * n * Xe;
    const dPm = p.yieldPm149 * n - p.lambdaPm149 * Pm;
    const dSm = p.lambdaPm149 * Pm - p.smBurnRateAtN1 * n * Sm;

    return [dI, dXe, dPm, dSm];
  }

  step(dt) {
    const maxSubStep = 2.0; // с — процессы медленные (часы), крупный шаг безопасен
    let remaining = dt;
    while (remaining > 1e-6) {
      const h = Math.min(maxSubStep, remaining);
      this.state = RK4Solver.step(this.state, this.t, h, this._derivative.bind(this));
      for (let i = 0; i < this.state.length; i++) {
        if (!isFinite(this.state[i]) || this.state[i] < 0) this.state[i] = 0;
      }
      this.t += h;
      remaining -= h;
    }
    this._maybeSampleHistory();
  }

  _pushHistory() {
    this.history.push({ t: this.t, I: this.state[0], Xe: this.state[1], Pm: this.state[2], Sm: this.state[3] });
    if (this.history.length > this.historyMaxPoints) this.history.shift();
  }

  _maybeSampleHistory() {
    if (this.t - this._lastSampleT >= this.historySampleEvery) {
      this._lastSampleT = this.t;
      this._pushHistory();
    }
  }

  get xenonLevel() { return this.state[1]; } // β, положительная величина (магнитуда отравления)
  get promethiumLevel() { return this.state[2]; } // β-экв. будущего Sm-149 — ещё не распался, но распадётся 1:1
  get samariumLevel() { return this.state[3]; }

  /** Вклад в реактивность (абсолютные единицы, dk/k), всегда <= 0 */
  getXenonReactivity() {
    return -this.state[1] * this.betaTotal;
  }

  getSamariumReactivity() {
    return -this.state[3] * this.betaTotal;
  }

  /**
   * @param {boolean} [toZero=false] - false: Горячий старт (равновесие при n=1,
   *   как сейчас). true: Холодный старт — топливо ещё не работало, ядов нет
   *   вообще (не путать с "недавно заглушен" — там был бы Xe от йодной ямы,
   *   это отдельный третий вариант пуска, задел на Stage 5)
   */
  reset(toZero = false) {
    this.state = toZero ? [0, 0, 0, 0] : [this.equilibrium.I, this.equilibrium.Xe, this.equilibrium.Pm, this.equilibrium.Sm];
    this.t = 0;
    this.history = [];
    this._lastSampleT = 0;
    this._pushHistory();
  }

  /** Снапшот состояния для сохранения/выгрузки (загрузка сценария) */
  getState() {
    return { state: this.state.slice(), t: this.t };
  }

  loadState(saved) {
    if (!saved || !Array.isArray(saved.state) || saved.state.length !== 4) {
      throw new Error(`isotopes.loadState: ожидался вектор длины 4, получено ${saved && saved.state ? saved.state.length : 'null'}`);
    }
    this.state = saved.state.slice();
    this.t = typeof saved.t === 'number' ? saved.t : 0;
    this.history = [];
    this._lastSampleT = this.t;
    this._pushHistory();
  }
}
