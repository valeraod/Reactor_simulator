// condition_lang.test.js — запуск: node js/core/condition_lang.test.js
// Изолированные проверки языка условий, без UI и без остального движка.

const assert = require('assert');
const { resolveField, evaluateCondition } = require('./condition_lang.js');

function makeSnapshot(overrides = {}) {
  return Object.assign({
    power: 0.5,
    rhoBeta: 0.0,
    period: null,
    xenonLevel: 3.0,
    fuelTemp: 750,
    scramActive: false,
    rodGroups: [
      { id: 'group1', label: 'Группа 1', position: 40 },
      { id: 'group2', label: 'Группа 2', position: 40 },
      { id: 'group3', label: 'Группа 3', position: 40 },
      { id: 'usp', label: 'УСП', position: 0 },
    ],
  }, overrides);
}

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`OK   ${name}`);
  } catch (e) {
    console.log(`FAIL ${name}`);
    console.log('     ' + e.message);
    process.exitCode = 1;
  }
}

// 1. Простое поле верхнего уровня
test('resolveField: простое поле (power)', () => {
  assert.strictEqual(resolveField(makeSnapshot(), 'power'), 0.5);
});

// 2. Правильный id группы (group1..3, usp) резолвится через массив
test('resolveField: rodGroups.usp.position резолвится по id из массива', () => {
  const snap = makeSnapshot({ rodGroups: [
    { id: 'group1', position: 10 },
    { id: 'usp', position: 77 },
  ] });
  assert.strictEqual(resolveField(snap, 'rodGroups.usp.position'), 77);
  assert.strictEqual(resolveField(snap, 'rodGroups.group1.position'), 10);
});

// 3. РЕГРЕССИЯ на найденный баг: старый (неверный) id "rod1" из
//    предыдущей редакции SCENARIO_FORMAT_SPEC.md не должен ронять
//    резолвер — должен вернуть undefined, а не бросить/угадать не то поле.
test('resolveField: несуществующий id группы ("rod1") -> undefined, не исключение', () => {
  const snap = makeSnapshot();
  assert.strictEqual(resolveField(snap, 'rodGroups.rod1.position'), undefined);
});

// 4. Наивный dot-path (без спец-случая для массива) сломался бы здесь —
//    фиксируем требуемое поведение явно, чтобы регрессия ловила будущий
//    рефакторинг, который случайно уберёт спец-случай для rodGroups.
test('evaluateCondition: guarded-условие по конкретной группе работает', () => {
  const snap = makeSnapshot({ rodGroups: [{ id: 'usp', position: 95 }] });
  const cond = { field: 'rodGroups.usp.position', op: 'gte', value: 90 };
  assert.strictEqual(evaluateCondition(snap, cond), true);
});

// 5. all / any / not
test('evaluateCondition: all/any/not комбинируются', () => {
  const snap = makeSnapshot({ power: 0.5, period: null });
  const cond = {
    all: [
      { field: 'power', op: 'gte', value: 0.45 },
      { field: 'power', op: 'lte', value: 0.55 },
      { not: { field: 'scramActive', op: 'eq', value: true } },
    ],
  };
  assert.strictEqual(evaluateCondition(snap, cond), true);
});

// 6. neq null семантика (из demo-сценария: forbidCondition guarded-reach)
test('evaluateCondition: period neq null (период не определён = мощность стабильна)', () => {
  const snapStable = makeSnapshot({ period: null });
  const snapRamping = makeSnapshot({ period: 12 });
  const forbid = {
    all: [
      { field: 'period', op: 'neq', value: null },
      { field: 'period', op: 'lt', value: 20 },
    ],
  };
  assert.strictEqual(evaluateCondition(snapStable, forbid), false, 'при стабильной мощности forbid не должен сработать');
  assert.strictEqual(evaluateCondition(snapRamping, forbid), true, 'период 12с < 20с должен сработать как forbid');
});

// 7. Точный сценарий из demo_hold_and_guard.scenario.json — hold-50 condition
test('evaluateCondition: demo-сценарий hold-50 условие на границах коридора', () => {
  const cond = {
    all: [
      { field: 'power', op: 'gte', value: 0.45 },
      { field: 'power', op: 'lte', value: 0.55 },
    ],
  };
  assert.strictEqual(evaluateCondition(makeSnapshot({ power: 0.45 }), cond), true, 'нижняя граница включительно');
  assert.strictEqual(evaluateCondition(makeSnapshot({ power: 0.55 }), cond), true, 'верхняя граница включительно');
  assert.strictEqual(evaluateCondition(makeSnapshot({ power: 0.44 }), cond), false);
  assert.strictEqual(evaluateCondition(makeSnapshot({ power: 0.56 }), cond), false);
});

console.log(`\n${passed} тестов пройдено`);
