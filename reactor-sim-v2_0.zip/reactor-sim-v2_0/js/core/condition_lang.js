// condition_lang.js
//
// Изолированный, не встроенный в main.js модуль. Реализует ТОЛЬКО язык
// условий из SCENARIO_FORMAT_SPEC.md (сравнения + all/any/not + адресация
// rodGroups.<id>.position) — то, от чего зависят и цели, и сообщения.
// Не часть ScenarioEngine (его самого ещё нет), но именно тот кусок,
// который иначе был бы молча неправильным при первой же реализации
// (см. AGENT_HANDOFF v1.12 — обсуждение бага с rodGroups).
//
// Экспортирует resolveField(snapshot, path) и evaluateCondition(snapshot, cond).

/**
 * Резолвит путь вида "power", "xenonLevel", "rodGroups.usp.position",
 * "rodGroups.group1.position" по снапшоту. Для сегмента "rodGroups" ищет
 * элемент МАССИВА rodGroups по полю id (rodGroups — массив {id,label,position},
 * см. buildSnapshot() в main.js), а не читает его как ключ объекта.
 * Не находит путь — возвращает undefined (устаревшее/неверное условие
 * просто никогда не станет истинным, движок не падает).
 */
function resolveField(snapshot, path) {
  const parts = String(path).split('.');
  let cur = snapshot;
  for (let i = 0; i < parts.length; i++) {
    const key = parts[i];
    if (cur == null) return undefined;
    if (key === 'rodGroups' && Array.isArray(cur.rodGroups)) {
      const nextKey = parts[i + 1];
      if (nextKey === undefined) return cur.rodGroups;
      const group = cur.rodGroups.find((g) => g.id === nextKey);
      if (!group) return undefined;
      cur = group;
      i += 1; // nextKey уже потреблён
      continue;
    }
    cur = cur[key];
  }
  return cur;
}

function compare(op, actual, expected) {
  switch (op) {
    case 'gte': return actual != null && actual >= expected;
    case 'gt': return actual != null && actual > expected;
    case 'lte': return actual != null && actual <= expected;
    case 'lt': return actual != null && actual < expected;
    case 'eq': return actual === expected;
    case 'neq': return actual !== expected;
    default:
      throw new Error(`condition_lang: неизвестный op "${op}"`);
  }
}

/**
 * Вычисляет дерево условий { field, op, value } | { all/any/not: [...] }
 * поверх снапшота (уже расширенного scenarioTimeSec, если это тик движка
 * сценариев). Возвращает boolean.
 */
function evaluateCondition(snapshot, cond) {
  if (cond.all) return cond.all.every((c) => evaluateCondition(snapshot, c));
  if (cond.any) return cond.any.some((c) => evaluateCondition(snapshot, c));
  if (cond.not) return !evaluateCondition(snapshot, cond.not);
  const actual = resolveField(snapshot, cond.field);
  return compare(cond.op, actual, cond.value);
}

// Экспорт для node (тесты запускаются через `node js/core/condition_lang.test.js`)
// — в браузере `module` не определён вообще (обычный <script>, без сборщика),
// typeof-проверка безопасна и ничего не делает; resolveField/evaluateCondition
// остаются обычными функциями верхнего уровня скрипта, видимыми из main.js
// напрямую по имени — тем же способом, каким уже сделаны PointKinetics,
// ControlRodSystem и остальные классы модели.
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { resolveField, evaluateCondition };
}
