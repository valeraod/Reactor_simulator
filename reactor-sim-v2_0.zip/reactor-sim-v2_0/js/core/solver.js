// solver.js
// Универсальный шаг Рунге-Кутты 4 порядка для системы ОДУ, заданной как
// derivative(state, t) -> array той же длины, что state.
// state — обычный массив чисел.

const RK4Solver = {
  /**
   * Один шаг интегрирования.
   * @param {number[]} state - текущее состояние
   * @param {number} t - текущее время
   * @param {number} dt - шаг
   * @param {(state:number[], t:number)=>number[]} derivative - функция производных
   * @returns {number[]} новое состояние
   */
  step(state, t, dt, derivative) {
    const n = state.length;
    const k1 = derivative(state, t);
    const s2 = new Array(n);
    for (let i = 0; i < n; i++) s2[i] = state[i] + (dt / 2) * k1[i];

    const k2 = derivative(s2, t + dt / 2);
    const s3 = new Array(n);
    for (let i = 0; i < n; i++) s3[i] = state[i] + (dt / 2) * k2[i];

    const k3 = derivative(s3, t + dt / 2);
    const s4 = new Array(n);
    for (let i = 0; i < n; i++) s4[i] = state[i] + dt * k3[i];

    const k4 = derivative(s4, t + dt);

    const result = new Array(n);
    for (let i = 0; i < n; i++) {
      result[i] = state[i] + (dt / 6) * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]);
    }
    return result;
  },
};
