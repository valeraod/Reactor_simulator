// scenario_engine.test.js — запуск: node js/core/scenario_engine.test.js
//
// v1.19: тесты переписаны под новую модель времени — tick(snapshot, dtSec)
// принимает РЕАЛЬНУЮ дельту секунд с прошлого вызова, а не абсолютное
// модельное время. load()/rebase() больше не принимают время вообще.
//
// Регрессия по плану, зафиксированному в AGENT_HANDOFF.md (v1.13, раздел
// "План тестов для будущей реализации ScenarioEngine") — 7 пунктов,
// специфичных для самого движка целей/сообщений (условия уже покрыты
// отдельно в condition_lang.test.js), плюс новый тест №8 на регрессию
// найденного пользователем бага (модельное vs реальное время).

const assert = require('assert');
const { ScenarioEngine } = require('./scenario_engine.js');

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`OK   ${name}`);
  } catch (e) {
    console.log(`FAIL ${name}`);
    console.log('     ' + e.message);
    process.exitCode = 1;
  }
}

function makeSnapshot(overrides = {}) {
  return Object.assign({
    power: 0.5,
    rhoBeta: 0.0,
    period: null,
    xenonLevel: 3.0,
    fuelTemp: 750,
    scramActive: false,
    rodGroups: [
      { id: 'group1', position: 40 },
      { id: 'group2', position: 40 },
      { id: 'group3', position: 40 },
      { id: 'usp', position: 0 },
    ],
  }, overrides);
}

function goalStateById(engine, id) {
  return engine.getGoalsState().find((g) => g.id === id);
}

// ---------------------------------------------------------------------
// 1. type:"task" откатывается, type:"exercise" — нет.
// ---------------------------------------------------------------------
test('type task: completed идёт false->true->false->true, таймер обнуляется при выходе', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's1', title: 'T1', goals: [
      {
        id: 'hold-task', title: 'x', goalText: 'x', hintText: 'x',
        type: 'task', kind: 'hold',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 }, durationSec: 10 },
      },
    ], messages: [],
  };
  const r = engine.load(scenario);
  assert.strictEqual(r.ok, true);

  engine.tick(makeSnapshot({ power: 0.6 }), 5);
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, false);
  engine.tick(makeSnapshot({ power: 0.6 }), 5); // итого 10с
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, true, 'должно завершиться после 10с подряд');

  engine.tick(makeSnapshot({ power: 0.3 }), 2);
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, false, 'task должен откатиться при потере условия');

  engine.tick(makeSnapshot({ power: 0.6 }), 3); // ещё не 10
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, false);
  engine.tick(makeSnapshot({ power: 0.6 }), 7); // итого 10 с момента возврата true
  assert.strictEqual(goalStateById(engine, 'hold-task').completed, true, 'должен снова завершиться после нового полного интервала');
});

test('type exercise: completed остаётся true после первого попадания, не откатывается', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's2', title: 'T2', goals: [
      {
        id: 'hold-exercise', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'hold',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 }, durationSec: 10 },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.6 }), 10);
  assert.strictEqual(goalStateById(engine, 'hold-exercise').completed, true);

  engine.tick(makeSnapshot({ power: 0.1 }), 2);
  assert.strictEqual(goalStateById(engine, 'hold-exercise').completed, true, 'exercise не должен откатываться');
  engine.tick(makeSnapshot({ power: 0.0 }), 88);
  assert.strictEqual(goalStateById(engine, 'hold-exercise').completed, true, 'exercise должен остаться true навсегда');
});

// ---------------------------------------------------------------------
// 2. guarded-reach: срыв обнуляет reachedTarget, а не только failed.
// ---------------------------------------------------------------------
test('guarded-reach: forbid до цели -> цель не достигнута', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's3', title: 'T3', goals: [
      {
        id: 'gr', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'guarded-reach',
        params: {
          targetCondition: { field: 'power', op: 'gte', value: 0.8 },
          forbidCondition: { field: 'period', op: 'lt', value: 20 },
        },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.3, period: 10 }), 1);
  assert.strictEqual(goalStateById(engine, 'gr').completed, false);
  engine.tick(makeSnapshot({ power: 0.9, period: null }), 1);
  assert.strictEqual(goalStateById(engine, 'gr').completed, true, 'после снятия forbid цель должна засчитаться');
});

test('guarded-reach: срыв ПОСЛЕ успеха откатывает reachedTarget в false', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's4', title: 'T4', goals: [
      {
        id: 'gr2', title: 'x', goalText: 'x', hintText: 'x',
        type: 'task', kind: 'guarded-reach',
        params: {
          targetCondition: { field: 'power', op: 'gte', value: 0.8 },
          forbidCondition: { field: 'period', op: 'lt', value: 20 },
        },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.9, period: null }), 1);
  assert.strictEqual(goalStateById(engine, 'gr2').completed, true);
  engine.tick(makeSnapshot({ power: 0.9, period: 10 }), 1);
  assert.strictEqual(
    goalStateById(engine, 'gr2').completed,
    false,
    'reachedTarget должен откатиться в false, а не остаться true рядом с failed'
  );
});

// ---------------------------------------------------------------------
// 3. sequence: порядок transitions значим.
// ---------------------------------------------------------------------
test('sequence: при двух одновременно истинных переходах срабатывает первый по порядку', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's5', title: 'T5', goals: [
      {
        id: 'seq', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'sequence',
        params: {
          initial: 'idle',
          success: 'done-first',
          states: {
            idle: {
              transitions: [
                { if: { field: 'power', op: 'gte', value: 0.5 }, goto: 'done-first' },
                { if: { field: 'power', op: 'gte', value: 0.5 }, goto: 'done-second' },
              ],
            },
            'done-first': {},
            'done-second': {},
          },
        },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.9 }), 1);
  assert.strictEqual(goalStateById(engine, 'seq').completed, true, 'должен попасть в success (первый транзишн)');
});

// ---------------------------------------------------------------------
// 4. rebase() не трогает прогресс.
// ---------------------------------------------------------------------
test('rebase(): scenarioTimeSec пересчитан от нуля, но timerSec/completed не тронуты', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's6', title: 'T6', goals: [
      {
        id: 'hold-r', title: 'x', goalText: 'x', hintText: 'x',
        type: 'task', kind: 'hold',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 }, durationSec: 60 },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.6 }), 30);
  assert.strictEqual(goalStateById(engine, 'hold-r').completed, false);
  assert.ok(goalStateById(engine, 'hold-r').progress > 0.49 && goalStateById(engine, 'hold-r').progress < 0.51);

  engine.rebase();

  assert.ok(goalStateById(engine, 'hold-r').progress > 0.49 && goalStateById(engine, 'hold-r').progress < 0.51, 'rebase не должен трогать прогресс');

  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  const state = goalStateById(engine, 'hold-r');
  assert.ok(state.progress > 0.5 && state.progress < 0.55, `progress=${state.progress}`);
});

// ---------------------------------------------------------------------
// 5. resetGoal/resetAll изолированы друг от друга.
// ---------------------------------------------------------------------
test('resetGoal(id) не затрагивает другие цели', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's7', title: 'T7', goals: [
      {
        id: 'g1', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'reach',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 } },
      },
      {
        id: 'g2', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'reach',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 } },
      },
    ], messages: [],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.9 }), 1);
  assert.strictEqual(goalStateById(engine, 'g1').completed, true);
  assert.strictEqual(goalStateById(engine, 'g2').completed, true);

  engine.resetGoal('g1');
  assert.strictEqual(goalStateById(engine, 'g1').completed, false, 'g1 должна сброситься');
  assert.strictEqual(goalStateById(engine, 'g2').completed, true, 'g2 не должна быть затронута');
});

// ---------------------------------------------------------------------
// 6. getActiveMessages() — очередь, не повторный push.
// ---------------------------------------------------------------------
test('messages: repeat=false — сообщение отдаётся один раз, не повторяется, пока условие остаётся true', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's8', title: 'T8', goals: [], messages: [
      { id: 'm1', text: 'привет', severity: 'info', condition: { field: 'power', op: 'gte', value: 0.5 }, repeat: false },
    ],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  let msgs = engine.getActiveMessages();
  assert.strictEqual(msgs.length, 1);
  assert.strictEqual(msgs[0].id, 'm1');

  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  msgs = engine.getActiveMessages();
  assert.strictEqual(msgs.length, 0, 'не должно повторно отдаваться, пока условие остаётся true');
});

test('messages: repeat=true — отдаётся заново именно на новом переходе в true', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's9', title: 'T9', goals: [], messages: [
      { id: 'm2', text: 'внимание', severity: 'caution', condition: { field: 'xenonLevel', op: 'gte', value: 3.5 }, repeat: true },
    ],
  };
  engine.load(scenario);
  engine.tick(makeSnapshot({ xenonLevel: 4.0 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 1);

  engine.tick(makeSnapshot({ xenonLevel: 4.0 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 0);

  engine.tick(makeSnapshot({ xenonLevel: 3.0 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 0);

  engine.tick(makeSnapshot({ xenonLevel: 4.0 }), 1);
  assert.strictEqual(engine.getActiveMessages().length, 1, 'repeat=true должен отдать сообщение заново на новом переходе');
});

// ---------------------------------------------------------------------
// 7. Битый файл сценария не роняет движок.
// ---------------------------------------------------------------------
test('load(): отсутствие обязательного поля -> {ok:false, error}, без исключения', () => {
  const engine = new ScenarioEngine();
  const broken = {
    id: 'broken', title: 'Broken', goals: [
      { id: 'no-type', title: 'x', goalText: 'x', hintText: 'x', kind: 'hold', params: { condition: {}, durationSec: 1 } },
    ], messages: [],
  };
  let result;
  assert.doesNotThrow(() => { result = engine.load(broken); });
  assert.strictEqual(result.ok, false);
  assert.ok(typeof result.error === 'string' && result.error.length > 0);
  assert.strictEqual(engine.isLoaded(), false, 'движок не должен считаться загруженным после неудачной валидации');
});

test('load(): не-объект целиком -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => { result = engine.load(null); });
  assert.strictEqual(result.ok, false);
  assert.doesNotThrow(() => { result = engine.load('строка, не объект'); });
  assert.strictEqual(result.ok, false);
});

// ---------------------------------------------------------------------
// НОВОЕ (v2.0): instructions[] — необязательное поле, отличающее урок
// (сценарий + явно объяснённая последовательность действий) от голого
// сценария (только состояние+цель, без instructions). См. AGENT_HANDOFF.md.
// ---------------------------------------------------------------------
test('load(): без instructions -> getMeta().instructions === []', () => {
  const engine = new ScenarioEngine();
  engine.load({ id: 's-no-instr', title: 'Без инструкций', goals: [], messages: [] });
  assert.deepStrictEqual(engine.getMeta().instructions, []);
});

test('load(): instructions — валидный массив строк -> сохраняется и отдаётся через getMeta()', () => {
  const engine = new ScenarioEngine();
  const steps = ['Шаг первый: вывести стержни группы 3 на 5%.', 'Шаг второй: удержать мощность в коридоре.'];
  const result = engine.load({ id: 's-instr', title: 'С инструкциями', goals: [], messages: [], instructions: steps });
  assert.strictEqual(result.ok, true);
  assert.deepStrictEqual(engine.getMeta().instructions, steps);
});

test('load(): instructions не массив -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => { result = engine.load({ id: 'bad', title: 'x', goals: [], messages: [], instructions: 'не массив' }); });
  assert.strictEqual(result.ok, false);
});

test('load(): instructions с пустой строкой внутри -> {ok:false}, без исключения', () => {
  const engine = new ScenarioEngine();
  let result;
  assert.doesNotThrow(() => { result = engine.load({ id: 'bad2', title: 'x', goals: [], messages: [], instructions: ['ok', ''] }); });
  assert.strictEqual(result.ok, false);
});

// ---------------------------------------------------------------------
// 8. НОВОЕ (v1.19): hold считает по РЕАЛЬНОМУ dt, переданному в tick(), а
// не по какому-либо "модельному времени" — прямая регрессия на баг,
// найденный пользователем: при ускорении симуляции (simSpeed) 60 секунд
// МОДЕЛЬНОГО времени раньше пролетали за 1 реальную секунду. Теперь
// движок вообще не получает модельное время — только реальную дельту.
// ---------------------------------------------------------------------
test('hold: результат зависит только от суммы dt, не от модельного времени/simSpeed', () => {
  const engine = new ScenarioEngine();
  const scenario = {
    id: 's10', title: 'T10', goals: [
      {
        id: 'hold-real', title: 'x', goalText: 'x', hintText: 'x',
        type: 'exercise', kind: 'hold',
        params: { condition: { field: 'power', op: 'gte', value: 0.5 }, durationSec: 60 },
      },
    ], messages: [],
  };
  engine.load(scenario);
  // 59 РЕАЛЬНЫХ секунд одним тиком (при simSpeed x60 модельное время
  // улетело бы на ~3540с за эти же 59 реальных секунд — но движок его
  // вообще не видит, только реальную дельту, поэтому цель ещё не готова)
  engine.tick(makeSnapshot({ power: 0.6 }), 59);
  assert.strictEqual(goalStateById(engine, 'hold-real').completed, false, '59 реальных секунд ещё не 60');
  engine.tick(makeSnapshot({ power: 0.6 }), 1);
  assert.strictEqual(goalStateById(engine, 'hold-real').completed, true, 'ровно 60 реальных секунд — готово');
});

console.log(`\n${passed} тестов пройдено`);
