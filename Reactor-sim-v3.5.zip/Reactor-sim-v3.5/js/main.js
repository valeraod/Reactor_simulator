// main.js
// Точка входа: создаёт модель, UI, и запускает цикл симуляции реального времени.

(function () {
  const rodSystem = new ControlRodSystem(RBMK_PARAMS);
  const fastPoisons = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power, RBMK_PARAMS.betaEff);
  const burnupModel = new BurnupModel(ISOTOPE_PARAMS.slow, () => kinetics.power, RBMK_PARAMS.betaEff);

  // v1.7 — Пространственная модель активной зоны, п.2 (см. AGENT_HANDOFF.md).
  // isotopes.js как класс НЕ меняется — раздваивается I/Xe созданием ВТОРОГО
  // экземпляра FastPoisons с локальным getPower. Pm/Sm НЕ раздваивается
  // (слишком медленный процесс для часового масштаба качелей верх/низ) — эти
  // два новых экземпляра дают Pm/Sm тоже (класс интегрирует все 4 состояния
  // вместе, его не меняли), но эти конкретные Pm/Sm значения НЕ используются
  // нигде — общий Sm-эффект по-прежнему берётся из единственного "глобального"
  // fastPoisons (см. designExcessReactivity/getSamariumReactivity ниже,
  // без изменений). Из зонных экземпляров используется только Xe.
  //
  // Локальная "мощность" зоны — это не доля от n, а n, отмасштабированное так,
  // чтобы при точной симметрии (frac=0.5/0.5) зонный getPower() давал РОВНО
  // kinetics.power — тогда зонная модель не отличима от одиночной (условие
  // регрессии "при симметрии = текущее поведение", проверено в getZonePowerFractions()).
  const fastPoisonsTop = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power * 2 * rodSystem.getZonePowerFractions().top, RBMK_PARAMS.betaEff);
  const fastPoisonsBottom = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power * 2 * rodSystem.getZonePowerFractions().bottom, RBMK_PARAMS.betaEff);
  // v2.5 — ВТОРАЯ, независимая пространственная ось (лево/право,
  // азимутальный перекос) — точная копия пары Top/Bottom выше, только через
  // getAzimuthPowerFractions(). При симметрии (group1.position ===
  // group2.position) даёт то же требование регрессии, что и осевая пара.
  const fastPoisonsLeft = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power * 2 * rodSystem.getAzimuthPowerFractions().left, RBMK_PARAMS.betaEff);
  const fastPoisonsRight = new FastPoisons(ISOTOPE_PARAMS.fast, () => kinetics.power * 2 * rodSystem.getAzimuthPowerFractions().right, RBMK_PARAMS.betaEff);

  /**
   * Небольшая штрафная поправка к общей ρ от накопившегося перекоса ксенона
   * между зонами (см. AGENT_HANDOFF.md, п.2 и "Открыто перед кодом" —
   * согласовано как штрафная, не знаковая версия). Всегда <= 0: это честная
   * плата за огрубление (нет настоящей диффузии между зонами), а не
   * дополнительный физический эффект, который можно было бы "выгодно"
   * использовать перекосом. При симметрии (Xe_top === Xe_bottom, что строго
   * верно при frac=0.5/0.5) равна нулю — часть "спит", как и остальная
   * зонная модель.
   */
  function zoneImbalanceReactivity() {
    const dXe = fastPoisonsTop.xenonLevel - fastPoisonsBottom.xenonLevel; // β, может быть любого знака
    return -RBMK_PARAMS.spatial.zoneImbalancePenaltyBeta * dXe * dXe * RBMK_PARAMS.betaEff;
  }

  /** v2.5 — та же штрафная поправка, но для оси лево/право. Независима от
   * осевой версии выше — оба штрафа складываются в общую ρ (см. ниже). */
  function azimuthImbalanceReactivity() {
    const dXe = fastPoisonsLeft.xenonLevel - fastPoisonsRight.xenonLevel;
    return -RBMK_PARAMS.spatial.azimuthImbalancePenaltyBeta * dXe * dXe * RBMK_PARAMS.betaEff;
  }

  // Запас реактивности активной зоны в реальности рассчитан так, чтобы
  // перекрывать равновесное отравление Xe/Sm — иначе реактор не мог бы вообще
  // выйти в критику при "штатном" положении стержней. Без этой компенсации
  // модель на старте оказывается глубоко подкритична (равновесные яды дают
  // порядка -4β, ничем не скомпенсированные) и глохнет сама по себе.
  const designExcessReactivity = (fastPoisons.equilibrium.Xe + fastPoisons.equilibrium.Sm) * RBMK_PARAMS.betaEff;

  const kinetics = new PointKinetics(
    RBMK_PARAMS,
    () =>
      rodSystem.getReactivity() +
      fastPoisons.getXenonReactivity() +
      fastPoisons.getSamariumReactivity() +
      burnupModel.getReactivity() +
      designExcessReactivity +
      zoneImbalanceReactivity() +
      azimuthImbalanceReactivity(),
    'modern' // паровой коэффициент; 'historical' — задел под Stage 5
  );
  const diagnostics = new DiagnosticsEngine();
  // v1.15 — ScenarioEngine создан и подключён к игровому циклу (tick()/
  // rebase() ниже), но загружать в него пока нечем: кнопки «Загрузить
  // сценарий»/«Загрузить урок» ещё нет (см. AGENT_HANDOFF.md — следующий
  // шаг). isLoaded() остаётся false всё время — значит tick() ниже сейчас
  // безусловно no-op, поведение реактора не меняется.
  const scenarioEngine = new ScenarioEngine();
  // v2.3 — терминальная авария ("повреждение активной зоны"). Работает
  // ВСЕГДА, независимо от того, загружен ли сценарий (см. AGENT_HANDOFF.md,
  // "План новой физики" — роль "исследователь аварий" должна работать и в
  // свободном режиме). reactorDestroyed — отдельный флаг (не то же самое,
  // что accidentMonitor.isTriggered(), хотя они всегда синхронны): нужен,
  // чтобы onStart()/onPauseToggle() могли явно отказать в повторном запуске
  // без обращения к внутренностям монитора из разных мест.
  const accidentMonitor = new AccidentMonitor(RBMK_PARAMS.accidentThresholds);
  let reactorDestroyed = false;

  let simRunning = false; // физика не шагает до нажатия "Старт" — см. п.4 согласованного плана
  let simSpeed = 1;
  let speedLocked = false; // защита от разбалансировки на невнимательности (см. AGENT_HANDOFF.md)
  // Органы управления стержнями недоступны, пока оператор не нажал «Старт» —
  // не только сама физика не идёт, но и крутить стержни "вслепую" до пуска
  // не должно быть возможности. Разблокируется в onStart(), снова
  // блокируется Горячим/Холодным стартом (afterStartReset).
  let rodControlsLocked = true;

  // При запуске программы реактор НЕ должен выглядеть работающим — все три
  // модуля (rodSystem/kinetics/fastPoisons) конструируются в состоянии
  // "реактор уже давно в работе" (n=1, стержни 50%, Xe/Sm в равновесии — это
  // нужно, чтобы designExcessReactivity/reset() Горячего старта считались от
  // правильной опорной точки). Оператор ещё не выбрал режим пуска, поэтому
  // здесь принудительно приводим начальный вид к "реактор остановлен":
  // стержни введены, мощность и яды на нуле. Кнопка «Старт» остаётся
  // заблокированной (см. controls_panel.js: initRunControl), пока оператор
  // не нажмёт Горячий или Холодный старт — тогда состояние будет выставлено
  // заново, уже по-настоящему, соответствующей функцией (onHotStart/onColdStart).
  rodSystem.reset(0);
  kinetics.initState(0, RBMK_PARAMS.thermal.coolantTemp0);
  fastPoisons.reset(true);
  fastPoisonsTop.reset(true);
  fastPoisonsBottom.reset(true);
  fastPoisonsLeft.reset(true);
  fastPoisonsRight.reset(true);

  Dashboard.init();
  Dashboard.renderRodBank(rodSystem, rodControlsLocked, buildSnapshot());

  function buildSnapshot() {
    const rhoExternal =
      rodSystem.getReactivity() +
      fastPoisons.getXenonReactivity() +
      fastPoisons.getSamariumReactivity() +
      burnupModel.getReactivity() +
      designExcessReactivity +
      zoneImbalanceReactivity();
    const dopplerBeta = kinetics.dopplerReactivityBeta;
    const voidBeta = kinetics.voidReactivityBeta;
    const rhoAbs = rhoExternal + (dopplerBeta + voidBeta) * rodSystem.betaTotal;
    const zoneFrac = rodSystem.getZonePowerFractions();
    const azimuthFrac = rodSystem.getAzimuthPowerFractions();
    return {
      power: kinetics.power,
      rhoAbs,
      rhoBeta: rhoAbs / rodSystem.betaTotal,
      period: kinetics.period,
      rodGroups: rodSystem.groups.map((g) => ({ id: g.id, label: g.label, position: g.position })),
      scramActive: rodSystem.scramActive,
      scramComplete: rodSystem.isFullyInserted(),
      xenonLevel: fastPoisons.xenonLevel,
      promethiumLevel: fastPoisons.promethiumLevel,
      samariumLevel: fastPoisons.samariumLevel,
      burnupEFPD: burnupModel.burnupEFPD,
      burnupMode: burnupModel.mode,
      fuelTemp: kinetics.fuelTemp,
      voidFraction: kinetics.voidFraction,
      dopplerReactivityBeta: dopplerBeta,
      voidReactivityBeta: voidBeta,
      // v2.7 — текущий паровой режим ('modern'/'historical'), см.
      // kinetics.setVoidMode(). Показывается в UI (Паровой ρ), чтобы
      // доаварийная конфигурация была видна, а не незаметна.
      voidMode: kinetics.voidMode,
      ozrBeta: rodSystem.getOperationalMargin(),
      ozrMaxBeta: rodSystem.getMaxOperationalMargin(),
      // v1.7 — Пространственная модель, п.2: осевой перекос ксенона (β,
      // верх минус низ) и текущая локальная доля потока по зонам (0..1).
      axialXeTop: fastPoisonsTop.xenonLevel,
      axialXeBottom: fastPoisonsBottom.xenonLevel,
      axialOffsetBeta: fastPoisonsTop.xenonLevel - fastPoisonsBottom.xenonLevel,
      zoneFracTop: zoneFrac.top,
      zoneFracBottom: zoneFrac.bottom,
      // v2.5 — ВТОРАЯ, независимая пространственная ось: азимутальный
      // перекос (лево/право), тот же смысл полей, что и у осевой версии выше.
      azimuthXeLeft: fastPoisonsLeft.xenonLevel,
      azimuthXeRight: fastPoisonsRight.xenonLevel,
      azimuthOffsetBeta: fastPoisonsLeft.xenonLevel - fastPoisonsRight.xenonLevel,
      azimuthFracLeft: azimuthFrac.left,
      azimuthFracRight: azimuthFrac.right,
      // v2.3 — расход теплоносителя (см. kinetics.setCoolantFlowFraction()).
      coolantFlowFraction: kinetics.coolantFlowFraction,
    };
  }

  diagnostics.log(0, 'info', 'Симулятор загружен — реактор остановлен. Выберите режим пуска (Горячий/Холодный старт) и нажмите «Старт»', 'system', buildSnapshot());

  function onScram() {
    // АЗ-5 сама переставляет стержни — любая незавершённая ручная правка
    // теряет смысл как отдельная запись, и открывать её после АЗ-5 нечем
    // сравнивать (позиции сейчас поедут по рампе, а не по клику оператора).
    flushAllPendingRodChanges();
    rodSystem.groups.forEach((g) => {
      _lastLoggedRodPosition[g.id] = g.position;
    });
    rodSystem.scram();
    Dashboard.updateStatus('АЗ-5 ИНИЦИИРОВАНА — аварийный ввод стержней', true);
    // АЗ-5 всегда сбрасывает скорость на ×1 и блокирует ускорение — независимо
    // от того, была ли уже тревога по мощности/реактивности/периоду на этот
    // момент (оператор мог нажать АЗ-5 профилактически) — согласовано отдельно.
    if (simSpeed > 1) {
      simSpeed = 1;
      ControlsPanel.selectSpeed(1);
    }
    speedLocked = true;
    ControlsPanel.setSpeedButtonsLocked(true);
  }

  function onReleaseScram() {
    if (!rodSystem.scramActive) return;
    rodSystem.releaseScram();
    rodSystem.groups.forEach((g) => {
      _lastLoggedRodPosition[g.id] = g.position;
    });
    diagnostics.log(kinetics.t, 'info', 'Блокировка АЗ-5 снята оператором — ручное управление стержнями восстановлено', 'scram', buildSnapshot());
    Dashboard.updateStatus('Блокировка АЗ-5 снята — ручное управление восстановлено', false);
  }

  /** Общая часть Горячего/Холодного старта: диагностика/журнал/графики/скорость/пауза */
  function afterStartReset(label) {
    // Позиции стержней сейчас переставлены Х/Г-стартом (или загрузкой) не
    // операторским кликом — старые pending-записи (если остались) относятся
    // к уже неактуальному состоянию "до" и должны быть отброшены без записи
    // в журнал, а не тихо всплыть позже со сравнением "с чем попало".
    Object.keys(_rodChangePending).forEach((id) => delete _rodChangePending[id]);
    rodSystem.groups.forEach((g) => {
      _lastLoggedRodPosition[g.id] = g.position;
    });

    diagnostics.reset();
    Dashboard.resetTrends(); // модельное время обнуляется — старые точки тренда больше не валидны
    // v1.19: rebase() больше не принимает время (движок сам не знает про
    // модельное время) — просто обнуляет scenarioTimeSec. Прогресс целей
    // по-прежнему не трогается — rebase() специально для этого отделён от
    // resetAll(). Безопасно вызывать всегда — rebase() сам по себе no-op,
    // если сценарий не загружен.
    scenarioEngine.rebase();
    diagnostics.log(0, 'info', label, 'system', buildSnapshot());
    Dashboard.updateStatus(label, false);
    ControlsPanel.syncPresetButtonsAfterReset();

    simRunning = false;
    simSpeed = 1;
    speedLocked = false;
    rodControlsLocked = true;
    ControlsPanel.setScramButtonLocked(true); // v2.1 — багфикс: снова недоступна до следующего «Старт»
    ControlsPanel.setSpeedButtonsLocked(false);
    ControlsPanel.selectSpeed(1);
    ControlsPanel.resetRunControl();
    // v2.3 — Х/Г-старт полностью "лечит" реактор: сбрасываем расход
    // теплоносителя (мог быть искажён аварийным faults[] на предыдущей
    // попытке), аварийный монитор и сам факт разрушения. Без этого
    // повторный запуск после аварии унаследовал бы уже поражённое
    // состояние — реактор технически новый/восстановленный.
    kinetics.setCoolantFlowFraction(1.0);
    // v2.7 — Х/Г-старт возвращает reactor к штатной ('modern') конфигурации
    // парового коэффициента — 'historical' имеет смысл только для уроков,
    // явно описывающих доаварийную конфигурацию (см. AGENT_HANDOFF.md).
    kinetics.setVoidMode('modern');
    accidentMonitor.reset();
    reactorDestroyed = false;
    // v2.3 — багфикс (найден headless-прогоном): без этого сработавший
    // fault сценария (например, отказ ГЦН) оставался "взведённым", и на
    // следующем же кадре getActiveFaultEffects() тут же переустанавливал
    // старое (аварийное) значение расхода поверх только что сброшенного
    // kinetics.setCoolantFlowFraction(1.0) — реактор визуально "лечился"
    // на один кадр и тут же снова "ломался". resetFaults() НЕ трогает
    // прогресс целей (в отличие от resetAll()) — Х/Г-старт лечит физику,
    // но не должен списывать уже пройденные шаги урока.
    if (scenarioEngine.isLoaded()) scenarioEngine.resetFaults();
    // Горячий/Холодный старт всегда возвращают реактор на паузу — значит,
    // выбор режима пуска снова доступен для повторной переигровки сессии.
    ControlsPanel.setStartModeButtonsLocked(false);
  }

  /** Горячий старт: реактор уже работает на 100% N0, стержни 50%, Xe/Sm в равновесии (как раньше "Сброс модели") */
  function onHotStart() {
    rodSystem.reset(); // 50% по умолчанию
    kinetics.reset(); // n=1, T_fuel=750°C
    fastPoisons.reset(false); // равновесие
    fastPoisonsTop.reset(false); // симметрично — rodSystem.reset() ставит и УСП на 50%
    fastPoisonsBottom.reset(false);
    fastPoisonsLeft.reset(false); // v2.5 — симметрично, group1===group2===50%
    fastPoisonsRight.reset(false);
    burnupModel.clearHistory(); // EFPD/пресет НЕ трогаем — независимая настройка
    afterStartReset('Горячий старт — реактор в стационарном режиме на 100% N0');
  }

  /** Холодный старт: топливо ещё не работало — стержни введены, Xe/Sm=0, топливо холодное. Наработка/пресет сохраняются. */
  function onColdStart() {
    rodSystem.reset(0); // стержни полностью введены
    kinetics.initState(RBMK_PARAMS.coldStartSourceN0, RBMK_PARAMS.thermal.coolantTemp0);
    fastPoisons.reset(true); // ноль — топливо не успело наработать яды
    fastPoisonsTop.reset(true); // симметрично — rodSystem.reset(0) ставит и УСП на 0%
    fastPoisonsBottom.reset(true);
    fastPoisonsLeft.reset(true); // v2.5
    fastPoisonsRight.reset(true);
    burnupModel.clearHistory();
    afterStartReset('Холодный старт — стержни введены, реактор заглушён, топливо холодное');
    // Уточнение к Холодному старту: T_теплоносителя в Stage 3 — фиксированная
    // константа (270°C, рабочая температура контура), разогрев с нуля не
    // моделируется. Это важно проговорить явно, иначе оператор может решить,
    // что довёл реактор с абсолютного нуля до 100% за часы модельного
    // времени — в реальности это относится только к пуску после короткого
    // планового останова; после полного расхолаживания/перегрузки топлива
    // сам разогрев контура занимает недели, иногда больше месяца, и в модели
    // не отражён. См. обсуждение — AGENT_HANDOFF.md.
    diagnostics.log(
      0,
      'caution',
      'Внимание: контур первого контура уже на рабочей температуре (270°C) — разогрев с нуля в модели не воспроизводится. Этот сценарий соответствует пуску после короткого планового останова, а не после полного расхолаживания/перегрузки топлива (тот процесс — недели, иногда больше месяца — сюда не входит)',
      'system',
      buildSnapshot()
    );
  }

  function onStart() {
    // v2.3 — после терминальной аварии обычный «Старт» не должен ничего
    // делать (кнопка и так задизейблена через lockRunControlsForAccident(),
    // но не полагаемся только на UI-состояние — та же защита, что уже
    // применялась для btn-reset-scenario).
    if (reactorDestroyed) return;
    simRunning = true;
    rodControlsLocked = false; // органы управления стержнями становятся доступны только после «Старт»
    ControlsPanel.setScramButtonLocked(false); // v2.1 — багфикс: АЗ-5 разблокируется вместе с остальными стержнями
    // После запуска реактора смена режима пуска заблокирована — оператор не
    // должен иметь возможность подменить состояние уже идущей реакции.
    ControlsPanel.setStartModeButtonsLocked(true);
    diagnostics.log(kinetics.t, 'info', 'Симуляция запущена оператором', 'system', buildSnapshot());
  }

  function onPauseToggle() {
    // v2.3 — см. onStart(): после аварии «Продолжить» тоже не должен
    // работать, даже если кнопка почему-то осталась активной.
    if (reactorDestroyed) return simRunning;
    simRunning = !simRunning;
    // Багфикс: органы управления стержнями должны блокироваться на паузе так
    // же, как они заблокированы до «Старт» (rodControlsLocked раньше
    // выставлялся только в конструкторе/onStart/аварии — onPauseToggle() про
    // него не знал, и на паузе можно было двигать стержни). АЗ-5 эта
    // блокировка не касается — управляется отдельно, через
    // setScramButtonLocked, и остаётся доступной даже на паузе.
    rodControlsLocked = !simRunning;
    // На паузе выбор режима пуска снова доступен (реактор фактически не
    // идёт), при возобновлении — опять блокируется.
    ControlsPanel.setStartModeButtonsLocked(simRunning);
    diagnostics.log(kinetics.t, 'info', simRunning ? 'Симуляция продолжена оператором' : 'Симуляция поставлена на паузу оператором', 'system', buildSnapshot());
    return simRunning;
  }

  // Debounce для записей "оператор установил X%": раньше каждый клик +/-1%
  // писал отдельную строку в журнал — при серии из 5-10 кликов подряд (обычное
  // действие "подвинуть стержень пониже") лог захлёбывался служебным шумом.
  // Вместо немедленной записи копим последнее движение по каждой группе и
  // пишем ОДНУ сводную строку после паузы (по РЕАЛЬНОМУ времени — не по
  // модельному, иначе на ×3600 порог в секунды модельного времени проходил бы
  // почти мгновенно и debounce не работал бы вовсе).
  const ROD_LOG_DEBOUNCE_MS = 1200;
  const _rodChangePending = {}; // id -> { fromPct, toPct, lastChangeRealMs }
  const _lastLoggedRodPosition = {};
  rodSystem.groups.forEach((g) => {
    _lastLoggedRodPosition[g.id] = g.position;
  });

  function flushRodChangeLog(id) {
    const pending = _rodChangePending[id];
    if (!pending) return;
    delete _rodChangePending[id];
    if (pending.toPct === pending.fromPct) return; // вернулись туда же — нечего писать
    const g = rodSystem.groups.find((x) => x.id === id);
    const label = g ? g.label : id;
    diagnostics.log(
      kinetics.t,
      'info',
      `${label}: оператор изменил положение с ${pending.fromPct}% до ${pending.toPct}%`,
      'rods',
      buildSnapshot()
    );
    _lastLoggedRodPosition[id] = pending.toPct;
  }

  function flushAllPendingRodChanges() {
    Object.keys(_rodChangePending).forEach(flushRodChangeLog);
  }

  function onRodChange(id, pct) {
    const g = rodSystem.groups.find((x) => x.id === id);
    if (!g) return;
    if (!_rodChangePending[id]) {
      _rodChangePending[id] = { fromPct: _lastLoggedRodPosition[id], toPct: pct, lastChangeRealMs: performance.now() };
    } else {
      _rodChangePending[id].toPct = pct;
      _rodChangePending[id].lastChangeRealMs = performance.now();
    }
  }

  function onPresetChange(presetKey, presetLabel, efpd) {
    diagnostics.log(kinetics.t, 'info', `Оператор выбрал пресет топлива «${presetLabel}» (${efpd.toFixed(1)} EFPD)`, 'burnup', buildSnapshot());
  }

  ControlsPanel.init(rodSystem, onScram, onHotStart, onColdStart, onReleaseScram, onRodChange);
  ControlsPanel.initBurnupControls(burnupModel, onPresetChange);
  ControlsPanel.initRunControl(onStart, onPauseToggle);

  ControlsPanel.initSpeedControl((speed) => {
    simSpeed = speed;
    diagnostics.log(kinetics.t, 'info', `Скорость моделирования: ×${speed}`, 'system', buildSnapshot());
  });

  function formatModelTime(t) {
    const h = Math.floor(t / 3600).toString().padStart(2, '0');
    const m = Math.floor((t % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(t % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
  }

  /** Таймер в шапке: "Д ЧЧ:ММ:СС" — сутки НЕ обрезаются по модулю (кампания — сотни суток) */
  function formatModelTimeLong(t) {
    const days = Math.floor(t / 86400);
    const h = Math.floor((t % 86400) / 3600).toString().padStart(2, '0');
    const m = Math.floor((t % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(t % 60).toString().padStart(2, '0');
    return `${days} ${h}:${m}:${s}`;
  }

  const reactorTimerEl = document.getElementById('reactor-timer');

  function snapToLines(snap) {
    if (!snap) return [];
    // "% введено" (100 - position) — как в панели СУЗ (renderRodBank), не
    // сырое position, чтобы цифры в логе и на панели не расходились.
    const rods = snap.rodGroups.map((g) => `${g.label.replace('Группа ', 'Г')} ${Math.round(100 - g.position)}%`).join(' · ');
    return [
      `Мощность: ${(snap.power * 100).toFixed(1)}% N0 · ${Math.round(snap.power * RBMK_PARAMS.nominalPowerMWt)} МВт · ρ: ${snap.rhoBeta >= 0 ? '+' : ''}${snap.rhoBeta.toFixed(3)}β · период: ${isFinite(snap.period) && snap.period !== 0 ? snap.period.toFixed(1) + ' с' : 'н/д'}`,
      `Xe-135: ${snap.xenonLevel.toFixed(2)}β (экв.) · Pm-149: ${snap.promethiumLevel.toFixed(2)}β (будущий Sm) · Sm-149: ${snap.samariumLevel.toFixed(2)}β (экв.)`,
      `Топливо: ${snap.fuelTemp.toFixed(0)}°C · паросодержание ${(snap.voidFraction * 100).toFixed(0)}% · ρ_доплер: ${snap.dopplerReactivityBeta.toFixed(3)}β · ρ_паровой: ${snap.voidReactivityBeta >= 0 ? '+' : ''}${snap.voidReactivityBeta.toFixed(3)}β`,
      `Осевой перекос: ΔXe(верх−низ) ${snap.axialOffsetBeta >= 0 ? '+' : ''}${snap.axialOffsetBeta.toFixed(2)}β · локальная мощность верх/низ ${(snap.zoneFracTop * 100).toFixed(0)}%/${(snap.zoneFracBottom * 100).toFixed(0)}%`,
      `СУЗ: ${snap.scramActive ? (snap.scramComplete ? 'АЗ-5, все группы введены' : 'АЗ-5, идёт аварийный ввод') : rods}`,
      `Наработка: ${snap.burnupEFPD.toFixed(1)} EFPD · ${snap.burnupMode === 'accelerated' ? 'ускоренный режим' : 'зафиксирован возраст'}`,
    ];
  }

  function exportLogToMarkdown() {
    const now = new Date();
    const header = [
      '# РБМК-1000 · Журнал учебной сессии',
      '',
      `Экспортировано: ${now.toLocaleString('ru-RU')}`,
      '',
      '---',
      '',
    ];
    const body = diagnostics.fullHistory
      .map((e) => {
        const sevTag = { alarm: 'АВАРИЯ', caution: 'ВНИМАНИЕ', info: 'ИНФО' }[e.severity] || e.severity.toUpperCase();
        const lines = [`### t = ${formatModelTime(e.t)} (модельное время)`, '', `**[${sevTag}] ${e.text}**`];
        const snapLines = snapToLines(e.snap);
        if (snapLines.length) lines.push('', ...snapLines);
        lines.push('', '---', '');
        return lines.join('\n');
      })
      .join('\n');

    const md = header.join('\n') + body;
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const ts = now.toISOString().slice(0, 19).replace(/[:T]/g, '-');
    a.href = url;
    a.download = `reactor-log-${ts}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  document.getElementById('btn-save-log').addEventListener('click', exportLogToMarkdown);

  /**
   * Сохранение/загрузка полного состояния модели (не журнал, не графики —
   * только физика: kinetics/isotopes/rods/burnup). Пригодится для повторного
   * запуска одного и того же сценария и для будущих заготовок аварийных
   * ситуаций (Stage 5). Формат — JSON, не .md (машиночитаемый, не для чтения).
   */
  function exportStateToJson() {
    const payload = {
      formatVersion: 1,
      savedAt: new Date().toISOString(),
      simSpeed,
      kinetics: kinetics.getState(),
      isotopes: fastPoisons.getState(),
      rods: rodSystem.getState(),
      burnup: burnupModel.getState(),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    a.href = url;
    a.download = `reactor-state-${ts}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    diagnostics.log(kinetics.t, 'info', 'Состояние модели сохранено в файл', 'system', buildSnapshot());
  }

  /**
   * Применяет уже распарсенный payload состояния (formatVersion:1, ровно то,
   * что кладёт exportStateToJson()) к модели. НЕ делает JSON.parse — payload
   * уже объект. Выделено из importStateFromFile() (v1.15, см. AGENT_HANDOFF.md
   * — рефакторинг под будущую "Загрузить урок": там state приходит не из
   * файла на диске, а вложенным объектом внутри .lesson.json, но применяется
   * буквально тем же кодом). Не бросает исключение наружу — возвращает
   * {ok:true} | {ok:false, error}, тот же принцип, что и ScenarioEngine.load().
   * ПРИМЕЧАНИЕ: применение по-прежнему НЕ атомарно (несколько независимых
   * loadState() подряд) — уже принятый риск формата v1 (см. v1.4 в
   * AGENT_HANDOFF.md), рефакторинг его не меняет, только даёт коду одно
   * место обитания вместо дублирования.
   */
  function applyStatePayload(payload, label) {
    try {
      // ПРИМЕЧАНИЕ: применение не атомарно — если один из loadState() упадёт
      // на середине, модель может остаться в смешанном (наполовину старом,
      // наполовину новом) состоянии. Для формата v1 (4 независимых, слабо
      // связанных объекта) сочли это приемлемым риском ради простоты; при
      // сбое ниже явно советуем Горячий/Холодный старт, чтобы гарантированно
      // вернуться к чистому состоянию, а не продолжать с неизвестным миксом.
      kinetics.loadState(payload.kinetics);
      fastPoisons.loadState(payload.isotopes);
      rodSystem.loadState(payload.rods);
      burnupModel.loadState(payload.burnup);
      // v1.7: формат состояния (v1) не содержит раздельных Xe_top/Xe_bottom —
      // при загрузке зонные экземпляры пересинхронизируются СИММЕТРИЧНО от
      // того же вектора, что и глобальный fastPoisons. Известное упрощение:
      // если на момент сохранения был реальный осевой перекос, он теряется
      // при загрузке (аналогично уже принятому риску неатомарности загрузки
      // burnup/rods — см. AGENT_HANDOFF.md). Формат v2 с раздельным
      // сохранением зон — возможное будущее расширение, не сделано сейчас.
      fastPoisonsTop.loadState(payload.isotopes);
      fastPoisonsBottom.loadState(payload.isotopes);
      fastPoisonsLeft.loadState(payload.isotopes); // v2.5
      fastPoisonsRight.loadState(payload.isotopes);
      // Скорость сохраняется в файле для справки, но НЕ восстанавливается
      // автоматически — как и после Горячего/Холодного старта, оператор
      // сознательно разгоняется заново (та же логика, что и авто-сброс
      // скорости на ×1 при alarm — не подсовывать разгон незаметно).
      afterStartReset(label);
      return { ok: true };
    } catch (e) {
      diagnostics.log(
        kinetics.t,
        'alarm',
        `Не удалось загрузить состояние: ${e.message}. Модель могла остаться в смешанном состоянии — рекомендуется Горячий или Холодный старт`,
        'system',
        buildSnapshot()
      );
      return { ok: false, error: e.message };
    }
  }

  function importStateFromFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
      let payload;
      try {
        payload = JSON.parse(reader.result);
      } catch (e) {
        diagnostics.log(kinetics.t, 'alarm', `Не удалось загрузить состояние: файл повреждён или не JSON (${e.message})`, 'system', buildSnapshot());
        return;
      }
      applyStatePayload(payload, `Состояние загружено из файла (сохранено: ${payload.savedAt || 'неизвестно'})`);
    };
    reader.readAsText(file);
  }

  document.getElementById('btn-save-state').addEventListener('click', exportStateToJson);

  const loadStateInput = document.getElementById('load-state-input');
  document.getElementById('btn-load-state').addEventListener('click', () => loadStateInput.click());
  loadStateInput.addEventListener('change', () => {
    if (loadStateInput.files && loadStateInput.files[0]) {
      importStateFromFile(loadStateInput.files[0]);
    }
    loadStateInput.value = ''; // сброс, чтобы можно было загрузить тот же файл повторно
  });

  /**
   * Загружает файл .scenario.json в scenarioEngine. Не трогает состояние
   * реактора (в отличие от importStateFromFile/applyStatePayload) — только
   * цели/сообщения поверх уже идущей симуляции. rebase(kinetics.t) сразу
   * после успешной load(): scenarioTimeSec целей вроде "продержаться N секунд
   * после старта сценария" должен считаться от момента ЗАГРУЗКИ, а не от
   * произвольного kinetics.t=0 (движок сам это не знает — он получает
   * modelTimeSec только через load()/rebase(), а не читает kinetics
   * напрямую, см. SCENARIO_ENGINE_DESIGN.md).
   */
  function importScenarioFromFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
      let payload;
      try {
        payload = JSON.parse(reader.result);
      } catch (e) {
        diagnostics.log(kinetics.t, 'alarm', `Не удалось загрузить сценарий: файл повреждён или не JSON (${e.message})`, 'scenario', buildSnapshot());
        return;
      }
      const result = scenarioEngine.load(payload);
      if (result.ok) {
        diagnostics.log(kinetics.t, 'info', `Сценарий загружен: «${scenarioEngine.getMeta().title}»`, 'scenario', buildSnapshot());
      } else {
        diagnostics.log(kinetics.t, 'alarm', `Не удалось загрузить сценарий: ${result.error}`, 'scenario', buildSnapshot());
      }
    };
    reader.readAsText(file);
  }

  const loadScenarioInput = document.getElementById('load-scenario-input');
  document.getElementById('btn-load-scenario').addEventListener('click', () => loadScenarioInput.click());
  loadScenarioInput.addEventListener('change', () => {
    if (loadScenarioInput.files && loadScenarioInput.files[0]) {
      importScenarioFromFile(loadScenarioInput.files[0]);
    }
    loadScenarioInput.value = '';
  });

  /**
   * Загружает файл .lesson.json — состояние И сценарий вместе, одним файлом
   * (см. LESSON_FORMAT_SPEC.md). В отличие от importScenarioFromFile(), ЭТА
   * загрузка ТРОГАЕТ состояние реактора (через applyStatePayload — тот же
   * код, что и «Загрузить состояние», просто источник не файл с диска, а
   * вложенный объект payload.state).
   *
   * ПОРЯДОК: сначала сценарий, потом состояние — НАМЕРЕННОЕ отступление от
   * порядка, предложенного в LESSON_FORMAT_SPEC.md (там: state, потом
   * scenario). Причины две:
   * 1) diagnostics.log() троттлит не-alarm записи не чаще раза в 200мс
   *    (см. diagnostics.js) — два раздельных info-сообщения подряд («Урок
   *    загружен: состояние применено» + «Сценарий урока загружен») идут
   *    практически одновременно и второе тихо проглатывается (найдено
   *    именно так — headless-проверкой, не по чтению кода: goals
   *    отрисовывались правильно, а вторая запись в журнале не появлялась
   *    вообще, без исключения). Загружая сценарий первым, можно составить
   *    ОДНО общее сообщение об успехе и отдать его единственным вызовом
   *    log() — через label, который всё равно уходит в applyStatePayload.
   * 2) Если файл урока битый именно в части scenario, при таком порядке
   *    состояние реактора вообще не будет тронуто — откат не нужен,
   *    реактор остаётся в прежнем, известном состоянии. При обратном
   *    порядке (как в спеке) пришлось бы либо мириться с тем, что state уже
   *    подменили, а сценарий не загрузился, либо городить откат.
   */
  function importLessonFromFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
      let payload;
      try {
        payload = JSON.parse(reader.result);
      } catch (e) {
        diagnostics.log(kinetics.t, 'alarm', `Не удалось загрузить урок: файл повреждён или не JSON (${e.message})`, 'scenario', buildSnapshot());
        return;
      }
      if (!payload || typeof payload !== 'object' || !payload.state || !payload.scenario) {
        diagnostics.log(kinetics.t, 'alarm', 'Не удалось загрузить урок: файл повреждён — отсутствует state или scenario', 'scenario', buildSnapshot());
        return;
      }
      const scenarioResult = scenarioEngine.load(payload.scenario);
      if (!scenarioResult.ok) {
        diagnostics.log(kinetics.t, 'alarm', `Не удалось загрузить урок: сценарий повреждён (${scenarioResult.error}), состояние реактора не трогали`, 'scenario', buildSnapshot());
        return;
      }
      const label = `Урок загружен: «${payload.title || payload.id || 'без названия'}» — состояние и сценарий применены`;
      const stateResult = applyStatePayload(payload.state, label);
      if (!stateResult.ok) {
        // applyStatePayload уже сам написал alarm в журнал с подробностями
        // (это alarm — троттлингу не подчиняется, см. diagnostics.log()).
        // Сценарий при этом остаётся загруженным — состояние не применилось,
        // но это лучше, чем откатывать уже закоммиченный scenarioEngine.load().
      }
    };
    reader.readAsText(file);
  }

  const loadLessonInput = document.getElementById('load-lesson-input');
  document.getElementById('btn-load-lesson').addEventListener('click', () => loadLessonInput.click());
  loadLessonInput.addEventListener('change', () => {
    if (loadLessonInput.files && loadLessonInput.files[0]) {
      importLessonFromFile(loadLessonInput.files[0]);
    }
    loadLessonInput.value = '';
  });

  document.getElementById('btn-reset-scenario').addEventListener('click', () => {
    if (!scenarioEngine.isLoaded()) return; // кнопка и так задизейблена, но не полагаемся только на это
    scenarioEngine.resetAll();
    diagnostics.log(kinetics.t, 'info', 'Прогресс целей сценария сброшен к началу — сам сценарий остался загружен', 'scenario', buildSnapshot());
  });

  let lastTs = null;

  function frame(ts) {
    if (lastTs === null) lastTs = ts;
    let realDt = (ts - lastTs) / 1000;
    lastTs = ts;
    realDt = Math.min(realDt, 0.25); // защита от скачка при переключении вкладки

    // v2.3 — faults[] сценария применяются к физике ДО шага (используя
    // значение, посчитанное scenarioEngine на ПРОШЛОМ кадре — сама
    // scenarioEngine.tick() ниже, после snap; отставание на 1 кадр,
    // тот же порядок уже принят в этом файле, см. diagnostics.evaluate()).
    if (scenarioEngine.isLoaded()) {
      const faultEffects = scenarioEngine.getActiveFaultEffects();
      if (typeof faultEffects.coolantFlowFraction === 'number') {
        kinetics.setCoolantFlowFraction(faultEffects.coolantFlowFraction);
      }
    }

    if (simRunning) {
      const dt = realDt * simSpeed; // модельное время с учётом ускорения
      rodSystem.update(dt);
      kinetics.step(dt);
      fastPoisons.step(dt);
      fastPoisonsTop.step(dt);
      fastPoisonsBottom.step(dt);
      fastPoisonsLeft.step(dt); // v2.5
      fastPoisonsRight.step(dt);
      burnupModel.update(dt);
    }
    // Пока simRunning=false — физика не шагает, ниже просто перерисовывается
    // текущее (статичное) состояние. Оператор может двигать стержни/пресеты
    // и до "Старт" — это не физика, а подготовка панели управления.

    // Debounce записей о движении стержней: "остывшие" (без новых кликов
    // ROD_LOG_DEBOUNCE_MS реального времени) изменения сбрасываются в журнал
    // одной сводной строкой. Проверяется каждый кадр независимо от simRunning/
    // скорости — это UI-действие оператора, а не часть физики.
    const nowMs = performance.now();
    Object.keys(_rodChangePending).forEach((id) => {
      if (nowMs - _rodChangePending[id].lastChangeRealMs >= ROD_LOG_DEBOUNCE_MS) {
        flushRodChangeLog(id);
      }
    });

    const snap = buildSnapshot();

    // v1.9: evaluate() перенесён сюда, до отрисовки показометров — иначе
    // diagnostics.isStuckInPit() в updateReadouts() отдавал бы состояние с
    // ПРЕДЫДУЩЕГО кадра (evaluate ещё не пересчитан в этом тике). Сам
    // evaluate() ничего не рисует, только считает — переставить его раньше
    // безопасно.
    diagnostics.evaluate(kinetics.t, snap);

    // v2.3 — терминальная авария. РЕАЛЬНОЕ время (realDt, не dt=realDt*simSpeed)
    // — тот же принцип, что и у scenarioEngine.tick() ниже (см. комментарий
    // там): иначе на ×3600 авария происходила бы за долю реальной секунды.
    // Работает ВСЕГДА (не только при загруженном сценарии) — см.
    // AGENT_HANDOFF.md, "План новой физики".
    let accidentResult = { triggered: accidentMonitor.isTriggered(), reason: accidentMonitor.getReason(), mostUrgent: null };
    if (simRunning && !accidentMonitor.isTriggered()) {
      const accidentConditions = {
        fuelTempAlarm: diagnostics._fuelTempZone(snap.fuelTemp) === 'alarm',
        overpower: snap.power >= 1.5, // "overscale" — см. RBMK_PARAMS/diagnostics._powerZone (сознательно НЕ _powerSeverity: тот alarm уже с 109%, здесь порог именно 150%, согласовано отдельно)
        promptCritical: snap.rhoBeta >= 1.0,
        coolantFlowRisk: diagnostics._coolantFlowZone(snap.coolantFlowFraction) === 'alarm',
      };
      accidentResult = accidentMonitor.tick(accidentConditions, realDt);
      if (accidentResult.triggered) {
        reactorDestroyed = true;
        simRunning = false;
        rodControlsLocked = true;
        ControlsPanel.setScramButtonLocked(true);
        ControlsPanel.setSpeedButtonsLocked(true);
        ControlsPanel.lockRunControlsForAccident();
        ControlsPanel.setStartModeButtonsLocked(false); // иначе Х/Г-старт остаются задизейбленными и восстановиться нельзя
        const msg = `АВАРИЯ: повреждение активной зоны — причина: ${accidentResult.reason}`;
        diagnostics.log(kinetics.t, 'alarm', msg, 'system', snap);
        Dashboard.updateStatus(msg, true);
      }
    }
    Dashboard.updateDangerCountdown(accidentResult.mostUrgent);

    // v1.19: движок сценариев тикает РЕАЛЬНЫМ временем (realDt) — то, что
    // прошло на часах, а не модельное время реактора. Иначе на ×60/×300
    // "удержать 60 секунд" пролетало бы за долю реальной секунды (найдено
    // и исправлено по замечанию пользователя, см. AGENT_HANDOFF.md v1.19).
    if (scenarioEngine.isLoaded()) {
      scenarioEngine.tick(snap, realDt, simRunning);
      // Сообщения сценария идут в уже существующий журнал событий, с
      // отдельным source='scenario' — отдельной ленты для них специально не
      // заводили (см. обсуждение места UI). severity у сообщения ('info'/
      // 'caution') совпадает по значениям с diagnostics.log(), маппинг не нужен.
      scenarioEngine.getActiveMessages().forEach((m) => {
        diagnostics.log(kinetics.t, m.severity, m.text, 'scenario', snap);
      });
    }
    Dashboard.renderScenarioPanel(scenarioEngine.isLoaded() ? scenarioEngine.getMeta() : null, scenarioEngine.isLoaded() ? scenarioEngine.getGoalsState() : []);

    Dashboard.updateGauge(kinetics.power);
    Dashboard.updateReadouts(kinetics, kinetics.t, diagnostics.isStuckInPit());
    Dashboard.updateReactivity(snap.rhoAbs, rodSystem.betaTotal, kinetics.t);
    Dashboard.renderRodBank(rodSystem, rodControlsLocked, snap);
    Dashboard.renderChart(kinetics.history);
    Dashboard.renderPoisonChart(fastPoisons.history);
    Dashboard.renderDopplerVoidChart(kinetics.history);
    Dashboard.renderComposition(burnupModel.getComposition());
    Dashboard.renderThermal(kinetics.history, snap);
    Dashboard.renderCoreReadouts(snap, kinetics.t);
    Dashboard.renderReactorSecondaryReadouts(snap, kinetics.t);
    ControlsPanel.updateBurnupReadout(burnupModel);

    Dashboard.renderEventLog(diagnostics.events, diagnostics._logVersion);
    Dashboard.renderAnnunciator(diagnostics.getAnnunciatorState(snap));
    ControlsPanel.updateReleaseScramButton(rodSystem.scramActive);

    if (reactorTimerEl) reactorTimerEl.textContent = formatModelTimeLong(kinetics.t);

    // Авто-защита от разбалансировки на невнимательности: если оператор
    // разогнал что-то на большой скорости и не заметил — принудительно
    // возвращаем ×1 и блокируем разгон скорости, пока мнемопанель не станет
    // полностью "чистой". Не авто-повышаем скорость обратно — оператор сам
    // решает, когда снова ускоряться.
    if (simRunning && !speedLocked && simSpeed > 1 && diagnostics.hasSpeedLockAlarm(snap)) {
      simSpeed = 1;
      speedLocked = true;
      ControlsPanel.selectSpeed(1);
      ControlsPanel.setSpeedButtonsLocked(true);
      diagnostics.log(kinetics.t, 'alarm', 'Автоматический сброс скорости до ×1 — параметр вышел за допустимый диапазон, регулятор скорости заблокирован до стабилизации', 'system', snap);
    }
    if (speedLocked && diagnostics.isFullyNormal(snap)) {
      speedLocked = false;
      ControlsPanel.setSpeedButtonsLocked(false);
      diagnostics.log(kinetics.t, 'info', 'Реактор стабилизирован — регулятор скорости разблокирован', 'system', snap);
    }

    // Статусные сообщения по состоянию
    // v2.3 — если реактор уже разрушен, статус-строка держит аварийное
    // сообщение постоянно — без этой ветки её тут же перетёрло бы либо
    // "ПРЕВЫШЕНИЕ ШКАЛЫ" (если мощность всё ещё >150%), либо очисткой по
    // ветке !simRunning (simRunning уже false после аварии) — на этом же кадре.
    if (reactorDestroyed) {
      // ничего не делаем — сообщение уже выставлено в момент срабатывания аварии выше
    } else if (kinetics.power > 1.5) {
      Dashboard.updateStatus('ПРЕВЫШЕНИЕ ШКАЛЫ ИНДИКАТОРА — мощность выше 150%', true);
    } else if (rodSystem.scramActive && rodSystem.isFullyInserted()) {
      Dashboard.updateStatus('АЗ-5 завершена — стержни полностью введены', false);
    } else if (rodSystem.scramActive) {
      Dashboard.updateStatus('АЗ-5 ИНИЦИИРОВАНА — аварийный ввод стержней', true);
    } else if (!simRunning) {
      Dashboard.updateStatus('', false);
    } else {
      // Раньше здесь не было ветки — статус "зависал" на последнем алармовом
      // тексте даже после того, как условие переставало выполняться (баг:
      // "ПРЕВЫШЕНИЕ ШКАЛЫ ИНДИКАТОРА" горело постоянно после одного разового
      // превышения 150%). Явно очищаем строку, когда ни одно из условий выше
      // не выполняется.
      Dashboard.updateStatus('', false);
    }

    requestAnimationFrame(frame);
  }

  requestAnimationFrame(frame);
})();
