// diagnostics.js
// Диагностический слой: не влияет на физику, только наблюдает за состоянием
// модели и переводит его в человеко-читаемые события и сводку состояния.
//
// Событие создаётся только при ПЕРЕСЕЧЕНИИ порога (edge-trigger), а не на
// каждом кадре — иначе лента событий мгновенно захлебнётся.

class DiagnosticsEngine {
  constructor() {
    this.events = []; // {t, severity: 'info'|'caution'|'alarm', text, source} — кольцевой буфер для ленты в UI
    // v1.20: версия журнала — инкрементируется на КАЖДЫЙ log() и на reset().
    // Раньше Dashboard.renderEventLog() сравнивал только events.length, а
    // reset() обнуляет массив и afterStartReset() сразу же пишет одну новую
    // запись — итоговая ДЛИНА (1) часто совпадает с длиной ДО сброса (тоже
    // 1, например сразу после загрузки страницы), рендер тогда ошибочно
    // пропускался, хотя содержимое единственной записи полностью другое.
    // Найдено headless-проверкой при добавлении «Загрузить урок»: реальные
    // данные в diagnostics.events были верны, а DOM молча не обновлялся.
    this._logVersion = 0;
    this.maxEvents = 200;

    // Полная история сессии — БЕЗ потолка, для экспорта в файл. events
    // (выше) намеренно ограничен для ленты на экране, но экспорт должен
    // отдавать всё, что реально произошло за сессию, а не последние 200
    // строк — иначе начало длинной сессии молча теряется при выгрузке.
    this.fullHistory = [];

    // Минимальный интервал между НЕ-alarm записями — считается по РЕАЛЬНОМУ
    // времени (мс на часах пользователя), а не по модельному: модельное время
    // масштабируется регулятором скорости (×1..×3600), и троттлинг в
    // модельных секундах на высокой скорости фактически переставал работать
    // (3 модельные секунды на ×3600 — это 0.0008 реальной секунды). Alarm-
    // события по-прежнему пишутся без задержки.
    this.minLogIntervalRealMs = 200;
    this._lastNonAlarmLogRealMs = -Infinity;

    // Предыдущие "зоны" для edge-trigger переходов
    this._prevPowerZone = 'normal';
    this._prevReactivityZone = 'negative';
    this._prevPeriodZone = 'stable';
    this._prevScramActive = false;
    this._prevScramComplete = false;
    this._rodLimitState = {}; // id -> 'mid'|'in'|'out'
    this._prevXenonZone = 'normal';
    this._prevSamariumZone = 'normal';
    this._prevBurnupMode = null;
    this._prevStuckInPit = false;
    this._prevFuelTempZone = 'normal';
    this._prevOzrZone = 'normal';
    this._prevAxialZone = 'normal'; // v1.7 — Пространственная модель, п.2
    this._prevAzimuthZone = 'normal'; // v2.5 — вторая ось (лево/право)

    // v1.9 — «застревание в яме», обобщённая версия (см. AGENT_HANDOFF.md).
    // Раньше признаком было «все группы стержней выведены на ≥95%» — жёсткая
    // и редко достижимая метка (в реальной сессии оператор обычно выводит
    // стержни лишь частично и застревает так и не дойдя до упора). Теперь —
    // персистентность по модельному времени в зоне «мощность ниже порога
    // отображения (0.05%) И (реактивность всё ещё заметно отрицательна ИЛИ
    // Xe-135 заметно выше равновесия)»: нужно проторчать в этой зоне дольше
    // stuckInPitPersistSec модельных секунд подряд, а не мгновенно попасть в
    // неё (иначе сообщение ложно срабатывало бы сразу на Холодном старте —
    // там те же условия по мощности/реактивности выполняются с первого
    // кадра, просто оператор ещё ничего не успел сделать).
    //
    // v1.10 — регрессия по реальному логу сессии (см. AGENT_HANDOFF.md):
    // условие ловило только "глубокую" фазу (ρ < -0.05β), но в реальной
    // сессии ρ вышла из глубокого минуса до -0.05β всего за ~30с — быстрее
    // 45с персистентности — а мощность ещё ~500с после этого оставалась
    // ниже порога отображения: реактор застрял уже в около-критическом
    // болтании ρ около нуля, а не в глубоком минусе. Условие расширено
    // ИЛИ-веткой по Xe-135: xenonLevel > xenonPitMarker (3.05β, чуть выше
    // равновесных 3.00) — надёжно отличает реальную иодную яму (реактор уже
    // поработал на мощности, Xe успел накопиться) от Холодного/раннего
    // старта (Xe≈0, там ветка не сработает, даже если ρ большую часть
    // времени отрицательна из-за увеличенного веса стержней при Холодном
    // старте). Обе ветки используют один и тот же таймер персистентности —
    // отдельный не нужен, зона просто определена шире.
    this.xenonPitMarker = 3.05;
    this.stuckInPitPersistSec = 45;
    this._stuckInPitElapsed = 0;
    this._stuckInPitActive = false; // публичное состояние — читает и period-блок (гасит шторм period-алярмов), и main.js/Dashboard (зелёный «живой» шеврон вместо стрелки тренда)
    this._lastEvalT = 0;
  }

  reset() {
    this.events = [];
    this._logVersion++;
    this.fullHistory = [];
    this._prevPowerZone = 'normal';
    this._prevReactivityZone = 'negative';
    this._prevPeriodZone = 'stable';
    this._prevScramActive = false;
    this._prevScramComplete = false;
    this._rodLimitState = {};
    this._prevXenonZone = 'normal';
    this._prevSamariumZone = 'normal';
    this._prevBurnupMode = null;
    this._prevStuckInPit = false;
    this._prevFuelTempZone = 'normal';
    this._prevOzrZone = 'normal';
    this._prevAxialZone = 'normal';
    this._prevAzimuthZone = 'normal';
    this._lastNonAlarmLogRealMs = -Infinity;
    this._stuckInPitElapsed = 0;
    this._stuckInPitActive = false;
    this._lastEvalT = 0;
  }

  log(t, severity, text, source, snap) {
    if (severity !== 'alarm') {
      const nowMs = performance.now();
      if (nowMs - this._lastNonAlarmLogRealMs < this.minLogIntervalRealMs) return; // слишком часто по реальным часам — пропускаем
      this._lastNonAlarmLogRealMs = nowMs;
    }
    const entry = { t, severity, text, source, snap: snap || null };
    this.events.push(entry);
    this._logVersion++;
    if (this.events.length > this.maxEvents) this.events.shift();
    // fullHistory получает ТОТ ЖЕ объект (не копию) — та же throttle-логика
    // выше уже отфильтровала спам, дублировать проверку не нужно; общая для
    // events/fullHistory ссылка на snap экономит память на длинных сессиях.
    this.fullHistory.push(entry);
  }

  // Пороги — реальные уставки АЗ РБМК: срабатывание при достижении мощности
  // ~3500 МВт (~109% Nном), см. AGENT_HANDOFF.md. Небольшой запас (103%) перед
  // "elevated" — чтобы не подсвечивать саму номинальную точку (100%) как
  // отклонение: 100% — это штатный рабочий режим, а не тревога.
  _powerZone(p) {
    if (p >= 100) return 'runaway';
    if (p >= 1.5) return 'overscale';
    if (p >= 1.09) return 'high'; // реальная уставка АЗ по мощности (~109% Nном)
    if (p >= 1.03) return 'elevated';
    return 'normal';
  }

  /** Severity для UI (мнемопанель, сводка) — единая точка правды, чтобы пороги
   *  не расходились по разным местам интерфейса (как было раньше). */
  _powerSeverity(p) {
    const zone = this._powerZone(p);
    if (zone === 'runaway' || zone === 'overscale' || zone === 'high') return 'alarm';
    if (zone === 'elevated') return 'caution';
    return 'normal';
  }

  _reactivityZone(rhoBeta) {
    if (rhoBeta >= 1.0) return 'prompt-critical';
    if (rhoBeta >= 0.3) return 'approaching';
    if (rhoBeta >= 0) return 'low-positive';
    return 'negative';
  }

  _periodZone(period) {
    if (!isFinite(period) || period <= 0) return 'stable';
    if (period < 5) return 'fast';
    if (period < 20) return 'moderate';
    return 'slow';
  }

  _xenonZone(level) {
    if (level >= 8) return 'deep';
    if (level >= 4.5) return 'elevated';
    if (level >= 1.0) return 'normal';
    return 'burned-down';
  }

  /**
   * Триггер для авто-сброса скорости моделирования (см. main.js): любой из
   * "быстрых" параметров (мощность/реактивность/период/ОЗР) вышел в alarm.
   * Защита не от физики (она уже есть — доплер), а от невнимательности
   * оператора на большой скорости. ОЗР добавлен отдельно от остальных трёх
   * (изначальных): критический ОЗР — не быстрый переходный процесс сам по
   * себе, но не менее опасное состояние, требующее внимания оператора в
   * реальном темпе, а не на ×3600.
   */
  hasSpeedLockAlarm(snap) {
    return (
      this._powerSeverity(snap.power) === 'alarm' ||
      this._reactivityZone(snap.rhoBeta) === 'prompt-critical' ||
      this._periodZone(snap.period) === 'fast' ||
      this._ozrZone(this._ozrFractionPct(snap)) === 'critical' ||
      this._coolantFlowZone(snap.coolantFlowFraction) === 'alarm'
    );
  }

  /** Условие разблокировки регулятора скорости — нет активных ALARM на мнемопанели.
   *  CAUTION (например, самарий >1.5β, который распадается только в модельном
   *  времени) намеренно не блокирует разблокировку — иначе получается дедлок:
   *  самарий не убрать без ускорения времени, а ускорение времени заблокировано
   *  самарием. Alarm-и (реактивность >β, мощность >109%, незавершённая АЗ-5,
   *  ксенон deep, топливо alarm, ОЗР critical) по-прежнему держат скорость
   *  на ×1. */
  isFullyNormal(snap) {
    return this.getAnnunciatorState(snap).every((t) => t.severity !== 'alarm');
  }

  _samariumZone(level) {
    if (level >= 1.5) return 'elevated';
    if (level >= 0.5) return 'normal';
    return 'low';
  }

  _fuelTempZone(t) {
    if (t >= RBMK_PARAMS.thermal.fuelTempAlarmC) return 'alarm';
    if (t >= RBMK_PARAMS.thermal.fuelTempCautionC) return 'caution';
    return 'normal';
  }

  /**
   * v2.3 — расход теплоносителя. alarm = "риск пережога" (см. обсуждение с
   * пользователем — честная физика кризиса теплоотдачи не моделируется,
   * вместо неё эта тревога обозначает смену режима теплообмена словами).
   * caution — заметное, но пока не критическое снижение (предупреждение
   * заранее, чтобы оператор успел среагировать до самого порога).
   */
  _coolantFlowZone(flowFraction) {
    if (flowFraction < RBMK_PARAMS.thermal.coolantFlowRiskFraction) return 'alarm';
    if (flowFraction < 0.6) return 'caution';
    return 'normal';
  }

  /** Доля ОЗР от максимально возможного (все группы введены), 0..100%. */
  _ozrFractionPct(snap) {
    if (!(snap.ozrMaxBeta > 0)) return 100;
    return (snap.ozrBeta / snap.ozrMaxBeta) * 100;
  }

  // Пороги стилизованы под реальное соотношение уставок РБМК (проектный
  // минимум ~30 стержней / порог АЗ по ОЗР ~15 стержней из ~211 стержней
  // СУЗ — то есть ~14% и ~7% от полного числа). Это НЕ точное воспроизведение
  // (архитектура модели — несколько укрупнённых групп, не 211 отдельных
  // стержней), а стилизация того же порядка, см. AGENT_HANDOFF.md.
  _ozrZone(fractionPct) {
    if (fractionPct < 7) return 'critical';
    if (fractionPct < 15) return 'low';
    return 'normal';
  }

  /**
   * Осевой перекос ксенона (v1.7, Пространственная модель п.2) —
   * |Xe_top − Xe_bottom|, в β. Пороги стилизованы (не откалиброваны под
   * честный расчёт), выбраны так, чтобы "significant" соответствовал
   * заметной, но не экстремальной доле от типичного равновесного Xe (~3β).
   * Само по себе это НЕ авария (см. getAnnunciatorState) — предупреждает
   * оператора, что зоны разъехались, а не то, что реактор в опасности.
   */
  _axialZone(dXeAbs) {
    if (dXeAbs >= 2.0) return 'significant';
    if (dXeAbs >= 0.8) return 'elevated';
    return 'normal';
  }

  /** v2.5 — та же шкала, для второй (лево/право) оси перекоса. */
  _azimuthZone(dXeAbs) {
    if (dXeAbs >= 2.0) return 'significant';
    if (dXeAbs >= 0.8) return 'elevated';
    return 'normal';
  }

  /**
   * @param {number} t - модельное время, с
   * @param {object} snap - снимок состояния:
   *   { power, rhoAbs, rhoBeta, period, rodGroups: [{id,label,position}],
   *     scramActive, scramComplete }
   */
  evaluate(t, snap) {
    // --- Застревание в яме (персистентность) — считается первым делом,
    // т.к. её результат (this._stuckInPitActive) нужен блоку "Период" ниже,
    // чтобы не сыпать десятками period-алярмов, пока и так известно, что
    // реактор просто медленно ползёт из глубокого провала. Сама текстовая
    // caution-запись при переходе normal->stuck пишется отдельно, ниже (там
    // же, где раньше было это условие) — здесь только обновление таймера.
    const dt = Math.max(0, t - this._lastEvalT);
    this._lastEvalT = t;
    const inPitZone =
      !snap.scramActive &&
      snap.power < 0.0005 &&
      (snap.rhoBeta < -0.05 || snap.xenonLevel > this.xenonPitMarker);
    this._stuckInPitElapsed = inPitZone ? this._stuckInPitElapsed + dt : 0;
    this._stuckInPitActive = this._stuckInPitElapsed >= this.stuckInPitPersistSec;

    // --- Мощность ---
    const pZone = this._powerZone(snap.power);
    if (pZone !== this._prevPowerZone) {
      const msgs = {
        elevated: ['caution', 'Мощность превысила 103% N0'],
        high: ['alarm', 'Мощность выше уставки АЗ по мощности (109% N0 / 3500 МВт) — в реальности реактор уже был бы заглушен автоматически'],
        overscale: ['alarm', 'Мощность выше 150% N0 — превышение шкалы индикатора'],
        runaway: ['alarm', 'Неограниченный разгон — доплеровская ОС (Stage 3) не успевает скомпенсировать вставленную реактивность'],
        normal: ['info', 'Мощность вернулась в номинальный диапазон'],
      };
      const [sev, text] = msgs[pZone] || ['info', `Мощность: зона ${pZone}`];
      this.log(t, sev, text, 'power', snap);
      this._prevPowerZone = pZone;
    }

    // --- Реактивность ---
    const rZone = this._reactivityZone(snap.rhoBeta);
    if (rZone !== this._prevReactivityZone) {
      const msgs = {
        'low-positive': ['info', 'Реактивность положительна, реактор медленно разгоняется'],
        approaching: ['caution', 'Реактивность растёт, приближение к порогу мгновенной критичности (ρ→β)'],
        'prompt-critical': ['alarm', 'РЕАКТИВНОСТЬ ПРЕВЫСИЛА β — разгон на мгновенных нейтронах'],
        negative: ['info', 'Реактивность отрицательна, реактор глушится или стабилен'],
      };
      const [sev, text] = msgs[rZone] || ['info', `Реактивность: зона ${rZone}`];
      this.log(t, sev, text, 'reactivity', snap);
      this._prevReactivityZone = rZone;
    }

    // --- Период (только если мощность растёт, период положителен) ---
    // v1.9: пока активно застревание в яме (this._stuckInPitActive) — период
    // здесь физически честен (n/dn — величина безразмерная, работает и на
    // 0.0001%), но абсолютная мощность настолько ниже порога отображения,
    // что оператор видит "0.0% / 0 МВт" и десятки алярмов "быстрый рост
    // мощности" подряд без видимого повода. Заменено одной caution-записью
    // про застревание (см. ниже) + зелёным "живым" индикатором в Dashboard.
    const perZone = this._periodZone(snap.period);
    if (perZone !== this._prevPeriodZone && snap.period > 0 && !this._stuckInPitActive) {
      const msgs = {
        moderate: ['caution', `Период разгона ${snap.period.toFixed(1)} с — умеренный рост мощности`],
        fast: ['alarm', `Период разгона ${snap.period.toFixed(1)} с — быстрый рост мощности`],
        slow: ['info', 'Темп роста мощности замедлился'],
      };
      const entry = msgs[perZone];
      if (entry) this.log(t, entry[0], entry[1], 'period', snap);
      this._prevPeriodZone = perZone;
    }

    // --- Стержни: достижение крайних положений ---
    snap.rodGroups.forEach((g) => {
      let state = 'mid';
      if (g.position <= 0.5) state = 'in';
      else if (g.position >= 99.5) state = 'out';

      const prev = this._rodLimitState[g.id] || 'mid';
      if (state !== prev) {
        if (state === 'in') this.log(t, 'info', `${g.label} полностью введена`, 'rods', snap);
        if (state === 'out') this.log(t, 'caution', `${g.label} полностью выведена — исчерпан ход стержня`, 'rods', snap);
        this._rodLimitState[g.id] = state;
      }
    });

    // --- АЗ-5 ---
    if (snap.scramActive && !this._prevScramActive) {
      this.log(t, 'alarm', 'АЗ-5 ИНИЦИИРОВАНА — аварийный ввод всех стержней', 'scram', snap);
    }
    if (snap.scramActive && snap.scramComplete && !this._prevScramComplete) {
      this.log(t, 'info', 'АЗ-5 завершена — все стержни введены в активную зону', 'scram', snap);
    }
    if (!snap.scramActive && this._prevScramActive) {
      this.log(t, 'info', 'Ручное управление стержнями восстановлено', 'scram', snap);
    }
    this._prevScramActive = snap.scramActive;
    this._prevScramComplete = snap.scramActive && snap.scramComplete;

    // --- Ксенон-135 ---
    const xeZone = this._xenonZone(snap.xenonLevel);
    if (xeZone !== this._prevXenonZone) {
      const msgs = {
        'burned-down': ['info', 'Концентрация Xe-135 ниже равновесной — реактор недавно работал на повышенной мощности'],
        normal: ['info', 'Xe-135 в районе равновесного уровня'],
        elevated: ['caution', 'Xe-135 растёт выше равновесия — формируется йодная яма'],
        deep: ['alarm', 'Глубокая йодная яма — Xe-135 может не дать вывести реактор на мощность'],
      };
      const [sev, text] = msgs[xeZone] || ['info', `Xe-135: зона ${xeZone}`];
      this.log(t, sev, text, 'xenon', snap);
      this._prevXenonZone = xeZone;
    }

    // --- Самарий-149 ---
    const smZone = this._samariumZone(snap.samariumLevel);
    if (smZone !== this._prevSamariumZone) {
      const msgs = {
        low: ['info', 'Sm-149 ниже обычного уровня'],
        normal: ['info', 'Sm-149 в районе равновесного уровня'],
        elevated: ['caution', 'Sm-149 накапливается выше равновесия (самарий не распадается — эффект более долгоживущий, чем ксенон)'],
      };
      const [sev, text] = msgs[smZone] || ['info', `Sm-149: зона ${smZone}`];
      this.log(t, sev, text, 'samarium', snap);
      this._prevSamariumZone = smZone;
    }

    // --- Температура топлива (Stage 3) ---
    const ftZone = this._fuelTempZone(snap.fuelTemp);
    if (ftZone !== this._prevFuelTempZone) {
      const msgs = {
        normal: ['info', 'Температура топлива вернулась в штатный диапазон'],
        caution: ['caution', `Температура топлива превысила ${RBMK_PARAMS.thermal.fuelTempCautionC}°C — растёт доплеровская отрицательная обратная связь`],
        alarm: ['alarm', `Температура топлива превысила проектный предел оболочки твэла (${RBMK_PARAMS.thermal.fuelTempAlarmC}°C)`],
      };
      const [sev, text] = msgs[ftZone] || ['info', `Температура топлива: зона ${ftZone}`];
      this.log(t, sev, text, 'thermal', snap);
      this._prevFuelTempZone = ftZone;
    }

    // --- ОЗР (оперативный запас реактивности) ---
    const ozrZone = this._ozrZone(this._ozrFractionPct(snap));
    if (ozrZone !== this._prevOzrZone) {
      const msgs = {
        normal: ['info', 'ОЗР в пределах нормы'],
        low: ['caution', 'ОЗР ниже рекомендованного минимума — мало введённых стержней, компенсирующий резерв мал'],
        critical: ['alarm', 'ОЗР критически низок — в реальном РБМК на этом уровне сработала бы блокировка на снижение мощности/АЗ; концевой эффект при АЗ-5 сейчас почти нечем компенсировать'],
      };
      const [sev, text] = msgs[ozrZone] || ['info', `ОЗР: зона ${ozrZone}`];
      this.log(t, sev, text, 'ozr', snap);
      this._prevOzrZone = ozrZone;
    }

    // --- Осевой перекос ксенона (v1.7, Пространственная модель п.2) ---
    const axialZone = this._axialZone(Math.abs(snap.axialOffsetBeta));
    if (axialZone !== this._prevAxialZone) {
      const sign = snap.axialOffsetBeta >= 0 ? 'верх' : 'низ';
      const msgs = {
        normal: ['info', 'Осевой перекос Xe-135 вернулся в норму — зоны сбалансированы'],
        elevated: ['info', `Осевой перекос Xe-135 растёт (сейчас больше в зоне «${sign}») — асимметрия ввода стержней верх/УСП`],
        significant: ['caution', `Значительный осевой перекос Xe-135 (больше в зоне «${sign}») — при низком ОЗР это опасное сочетание для АЗ-5 (см. концевой эффект)`],
      };
      const [sev, text] = msgs[axialZone] || ['info', `Осевой перекос: зона ${axialZone}`];
      this.log(t, sev, text, 'axial', snap);
      this._prevAxialZone = axialZone;
    }

    // --- Азимутальный перекос ксенона (v2.5, Пространственная модель, вторая ось) ---
    const azimuthZone = this._azimuthZone(Math.abs(snap.azimuthOffsetBeta));
    if (azimuthZone !== this._prevAzimuthZone) {
      const sign = snap.azimuthOffsetBeta >= 0 ? 'лево' : 'право';
      const msgs = {
        normal: ['info', 'Азимутальный перекос Xe-135 вернулся в норму — половины сбалансированы'],
        elevated: ['info', `Азимутальный перекос Xe-135 растёт (сейчас больше в половине «${sign}») — асимметрия ввода групп 1/2`],
        significant: ['caution', `Значительный азимутальный перекос Xe-135 (больше в половине «${sign}») — выровняйте группы 1/2`],
      };
      const [sev, text] = msgs[azimuthZone] || ['info', `Азимутальный перекос: зона ${azimuthZone}`];
      this.log(t, sev, text, 'azimuth', snap);
      this._prevAzimuthZone = azimuthZone;
    }

    // --- Режим наработки топлива ---
    if (snap.burnupMode !== this._prevBurnupMode) {
      if (this._prevBurnupMode !== null) {
        const text = snap.burnupMode === 'accelerated'
          ? 'Включён ускоренный режим наработки топлива (кампания идёт быстрее реального времени)'
          : 'Возраст топлива зафиксирован — наработка приостановлена';
        this.log(t, 'info', text, 'burnup', snap);
      }
      this._prevBurnupMode = snap.burnupMode;
    }

    // --- Застревание в яме без АЗ-5 (v1.9, обобщено — см. вычисление
    //     this._stuckInPitActive в начале evaluate()). Раньше требовалось,
    //     чтобы ВСЕ группы стояли на ≥95% — реальные сессии застревают и при
    //     частично выведенных стержнях, условие почти никогда не срабатывало.
    //     Теперь — персистентность по времени в зоне "мощность ниже порога
    //     отображения и реактивность заметно отрицательна", без требований к
    //     позициям стержней. Подсказка, а не авто-исправление.
    if (this._stuckInPitActive !== this._prevStuckInPit) {
      if (this._stuckInPitActive) {
        this.log(
          t,
          'caution',
          'Реактор долго остаётся глубоко подкритичным — недостаточно оперативного запаса реактивности, чтобы перекрыть отравление. Дождитесь распада Xe-135 (или ускорьте время моделирования).',
          'xenon',
          snap
        );
      }
      this._prevStuckInPit = this._stuckInPitActive;
    }
  }

  /** Публичный геттер для UI (Dashboard) — зелёный "живой" индикатор вместо
   *  стрелки тренда мощности, пока реактор застрял ниже порога отображения
   *  (см. v1.9 выше). Не влияет на логирование, только на чтение состояния. */
  isStuckInPit() {
    return this._stuckInPitActive;
  }

  /**
   * Состояние мнемопанели БЩУ слева (не текстовая сводка, а вкл/выкл-табло):
   * загорается только когда параметр вышел за допустимый диапазон, иначе
   * плитка приглушена. Отдельно от getStateSummary(), чтобы не дублировать
   * одну и ту же информацию.
   */
  getAnnunciatorState(snap) {
    const powerSeverity = this._powerSeverity(snap.power);
    const reactSeverity = snap.rhoBeta >= 1.0 ? 'alarm' : snap.rhoBeta >= 0.3 ? 'caution' : 'normal';
    const scramSeverity = snap.scramActive && !snap.scramComplete ? 'alarm' : 'normal';
    const xenonSeverity = snap.xenonLevel >= 8 ? 'alarm' : snap.xenonLevel >= 4.5 ? 'caution' : 'normal';
    const samariumSeverity = snap.samariumLevel >= 1.5 ? 'caution' : 'normal';
    const tempSeverity = this._fuelTempZone(snap.fuelTemp);
    const ozrZone = this._ozrZone(this._ozrFractionPct(snap));
    const ozrSeverity = ozrZone === 'critical' ? 'alarm' : ozrZone === 'low' ? 'caution' : 'normal';
    // v1.7 — намеренно НЕ 'alarm' ни при каких обстоятельствах: перекос сам
    // по себе не авария (см. _axialZone) — только caution на верхнем уровне.
    const axialZone = this._axialZone(Math.abs(snap.axialOffsetBeta));
    const axialSeverity = axialZone === 'normal' ? 'normal' : 'caution';
    // v2.5 — вторая ось (лево/право): существующая плитка переименована в
    // "Перекос в-н" (была просто "Перекос"), т.к. появилась вторая ось.
    const azimuthZone = this._azimuthZone(Math.abs(snap.azimuthOffsetBeta));
    const azimuthSeverity = azimuthZone === 'normal' ? 'normal' : 'caution';
    const flowSeverity = this._coolantFlowZone(snap.coolantFlowFraction);

    return [
      { key: 'power', label: 'Мощность', severity: powerSeverity },
      { key: 'reactivity', label: 'Реактивность', severity: reactSeverity },
      { key: 'scram', label: 'СУЗ / АЗ-5', severity: scramSeverity },
      { key: 'xenon', label: 'Ксенон', severity: xenonSeverity },
      { key: 'samarium', label: 'Самарий', severity: samariumSeverity },
      { key: 'temperature', label: 'Температура', severity: tempSeverity },
      { key: 'ozr', label: 'ОЗР', severity: ozrSeverity },
      { key: 'axial', label: 'Перекос в-н', severity: axialSeverity },
      { key: 'azimuth', label: 'Перекос л-п', severity: azimuthSeverity },
      { key: 'flow', label: 'Расход', severity: flowSeverity },
    ];
  }

  /**
   * Текстовая сводка текущего состояния по подсистемам (без истории).
   */
  getStateSummary(snap) {
    const powerSeverity = this._powerSeverity(snap.power);
    const powerText = `${(snap.power * 100).toFixed(1)}% N0 · ${Math.round(snap.power * RBMK_PARAMS.nominalPowerMWt)} МВт`;

    const reactSeverity = snap.rhoBeta >= 1.0 ? 'alarm' : snap.rhoBeta >= 0.3 ? 'caution' : 'normal';
    let periodText = 'период не определён (мощность стабильна)';
    if (isFinite(snap.period) && snap.period > 0) {
      periodText = `период разгона ${snap.period.toFixed(1)} с`;
    } else if (isFinite(snap.period) && snap.period < 0) {
      periodText = `мощность снижается (период ${snap.period.toFixed(1)} с)`;
    }
    const reactText = `${snap.rhoBeta >= 0 ? '+' : ''}${snap.rhoBeta.toFixed(3)} β · ${periodText}`;

    let rodsText;
    let rodsSeverity = 'normal';
    if (snap.scramActive) {
      rodsText = snap.scramComplete ? 'АЗ-5: все группы введены' : 'АЗ-5: идёт аварийный ввод стержней';
      rodsSeverity = snap.scramComplete ? 'normal' : 'alarm';
    } else {
      // "% введено" (100 - position) — как в панели СУЗ, см. main.js:snapToLines()
      rodsText = snap.rodGroups.map((g) => `${g.label.replace('Группа ', 'Г')} ${Math.round(100 - g.position)}%`).join(' · ');
    }

    return [
      { label: 'Мощность', text: powerText, severity: powerSeverity },
      { label: 'Реактивность', text: reactText, severity: reactSeverity },
      { label: 'СУЗ', text: rodsText, severity: rodsSeverity },
      {
        label: 'Xe-135',
        text: `${snap.xenonLevel.toFixed(2)} β (экв.)`,
        severity: snap.xenonLevel >= 8 ? 'alarm' : snap.xenonLevel >= 4.5 ? 'caution' : 'normal',
      },
      {
        label: 'Sm-149',
        text: `${snap.samariumLevel.toFixed(2)} β (экв.)`,
        severity: snap.samariumLevel >= 1.5 ? 'caution' : 'normal',
      },
      {
        label: 'Топливо',
        text: `${snap.fuelTemp.toFixed(0)}°C · паросодержание ${(snap.voidFraction * 100).toFixed(0)}%`,
        severity: this._fuelTempZone(snap.fuelTemp),
      },
      {
        label: 'Расход',
        text: `${(snap.coolantFlowFraction * 100).toFixed(0)}% номинала${this._coolantFlowZone(snap.coolantFlowFraction) === 'alarm' ? ' — риск пережога' : ''}`,
        severity: this._coolantFlowZone(snap.coolantFlowFraction),
      },
      {
        label: 'Наработка',
        text: `${snap.burnupEFPD.toFixed(1)} EFPD · ${snap.burnupMode === 'accelerated' ? 'ускоренный режим' : 'зафиксирован возраст'}`,
        severity: 'normal',
      },
      {
        label: 'ОЗР',
        text: `${snap.ozrBeta.toFixed(2)} β (${this._ozrFractionPct(snap).toFixed(0)}%)`,
        severity: (() => {
          const z = this._ozrZone(this._ozrFractionPct(snap));
          return z === 'critical' ? 'alarm' : z === 'low' ? 'caution' : 'normal';
        })(),
      },
      {
        label: 'Перекос в-н',
        text: `ΔXe ${snap.axialOffsetBeta >= 0 ? '+' : ''}${snap.axialOffsetBeta.toFixed(2)} β · поток ${(snap.zoneFracTop * 100).toFixed(0)}/${(snap.zoneFracBottom * 100).toFixed(0)}%`,
        severity: this._axialZone(Math.abs(snap.axialOffsetBeta)) === 'normal' ? 'normal' : 'caution',
      },
      {
        label: 'Перекос л-п',
        text: `ΔXe ${snap.azimuthOffsetBeta >= 0 ? '+' : ''}${snap.azimuthOffsetBeta.toFixed(2)} β · поток ${(snap.azimuthFracLeft * 100).toFixed(0)}/${(snap.azimuthFracRight * 100).toFixed(0)}%`,
        severity: this._azimuthZone(Math.abs(snap.azimuthOffsetBeta)) === 'normal' ? 'normal' : 'caution',
      },
    ];
  }
}
