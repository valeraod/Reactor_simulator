// controls_panel.js
// Строит слайдеры для групп стержней и привязывает кнопки управления к модели.

const ControlsPanel = {
  SPEED_PRESETS: [
    { value: 1, label: '×1' },
    { value: 10, label: '×10' },
    { value: 60, label: '×60' },
    { value: 300, label: '×300' },
    { value: 3600, label: '×3600' },
  ],

  initSpeedControl(onSpeedChange) {
    const container = document.getElementById('speed-control');
    container.innerHTML =
      '<span class="speed-label">Скорость</span>' +
      this.SPEED_PRESETS.map((p) => `<button class="speed-btn" data-speed="${p.value}">${p.label}</button>`).join('');

    const buttons = container.querySelectorAll('button[data-speed]');
    buttons.forEach((btn) => {
      btn.addEventListener('click', () => {
        const speed = Number(btn.dataset.speed);
        buttons.forEach((b) => b.classList.toggle('active', b === btn));
        onSpeedChange(speed);
      });
    });
    // ×1 по умолчанию
    buttons[0].classList.add('active');
    this._speedButtons = buttons;
  },

  /** Блокирует/разблокирует скорости >×1 — защита от разбалансировки на невнимательности (см. AGENT_HANDOFF.md) */
  setSpeedButtonsLocked(locked) {
    if (!this._speedButtons) return;
    this._speedButtons.forEach((b) => {
      if (Number(b.dataset.speed) > 1) b.disabled = locked;
    });
  },

  /** Программно подсветить активную кнопку скорости (используется авто-сбросом на ×1) */
  selectSpeed(value) {
    if (!this._speedButtons) return;
    this._speedButtons.forEach((b) => b.classList.toggle('active', Number(b.dataset.speed) === value));
  },

  /**
   * Старт/Пауза — управляет самим ходом времени (см. main.js: simRunning).
   * До первого «Старт» физика не шагает — на экране статичное начальное
   * состояние. «Старт» одноразовый (дальше только Пауза/Продолжить), пока не
   * нажат Холодный/Горячий старт — тогда resetRunControl() возвращает всё к
   * исходному виду.
   */
  initRunControl(onStart, onPauseToggle) {
    const container = document.getElementById('run-control');
    // «Старт» изначально ЗАБЛОКИРОВАН — реактор не должен выглядеть/работать
    // до того, как оператор явно выберет режим пуска (Горячий/Холодный старт,
    // см. main.js). Разблокируется в resetRunControl(), которую дёргают
    // onHotStart/onColdStart.
    container.innerHTML = `
      <button class="run-btn" id="btn-run-start" disabled>Старт</button>
      <button class="run-btn" id="btn-run-pause" disabled>Пауза</button>
    `;
    const startBtn = document.getElementById('btn-run-start');
    const pauseBtn = document.getElementById('btn-run-pause');

    startBtn.addEventListener('click', () => {
      onStart();
      startBtn.disabled = true;
      startBtn.classList.remove('btn-start-active');
      pauseBtn.disabled = false;
      pauseBtn.textContent = 'Пауза';
      pauseBtn.classList.add('btn-pause-active');
    });

    pauseBtn.addEventListener('click', () => {
      const running = onPauseToggle(); // main.js переключает simRunning и возвращает новое значение
      pauseBtn.textContent = running ? 'Пауза' : 'Продолжить';
      pauseBtn.classList.toggle('btn-pause-active', running);
      pauseBtn.classList.toggle('btn-start-active', !running);
    });

    this._runStartBtn = startBtn;
    this._runPauseBtn = pauseBtn;
  },

  /** Возвращает кнопки Старт/Пауза в исходное состояние (Холодный/Горячий старт всегда ставит симуляцию на паузу) */
  resetRunControl() {
    if (!this._runStartBtn) return;
    this._runStartBtn.disabled = false;
    this._runStartBtn.classList.add('btn-start-active');
    this._runPauseBtn.disabled = true;
    this._runPauseBtn.textContent = 'Пауза';
    this._runPauseBtn.classList.remove('btn-pause-active', 'btn-start-active');
  },

  /**
   * v2.3 — терминальная авария ("повреждение активной зоны"): и «Старт», и
   * «Пауза»/«Продолжить» блокируются НАМЕРТВО — в отличие от обычной паузы,
   * здесь недостаточно просто задизейблить «Пауза» (оставив «Старт»
   * доступным для повторного запуска той же, уже разрушенной, активной
   * зоны). Разблокировка — только через Горячий/Холодный старт
   * (resetRunControl(), см. afterStartReset() в main.js).
   */
  lockRunControlsForAccident() {
    if (!this._runStartBtn) return;
    this._runStartBtn.disabled = true;
    this._runPauseBtn.disabled = true;
  },

  init(rodSystem, onScram, onHotStart, onColdStart, onReleaseScram, onRodChange) {
    // Полосы + кнопки шага строит dashboard.js (renderRodBank) — здесь только
    // привязываем обработчики к уже существующим кнопкам rod-inc-*/rod-dec-*.
    rodSystem.groups.forEach((g) => {
      const incBtn = document.getElementById(`rod-inc-${g.id}`);
      const decBtn = document.getElementById(`rod-dec-${g.id}`);

      if (incBtn) {
        incBtn.addEventListener('click', () => {
          const pct = Math.min(100, Math.round(g.position) + 1);
          rodSystem.setGroupPosition(g.id, pct);
          if (onRodChange) onRodChange(g.id, pct);
        });
      }
      if (decBtn) {
        decBtn.addEventListener('click', () => {
          const pct = Math.max(0, Math.round(g.position) - 1);
          rodSystem.setGroupPosition(g.id, pct);
          if (onRodChange) onRodChange(g.id, pct);
        });
      }
    });

    const scramBtn = document.getElementById('btn-scram');
    scramBtn.addEventListener('click', onScram);
    scramBtn.disabled = true; // v2.1 — багфикс: по умолчанию заблокирована, пока не нажат «Старт» (main.js вызовет setScramButtonLocked(false) в onStart())
    this._scramBtn = scramBtn;

    const releaseBtn = document.getElementById('btn-release-scram');
    releaseBtn.addEventListener('click', () => {
      if (onReleaseScram) onReleaseScram();
    });
    this._releaseBtn = releaseBtn;

    const hotBtn = document.getElementById('btn-hot-start');
    const coldBtn = document.getElementById('btn-cold-start');
    hotBtn.addEventListener('click', onHotStart);
    coldBtn.addEventListener('click', onColdStart);
    this._hotStartBtn = hotBtn;
    this._coldStartBtn = coldBtn;
  },

  /**
   * Блокирует/разблокирует выбор режима пуска (Горячий/Холодный старт).
   * Заблокировано, пока реактор реально идёт (simRunning=true в main.js) —
   * оператор не должен иметь возможность подменить состояние работающего
   * реактора у себя под ногами. На паузе — снова доступно (это единственный
   * способ переиграть пуск заново в рамках одной сессии).
   */
  setStartModeButtonsLocked(locked) {
    if (this._hotStartBtn) this._hotStartBtn.disabled = locked;
    if (this._coldStartBtn) this._coldStartBtn.disabled = locked;
  },

  /**
   * v2.1 — БАГФИКС: АЗ-5 — это тоже орган управления стержнями (аварийно
   * вставляет их), а не что-то отдельное от общего запрета "стержни
   * недоступны, пока не нажат Старт" (см. rodControlsLocked в main.js и
   * Dashboard.renderRodBank()). До этой правки кнопка «АЗ-5» никогда не
   * дизейблилась и срабатывала даже до нажатия «Старт» — обнаружено
   * пользователем.
   */
  setScramButtonLocked(locked) {
    if (this._scramBtn) this._scramBtn.disabled = locked;
  },

  /**
   * Кнопка «Снять блокировку АЗ-5» активна только пока защита реально
   * блокирует ручное управление — иначе непонятно, когда ей вообще пользоваться.
   */
  updateReleaseScramButton(scramActive) {
    if (!this._releaseBtn) return;
    this._releaseBtn.disabled = !scramActive;
  },

  initBurnupControls(burnupModel, onPresetChange) {
    const container = document.getElementById('burnup-controls');
    container.innerHTML = `
      <div class="burnup-mode-toggle">
        <button class="btn" id="burnup-mode-fixed">Фикс. возраст</button>
        <button class="btn" id="burnup-mode-accel">Ускор. кампания</button>
      </div>
      <div class="burnup-readout">Наработка: <span class="val" id="burnup-efpd-val">0.0</span> EFPD</div>
      <div class="preset-row" id="burnup-presets">
        <button class="btn" data-preset="fresh">Свежее</button>
        <button class="btn" data-preset="mid">Середина</button>
        <button class="btn" data-preset="end">Конец</button>
      </div>
    `;

    const fixedBtn = document.getElementById('burnup-mode-fixed');
    const accelBtn = document.getElementById('burnup-mode-accel');
    const presetsRow = document.getElementById('burnup-presets');
    const presetBtns = presetsRow.querySelectorAll('button[data-preset]');
    const efpdVal = document.getElementById('burnup-efpd-val');

    const syncModeButtons = () => {
      fixedBtn.classList.toggle('active', burnupModel.mode === 'fixed');
      accelBtn.classList.toggle('active', burnupModel.mode === 'accelerated');
      presetsRow.style.display = burnupModel.mode === 'fixed' ? 'flex' : 'none';
    };

    // Подсвечиваем кнопку пресета, чей EFPD совпадает с текущим (в пределах
    // погрешности) — было совсем непонятно, какой пресет сейчас активен.
    const syncPresetButtons = () => {
      presetBtns.forEach((btn) => {
        const presetEfpd = burnupModel.params.presets[btn.dataset.preset];
        btn.classList.toggle('active', Math.abs(presetEfpd - burnupModel.burnupEFPD) < 0.05);
      });
    };

    fixedBtn.addEventListener('click', () => {
      burnupModel.setMode('fixed');
      syncModeButtons();
    });
    accelBtn.addEventListener('click', () => {
      burnupModel.setMode('accelerated');
      syncModeButtons();
    });

    presetBtns.forEach((btn) => {
      btn.addEventListener('click', () => {
        burnupModel.setPreset(btn.dataset.preset);
        efpdVal.textContent = burnupModel.burnupEFPD.toFixed(1);
        syncPresetButtons();
        if (onPresetChange) onPresetChange(btn.dataset.preset, btn.textContent, burnupModel.burnupEFPD);
      });
    });

    syncModeButtons();
    syncPresetButtons();
    this._burnupEfpdVal = efpdVal;
    this._presetBtns = presetBtns;
    this._burnupModel = burnupModel;
  },

  /** Вызывается извне после сброса модели, чтобы снова подсветить пресет "Свежее". */
  syncPresetButtonsAfterReset() {
    if (!this._presetBtns || !this._burnupModel) return;
    this._presetBtns.forEach((btn) => {
      const presetEfpd = this._burnupModel.params.presets[btn.dataset.preset];
      btn.classList.toggle('active', Math.abs(presetEfpd - this._burnupModel.burnupEFPD) < 0.05);
    });
  },

  updateBurnupReadout(burnupModel) {
    if (this._burnupEfpdVal) this._burnupEfpdVal.textContent = burnupModel.burnupEFPD.toFixed(1);
  },
};
