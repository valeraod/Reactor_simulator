// dashboard.js
// Отвечает только за отрисовку — не трогает физику модели.

const Dashboard = {
  gaugeMaxValue: 1.5, // 150% по шкале индикатора
  gaugeCx: 120,
  gaugeCy: 120,
  gaugeR: 90,

  chartCtx: null,
  chartCanvas: null,

  init() {
    this.needleEl = document.getElementById('gauge-needle');
    this.powerPctEl = document.getElementById('readout-power-pct');
    this.powerMwtEl = document.getElementById('readout-power-mwt');
    this.reactivityEl = document.getElementById('readout-reactivity');
    this.periodEl = document.getElementById('readout-period');
    this.statusEl = document.getElementById('status-line');
    // v2.3 — терминальная авария: отдельный от status-line баннер обратного
    // отсчёта (status-line уже занята другими сообщениями и конфликтовала
    // бы с ним, см. обсуждение с пользователем).
    this.dangerCountdownEl = document.getElementById('danger-countdown');

    this.chartCanvas = document.getElementById('power-chart');
    this.chartCtx = this.chartCanvas.getContext('2d');

    this.rodBankEl = document.getElementById('rod-bank');
    this.annunciatorEl = document.getElementById('annunciator-grid');
    this._annunciatorBuilt = false;

    this.stateSummaryEl = document.getElementById('state-summary');
    this.eventLogEl = document.getElementById('event-log');
    this._lastLogVersion = -1; // v1.20: было _lastEventCount — см. diagnostics.js reset()/log() и renderEventLog()

    this.poisonChartCanvas = document.getElementById('poison-chart');
    this.poisonChartCtx = this.poisonChartCanvas.getContext('2d');

    this.burnupChartCanvas = document.getElementById('burnup-chart');
    this.burnupChartCtx = this.burnupChartCanvas.getContext('2d');

    this.compositionBarEl = document.getElementById('composition-bar');
    this.compositionLegendEl = document.getElementById('composition-legend');
    this.burnupControlsEl = document.getElementById('burnup-controls');

    this.thermalChartCanvas = document.getElementById('thermal-chart');
    this.thermalChartCtx = this.thermalChartCanvas.getContext('2d');
    this.thermalReadoutsEl = document.getElementById('thermal-readouts');
    this.voidGaugeFillEl = document.getElementById('void-gauge-fill');
    this.voidGaugeValEl = document.getElementById('void-gauge-val');

    this.trendPowerPctEl = document.getElementById('trend-power-pct');
    this.trendPowerMwtEl = document.getElementById('trend-power-mwt');
    this.trendReactivityEl = document.getElementById('trend-reactivity');
    this.trendPeriodEl = document.getElementById('trend-period');

    this.coreReadoutsEl = document.getElementById('core-readouts');

    this.scenarioTitleEl = document.getElementById('scenario-title');
    this.scenarioGoalsEl = document.getElementById('scenario-goals');
    this.scenarioResetBtnEl = document.getElementById('btn-reset-scenario');

    // Буфер сглаженного тренда (▲/▼/—): для каждого параметра храним историю
    // {t, v} и сравниваем текущее значение с точкой ~trendWindowSec назад —
    // сравнение с предыдущим кадром рендера было бы слишком "дёрганым"
    this._trendBuf = {};
    this._trendWindowSec = 10;
  },

  /** Сбрасывает буфер трендов — вызывается при Горячем/Холодном старте, т.к. модельное время обнуляется */
  resetTrends() {
    this._trendBuf = {};
  },

  /**
   * Сглаженный тренд параметра: ▲ рост / ▼ падение / — без изменений,
   * относительно значения ~trendWindowSec модельных секунд назад (не относительно
   * предыдущего кадра рендера — иначе стрелка дёргалась бы на шумных величинах).
   * @param {string} key - уникальный ключ параметра
   * @param {number} value - текущее значение
   * @param {number} t - текущее модельное время, с
   * @param {number} eps - порог нечувствительности (в единицах value) — стрелка
   *   появляется только если изменение заметно на отображаемой точности числа
   */
  _trend(key, value, t, eps) {
    if (!isFinite(value)) return 'flat';
    const buf = this._trendBuf[key] || (this._trendBuf[key] = []);
    buf.push({ t, v: value });
    const windowSec = this._trendWindowSec;
    // Не даём буферу расти бесконечно — не нужна история глубже пары окон
    while (buf.length > 2 && t - buf[0].t > windowSec * 4) buf.shift();
    let ref = buf[0];
    for (const p of buf) {
      if (t - p.t >= windowSec) ref = p;
      else break;
    }
    const diff = value - ref.v;
    if (!isFinite(diff)) return 'flat';
    if (diff > eps) return 'up';
    if (diff < -eps) return 'down';
    return 'flat';
  },

  _trendArrow(trend) {
    return trend === 'up' ? '▲' : trend === 'down' ? '▼' : '—';
  },

  _setTrendEl(el, trend) {
    if (!el) return;
    el.textContent = this._trendArrow(trend);
  },

  /**
   * v1.9 — "живой" индикатор вместо стрелки тренда мощности, пока диагностика
   * (DiagnosticsEngine.isStuckInPit()) сигналит, что реактор застрял ниже
   * порога отображения мощности. Обычная стрелка тренда в этом диапазоне
   * показывала бы "—" неотличимо от настоящего зависания интерфейса — этот
   * шеврон мигает по CSS-анимации (реальное время, не завязано на скорость
   * моделирования и на частоту кадров рендера) специально, чтобы оператор
   * видел: движок жив, просто абсолютная мощность пока не видна на шкале.
   */
  _setAliveChevron(el) {
    if (!el) return;
    el.textContent = '›';
    el.className = 'lcd-trend alive';
  },

  _angleForValue(v) {
    if (!isFinite(v)) v = this.gaugeMaxValue; // защита: NaN/Infinity не должны ронять отрисовку стрелки
    const clamped = Math.max(0, Math.min(this.gaugeMaxValue, v));
    // 180deg (v=0) -> 0deg (v=max), проходя через верх
    return 180 - (clamped / this.gaugeMaxValue) * 180;
  },

  updateGauge(powerRel) {
    const angleDeg = this._angleForValue(powerRel);
    const rad = (angleDeg * Math.PI) / 180;
    const x2 = this.gaugeCx + this.gaugeR * Math.cos(rad);
    const y2 = this.gaugeCy - this.gaugeR * Math.sin(rad);
    this.needleEl.setAttribute('x2', x2.toFixed(1));
    this.needleEl.setAttribute('y2', y2.toFixed(1));

    // Цвет стрелки меняется в зависимости от зоны
    let color = '#35e08a';
    if (powerRel > 1.2) color = '#ff3b30';
    else if (powerRel > 1.0) color = '#ffb020';
    this.needleEl.setAttribute('stroke', color);
  },

  updateReadouts(kinetics, t, stuckInPit) {
    const pct = kinetics.power * 100;
    this.powerPctEl.textContent = pct.toFixed(1);
    this.powerPctEl.className = 'lcd-value' + (pct > 120 ? ' alarm' : pct > 100 ? ' caution' : '');
    if (stuckInPit) {
      this._setAliveChevron(this.trendPowerPctEl);
    } else {
      // _setTrendEl трогает только textContent — className нужно вернуть к
      // базовому явно, иначе после выхода из "живого" состояния зелёный
      // мигающий класс остался бы навсегда на этом элементе.
      if (this.trendPowerPctEl) this.trendPowerPctEl.className = 'lcd-trend';
      this._setTrendEl(this.trendPowerPctEl, this._trend('powerPct', pct, t, 0.05));
    }

    this.powerMwtEl.textContent = Math.round(kinetics.powerMWt);
    this._setTrendEl(this.trendPowerMwtEl, this._trend('powerMwt', kinetics.powerMWt, t, 0.5));

    const period = kinetics.period;
    if (!isFinite(period) || Math.abs(period) > 999) {
      this.periodEl.textContent = '∞';
      this.periodEl.className = 'lcd-value';
      this._setTrendEl(this.trendPeriodEl, 'flat');
    } else {
      this.periodEl.textContent = period.toFixed(1);
      this.periodEl.className = 'lcd-value' + (period > 0 && period < 5 ? ' alarm' : period > 0 && period < 20 ? ' caution' : '');
      this._setTrendEl(this.trendPeriodEl, this._trend('period', period, t, 0.5));
    }
  },

  updateReactivity(rhoAbs, betaTotal, t) {
    const rhoBeta = rhoAbs / betaTotal;
    this.reactivityEl.textContent = (rhoBeta >= 0 ? '+' : '') + rhoBeta.toFixed(3);
    this.reactivityEl.className = 'lcd-value' + (rhoBeta >= 1.0 ? ' alarm' : rhoBeta > 0.3 ? ' caution' : '');
    this._setTrendEl(this.trendReactivityEl, this._trend('reactivity', rhoBeta, t, 0.0005));
  },

  updateStatus(text, isAlarm) {
    this.statusEl.textContent = text || '';
    this.statusEl.className = 'status-line' + (isAlarm ? ' alarm' : '');
  },

  /**
   * v2.3 — драматичный обратный отсчёт до терминальной аварии (отдельный
   * баннер, не переиспользует status-line — см. init()). mostUrgent —
   * {label, remainingSec, limitSec} | null, см. accident_monitor.js.
   */
  updateDangerCountdown(mostUrgent) {
    if (!this.dangerCountdownEl) return;
    if (!mostUrgent) {
      this.dangerCountdownEl.textContent = '';
      this.dangerCountdownEl.classList.remove('visible');
      return;
    }
    this.dangerCountdownEl.textContent = `⚠ ${mostUrgent.label} — до необратимых последствий: ${mostUrgent.remainingSec.toFixed(1)} с`;
    this.dangerCountdownEl.classList.add('visible');
  },

  renderRodBank(rodSystem, controlsLocked) {
    // Полосы вставки строим один раз, дальше только обновляем высоту/подписи
    if (!this._rodBankBuilt) {
      this.rodBankEl.innerHTML = '';
      this._rodFillEls = {};
      rodSystem.groups.forEach((g) => {
        const col = document.createElement('div');
        col.className = 'rod-column';

        const label = document.createElement('div');
        label.className = 'rod-label';
        label.textContent = g.label;

        // v2.5 — багфикс по замечанию пользователя: раньше нигде не было
        // видно, какая группа на какую пространственную ось влияет
        // (group1/2 — ещё и лево/право, group3/УСП — только верх/низ).
        // Короткая подпись под названием группы, всегда видимая (не
        // тултип — те легко пропустить).
        const zoneParts = [];
        if (g.zone === 'top') zoneParts.push('верх');
        if (g.zone === 'bottom') zoneParts.push('низ');
        if (g.azimuthZone === 'left') zoneParts.push('лево');
        if (g.azimuthZone === 'right') zoneParts.push('право');
        const zoneLabel = document.createElement('div');
        zoneLabel.className = 'rod-zone-label';
        zoneLabel.textContent = zoneParts.join(' · ');

        const pctLabel = document.createElement('div');
        pctLabel.className = 'rod-pct';
        pctLabel.id = `rod-pct-${g.id}`;
        pctLabel.textContent = `${Math.round(g.position)}%`;

        // Кнопки шага вместо слайдера — убирает риск случайного резкого
        // скачка (см. AGENT_HANDOFF.md): каждое нажатие двигает ровно на 1%,
        // без промежуточных значений и без риска "дёрнуть мышкой" мимо цели.
        const incBtn = document.createElement('button');
        incBtn.type = 'button';
        incBtn.className = 'rod-step-btn';
        incBtn.id = `rod-inc-${g.id}`;
        incBtn.textContent = '+';
        incBtn.title = `${g.label}: вывести на 1%`;

        const track = document.createElement('div');
        track.className = 'rod-track';
        const fill = document.createElement('div');
        fill.className = 'rod-fill';
        track.appendChild(fill);

        const decBtn = document.createElement('button');
        decBtn.type = 'button';
        decBtn.className = 'rod-step-btn';
        decBtn.id = `rod-dec-${g.id}`;
        decBtn.textContent = '−';
        decBtn.title = `${g.label}: ввести на 1%`;

        col.appendChild(label);
        col.appendChild(zoneLabel);
        col.appendChild(pctLabel);
        col.appendChild(incBtn);
        col.appendChild(track);
        col.appendChild(decBtn);
        this.rodBankEl.appendChild(col);

        this._rodFillEls[g.id] = { fill, pctLabel, incBtn, decBtn };
      });
      this._rodBankBuilt = true;
    }

    rodSystem.groups.forEach((g) => {
      const els = this._rodFillEls[g.id];
      // Высота полосы = процент ВВЕДЕНИЯ (100 - position), т.к. position = % выведен
      const insertedPct = 100 - g.position;
      els.fill.style.height = `${insertedPct}%`;
      els.fill.className = 'rod-fill' + (rodSystem.scramActive ? ' scram' : g.position < 20 ? ' warn' : '');
      els.pctLabel.textContent = `${Math.round(g.position)}%`;
      // Во время АЗ-5 ручное управление заблокировано (см. control_rods.js) —
      // кнопки визуально неактивны, а не молча ничего не делают. Аналогично —
      // до первого нажатия «Старт» (controlsLocked) органы управления
      // стержнями недоступны: реактор ещё не запущен оператором.
      els.incBtn.disabled = controlsLocked || rodSystem.scramActive || g.position >= 100;
      els.decBtn.disabled = controlsLocked || rodSystem.scramActive || g.position <= 0;
    });
  },

  /**
   * Мнемопанель БЩУ: набор плиток-табло, которые в норме приглушены и
   * загораются нужным цветом только когда параметр вышел за допустимый
   * диапазон — не текст для чтения, а состояние "окинул взглядом".
   */
  renderAnnunciator(items) {
    if (!this.annunciatorEl) return;
    if (!this._annunciatorBuilt) {
      this.annunciatorEl.innerHTML = items
        .map((it) => `<div class="annun-tile" id="annun-${it.key}">${it.label}</div>`)
        .join('');
      this._annunciatorEls = {};
      items.forEach((it) => {
        this._annunciatorEls[it.key] = document.getElementById(`annun-${it.key}`);
      });
      this._annunciatorBuilt = true;
    }
    items.forEach((it) => {
      const el = this._annunciatorEls[it.key];
      if (!el) return;
      el.className = 'annun-tile' + (it.severity !== 'normal' ? ' annun-' + it.severity : '');
    });
  },

  renderChart(history) {
    const ctx = this.chartCtx;
    const w = this.chartCanvas.width;
    const h = this.chartCanvas.height;
    ctx.clearRect(0, 0, w, h);

    // фон + сетка
    ctx.fillStyle = '#171a1d';
    ctx.fillRect(0, 0, w, h);

    if (history.length < 2) return;

    const tMax = history[history.length - 1].t;
    const tMin = Math.max(0, tMax - 120); // окно 120 секунд
    const visible = history.filter((p) => p.t >= tMin);

    let nMax = 1.5;
    for (const p of visible) if (p.n > nMax) nMax = p.n * 1.1;

    ctx.strokeStyle = '#2f363c';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = (h / 4) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // линия мощности
    ctx.strokeStyle = '#35e08a';
    ctx.lineWidth = 2;
    ctx.beginPath();
    visible.forEach((p, idx) => {
      const x = ((p.t - tMin) / (tMax - tMin || 1)) * w;
      const y = h - (p.n / nMax) * h;
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // подпись оси Y
    ctx.fillStyle = '#9aa4ad';
    ctx.font = '11px ui-monospace, monospace';
    ctx.fillText(`${(nMax * 100).toFixed(0)}%`, 4, 10);
    ctx.fillText('0%', 4, h - 4);
  },

  renderStateSummary(items) {
    this.stateSummaryEl.innerHTML = items
      .map(
        (it) =>
          `<div class="state-row"><span class="state-label">${it.label}</span><span class="state-value${
            it.severity !== 'normal' ? ' ' + it.severity : ''
          }">${it.text}</span></div>`
      )
      .join('');
  },

  renderEventLog(events, logVersion) {
    if (logVersion === this._lastLogVersion) return; // без изменений — не трогаем DOM
    this._lastLogVersion = logVersion;
    const rows = events
      .slice()
      .reverse()
      .map((e) => {
        const mm = Math.floor(e.t / 60).toString().padStart(2, '0');
        const ss = Math.floor(e.t % 60).toString().padStart(2, '0');
        return `<div class="event-item ${e.severity}"><span class="event-time">${mm}:${ss}</span><span class="event-text">${e.text}</span></div>`;
      })
      .join('');
    this.eventLogEl.innerHTML = rows;
  },

  _drawMultiLineChart(ctx, canvas, series, opts) {
    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#171a1d';
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = '#2f363c';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = (h / 4) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    const allPoints = series.flatMap((s) => s.points);
    if (allPoints.length < 2) return;

    const xMin = opts.xMin !== undefined ? opts.xMin : Math.min(...allPoints.map((p) => p.x));
    const xMax = opts.xMax !== undefined ? opts.xMax : Math.max(...allPoints.map((p) => p.x));
    const yMax = opts.yMax !== undefined ? opts.yMax : Math.max(1, ...allPoints.map((p) => p.y)) * 1.15;

    series.forEach((s) => {
      if (s.points.length < 2) return;
      ctx.strokeStyle = s.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      s.points.forEach((p, idx) => {
        const x = ((p.x - xMin) / (xMax - xMin || 1)) * w;
        const y = h - (p.y / (yMax || 1)) * h;
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    });

    ctx.fillStyle = '#9aa4ad';
    ctx.font = '11px ui-monospace, monospace';
    const yUnit = opts.yUnit !== undefined ? opts.yUnit : 'β';
    ctx.fillText(`${yMax.toFixed(1)}${yUnit}`, 4, 10);
    ctx.fillText('0', 4, h - 4);
    // Промежуточные подписи на сетке (75%/50%/25% от yMax) — без них разные
    // по масштабу линии (напр. Xe и Sm при сильно отличающихся значениях)
    // визуально выглядят "не синхронизированными", хотя данные верны: глазом
    // трудно оценить долю высоты без промежуточных делений на маленьком графике.
    ctx.fillStyle = '#6b7379';
    ctx.font = '9px ui-monospace, monospace';
    for (let i = 1; i <= 3; i++) {
      const y = (h / 4) * i;
      const val = yMax * (1 - i / 4);
      ctx.fillText(`${val.toFixed(2)}${yUnit}`, 4, y - 2);
    }
    if (opts.xLabel) {
      ctx.fillStyle = '#9aa4ad';
      ctx.font = '11px ui-monospace, monospace';
      ctx.fillText(opts.xLabel, w - ctx.measureText(opts.xLabel).width - 4, h - 4);
    }
  },

  renderPoisonChart(history) {
    if (history.length < 2) return;
    const tMax = history[history.length - 1].t;
    const windowSec = 8 * 3600; // показываем последние 8 часов модельного времени
    const tMin = Math.max(0, tMax - windowSec);
    const visible = history.filter((p) => p.t >= tMin);

    const xeSeries = { points: visible.map((p) => ({ x: p.t, y: p.Xe })), color: '#ff3b30' };
    const pmSeries = { points: visible.map((p) => ({ x: p.t, y: p.Pm })), color: '#ffb020' };
    const smSeries = { points: visible.map((p) => ({ x: p.t, y: p.Sm })), color: '#4fa3d1' };

    this._drawMultiLineChart(this.poisonChartCtx, this.poisonChartCanvas, [xeSeries, pmSeries, smSeries], {
      xMin: tMin,
      xMax: tMax,
      xLabel: 'последние 8ч',
    });
  },

  renderBurnupChart(history) {
    if (history.length < 2) return;
    const u235Series = { points: history.map((p) => ({ x: p.efpd, y: p.comp.u235 * 100 })), color: '#35e08a' };
    const pu239Series = { points: history.map((p) => ({ x: p.efpd, y: p.comp.pu239 * 100 })), color: '#ffb020' };

    this._drawMultiLineChart(this.burnupChartCtx, this.burnupChartCanvas, [u235Series, pu239Series], {
      yMax: Math.max(3, u235Series.points[0] ? u235Series.points[0].y * 1.1 : 3),
      xLabel: 'EFPD',
    });
  },

  renderComposition(comp) {
    const items = [
      { key: 'u235', label: 'U-235', color: '#35e08a' },
      { key: 'u238', label: 'U-238', color: '#3a4147' },
      { key: 'pu239', label: 'Pu-239', color: '#ffb020' },
      { key: 'pu240', label: 'Pu-240', color: '#c97c0a' },
      { key: 'pu241', label: 'Pu-241', color: '#8a5206' },
      { key: 'fp', label: 'Осколки', color: '#4fa3d1' },
    ];
    this.compositionBarEl.innerHTML = items
      .map((it) => `<div class="seg" style="width:${(comp[it.key] * 100).toFixed(2)}%; background:${it.color};" title="${it.label}: ${(comp[it.key] * 100).toFixed(2)}%"></div>`)
      .join('');
    this.compositionLegendEl.innerHTML = items
      .map((it) => `<span><span class="swatch" style="background:${it.color}"></span> ${it.label} ${(comp[it.key] * 100).toFixed(2)}%</span>`)
      .join('');
  },

  renderThermal(history, snap) {
    if (history.length >= 2) {
      const tMax = history[history.length - 1].t;
      const windowSec = 120; // последние 2 минуты модельного времени (совпадает с окном графика мощности)
      const tMin = Math.max(0, tMax - windowSec);
      const visible = history.filter((p) => p.t >= tMin);
      const tFuelSeries = { points: visible.map((p) => ({ x: p.t, y: p.tFuel })), color: '#ff8a3d' };

      this._drawMultiLineChart(this.thermalChartCtx, this.thermalChartCanvas, [tFuelSeries], {
        xMin: tMin,
        xMax: tMax,
        yMax: RBMK_PARAMS.thermal.fuelTempAlarmC * 1.15,
        yUnit: '°C',
        xLabel: 'последние 2 мин',
      });
    }

    const tempSeverity = snap.fuelTemp >= RBMK_PARAMS.thermal.fuelTempAlarmC ? 'alarm' : snap.fuelTemp >= RBMK_PARAMS.thermal.fuelTempCautionC ? 'caution' : 'normal';
    const readouts = [
      { label: 'Топливо', value: `${snap.fuelTemp.toFixed(0)}°C`, severity: tempSeverity },
      {
        label: 'Доплер ρ',
        value: `${snap.dopplerReactivityBeta.toFixed(3)} β`,
        severity: 'normal',
        tooltip:
          'Доплеровский эффект — с ростом температуры топлива резонансное поглощение нейтронов ураном-238 растёт, что вносит ОТРИЦАТЕЛЬНУЮ реактивность (быстрая, самостабилизирующая обратная связь по мощности). Величина здесь — вклад этого эффекта в общую реактивность, в единицах β.',
      },
      {
        label: 'Паровой ρ',
        value: `${snap.voidReactivityBeta >= 0 ? '+' : ''}${snap.voidReactivityBeta.toFixed(3)} β`,
        severity: 'normal',
        tooltip:
          'Паровой (пустотный) коэффициент реактивности — вклад изменения паросодержания теплоносителя в реактивность. У РБМК этот коэффициент может быть ПОЛОЖИТЕЛЬНЫМ на части режимов — рост паросодержания тогда разгоняет реактор ещё сильнее, а не гасит его (в отличие от Доплера).',
      },
      {
        label: 'Паросодержание',
        value: `${(snap.voidFraction * 100).toFixed(0)}%`,
        severity: 'normal',
        tooltip:
          'Паросодержание α — доля объёма теплоносителя в канале, занятая паром (0% — однофазная вода, 100% — сухой пар). Растёт с мощностью реактора и напрямую влияет на паровой коэффициент реактивности (см. «Паровой ρ»).',
      },
      {
        label: 'Расход',
        value: `${(snap.coolantFlowFraction * 100).toFixed(0)}%`,
        severity:
          snap.coolantFlowFraction < RBMK_PARAMS.thermal.coolantFlowRiskFraction ? 'alarm' : snap.coolantFlowFraction < 0.6 ? 'caution' : 'normal',
        tooltip:
          'Относительный расход теплоносителя (100% — номинал). Падает только при аварии (отказ ГЦН и т.п.) — это не орган ручного управления. Меньше расход при той же мощности — больше паросодержание при той же мощности (хуже охлаждение). Ниже определённого порога — риск пережога (смена режима теплообмена на паровую плёнку у поверхности твэла).',
      },
    ];
    this.thermalReadoutsEl.innerHTML = readouts
      .map(
        (r) =>
          `<div class="thermal-readout"><span class="label">${r.label}${
            r.tooltip
              ? `<span class="info-icon" tabindex="0">?<span class="info-tooltip">${r.tooltip}</span></span>`
              : ''
          }</span><span class="value ${r.severity}">${r.value}</span></div>`
      )
      .join('');

    this.voidGaugeFillEl.style.width = `${(snap.voidFraction * 100).toFixed(1)}%`;
    this.voidGaugeValEl.textContent = `${(snap.voidFraction * 100).toFixed(0)}%`;
  },

  /**
   * ЖК-табло левой панели (под мнемопанелью): числовые значения Xe-135,
   * Sm-149, температуры топлива и паросодержания — те же данные, что уже
   * идут в график отравления и панель термогидравлики, просто продублированы
   * здесь для считывания одним взглядом рядом с диагностикой. Порог
   * нечувствительности (eps) у каждого параметра соответствует его
   * отображаемой точности — иначе стрелка тренда дёргалась бы от шума
   * младшего разряда, не видимого на самом табло.
   */
  /**
   * Экранирование текста перед вставкой в innerHTML — goalText/hintText/
   * title приходят из пользовательского .scenario.json, а не сгенерированы
   * кодом (в отличие от большинства других render*() в этом файле, где
   * текст собирается самим движком). Минимальная защита от случайно (или
   * намеренно) вставленной разметки в файле сценария.
   */
  _esc(str) {
    if (str === undefined || str === null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  },

  /**
   * v1.17 — панель «Задание сценария». meta=null/goalsState=[] — сценарий не
   * загружен (плейсхолдер). progress не null только у kind:"hold" — там
   * прогресс имеет смысл (доля от durationSec); для остальных kind
   * показываем только текстовый статус.
   */
  renderScenarioPanel(meta, goalsState) {
    if (!this.scenarioTitleEl || !this.scenarioGoalsEl) return;

    if (this.scenarioResetBtnEl) this.scenarioResetBtnEl.disabled = !meta;

    if (!meta) {
      this.scenarioTitleEl.textContent = 'Сценарий не загружен';
      this.scenarioGoalsEl.innerHTML = '';
      return;
    }

    this.scenarioTitleEl.innerHTML =
      this._esc(meta.title) +
      (meta.description ? `<span class="scenario-subtitle">${this._esc(meta.description)}</span>` : '');

    // v2.0 — instructions[]: явная, пронумерованная последовательность
    // действий оператора. Присутствует только в УРОКАХ (не в голом
    // сценарии) — это и есть видимая, функциональная разница между
    // "Загрузить сценарий" (состояние+цель) и "Загрузить урок" (сценарий +
    // объяснение, как её достигать), см. LESSON_FORMAT_SPEC.md.
    const instructionsHtml =
      meta.instructions && meta.instructions.length
        ? `<div class="scenario-instructions">
            <div class="scenario-instructions-title">Порядок действий</div>
            <ol class="scenario-instructions-list">${meta.instructions.map((step) => `<li>${this._esc(step)}</li>`).join('')}</ol>
          </div>`
        : '';

    if (!goalsState || goalsState.length === 0) {
      this.scenarioGoalsEl.innerHTML = instructionsHtml + '<div class="scenario-goal-empty">В этом сценарии нет целей — только информационные сообщения в журнале событий.</div>';
      return;
    }

    // v2.0 — sequentialGoals: игровой формат "одна цель за раз" (см.
    // scenario_engine.js). Порядок целей = порядок в goals[] файла —
    // движок это же самое порядок и использует как индекс завершения.
    if (meta.sequentialGoals) {
      this.scenarioGoalsEl.innerHTML = instructionsHtml + this._renderSequentialGoals(goalsState);
      return;
    }

    this.scenarioGoalsEl.innerHTML = instructionsHtml + goalsState.map((g) => this._renderGoalCard(g)).join('');
  },

  /** Полная карточка одной цели — общий markup для обычного и sequential-режима. */
  _renderGoalCard(g) {
    const classes = ['scenario-goal'];
    if (g.completed) classes.push('completed');
    if (g.failed) classes.push('failed'); // guarded-reach: срыв после успеха — отличимо от "ещё не начато"

    const progressHtml =
      g.progress !== null
        ? `<div class="scenario-goal-progress-track"><div class="scenario-goal-progress-fill" style="width:${Math.round(g.progress * 100)}%"></div></div>`
        : '';
    const metaText = g.progress !== null ? `${Math.round(g.progress * 100)}%` : g.completed ? 'выполнено' : g.failed ? 'сорвано' : '';

    // v2.0 — инструкция КОНКРЕТНОЙ цели (goal.instructions), отдельно от
    // общего лесонного instructionsHtml (тот — на весь урок сразу). Только
    // в sequential-режиме это реально используется (см. _renderSequentialGoals).
    const goalInstructionsHtml =
      g.instructions && g.instructions.length
        ? `<div class="scenario-goal-instructions">
            <div class="scenario-instructions-title">Как сделать</div>
            <ol class="scenario-instructions-list">${g.instructions.map((step) => `<li>${this._esc(step)}</li>`).join('')}</ol>
          </div>`
        : '';

    return `<div class="${classes.join(' ')}">
      <div class="scenario-goal-dot"></div>
      <div class="scenario-goal-body">
        <div class="scenario-goal-text" title="${this._esc(g.hintText || '')}">${this._esc(g.goalText || g.title || '')}</div>
        ${goalInstructionsHtml}
        ${progressHtml}
      </div>
      <div class="scenario-goal-meta">${metaText}</div>
    </div>`;
  },

  /** Свёрнутая строка уже пройденной цели (только заголовок + галочка) — история над активной целью. */
  _renderGoalCollapsedDone(g) {
    return `<div class="scenario-goal-collapsed">
      <span class="scenario-goal-collapsed-dot">✓</span>
      <span class="scenario-goal-collapsed-title">${this._esc(g.title || g.goalText || '')}</span>
    </div>`;
  },

  /**
   * v2.0 — рендер "одна цель за раз": уже пройденные цели сворачиваются в
   * короткую историю сверху (без текста цели/инструкции — чтобы не грузить
   * панель), первая невыполненная цель по порядку файла показывается
   * полностью (с её персональной instructions[]), всё, что идёт ПОСЛЕ неё,
   * вообще не рендерится — не спойлерим следующие шаги. Если пройдены
   * ВСЕ цели — вместо активной карточки показывается баннер завершения.
   */
  _renderSequentialGoals(goalsState) {
    const activeIndex = goalsState.findIndex((g) => !g.completed);
    const doneGoals = activeIndex === -1 ? goalsState : goalsState.slice(0, activeIndex);
    const historyHtml = doneGoals.length
      ? `<div class="scenario-goals-history">${doneGoals.map((g) => this._renderGoalCollapsedDone(g)).join('')}</div>`
      : '';

    if (activeIndex === -1) {
      return historyHtml + '<div class="scenario-complete-banner">🎉 Урок пройден — все цели выполнены.</div>';
    }

    return historyHtml + this._renderGoalCard(goalsState[activeIndex]);
  },

  renderCoreReadouts(snap, t) {
    if (!this.coreReadoutsEl) return;
    const th = RBMK_PARAMS.thermal;
    const tempSeverity = snap.fuelTemp >= th.fuelTempAlarmC ? 'alarm' : snap.fuelTemp >= th.fuelTempCautionC ? 'caution' : '';
    const voidPct = snap.voidFraction * 100;

    // v1.7 — Пространственная модель, п.2: осевой перекос ксенона
    // (верх-низ, β). Знак сохраняется (может быть и +, и -) — в отличие от
    // остальных readout'ов этой панели, это НЕ уровень отравления, а именно
    // разница/асимметрия. Severity нарочито не строгая (только caution) —
    // сам по себе перекос не авария, опасен лишь в сочетании с низким ОЗР
    // (см. AGENT_HANDOFF.md) — эту связь показывает диагностика/журнал, а не
    // цвет этого конкретного числа.
    const axialAbs = Math.abs(snap.axialOffsetBeta);
    const axialSeverity = axialAbs >= 2.0 ? 'caution' : '';
    // v2.5 — вторая ось (лево/право): та же логика, что и у осевой версии.
    const azimuthAbs = Math.abs(snap.azimuthOffsetBeta);
    const azimuthSeverity = azimuthAbs >= 2.0 ? 'caution' : '';

    const rows = [
      { key: 'xe', label: 'Xe-135', value: snap.xenonLevel, decimals: 2, unit: 'β', eps: 0.005, severity: '' },
      { key: 'pm', label: 'Pm-149', value: snap.promethiumLevel, decimals: 2, unit: 'β', eps: 0.005, severity: '' },
      { key: 'sm', label: 'Sm-149', value: snap.samariumLevel, decimals: 2, unit: 'β', eps: 0.005, severity: '' },
      { key: 'tfuel', label: 'Топливо', value: snap.fuelTemp, decimals: 0, unit: '°C', eps: 0.5, severity: tempSeverity },
      { key: 'void', label: 'Паросодерж', value: voidPct, decimals: 0, unit: '%', eps: 0.5, severity: '' },
      { key: 'axial', label: 'Перекос в-н', value: snap.axialOffsetBeta, decimals: 2, unit: 'β', eps: 0.02, severity: axialSeverity, signed: true },
      { key: 'azimuth', label: 'Перекос л-п', value: snap.azimuthOffsetBeta, decimals: 2, unit: 'β', eps: 0.02, severity: azimuthSeverity, signed: true },
    ];

    this.coreReadoutsEl.innerHTML = rows
      .map((r) => {
        const trend = this._trend(r.key, r.value, t, r.eps);
        const valueClass = 'lcd-value' + (r.severity ? ' ' + r.severity : '');
        const displayValue = (r.signed && r.value >= 0 ? '+' : '') + r.value.toFixed(r.decimals);
        return (
          `<div class="core-readout">` +
          `<span class="core-readout-label">${r.label}</span>` +
          `<div class="lcd-screen">` +
          `<span class="${valueClass}">${displayValue}</span>` +
          `<span class="lcd-unit">${r.unit}</span>` +
          `<span class="lcd-trend">${this._trendArrow(trend)}</span>` +
          `</div></div>`
        );
      })
      .join('');
  },
};
