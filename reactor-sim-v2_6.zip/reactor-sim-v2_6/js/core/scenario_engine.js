// scenario_engine.js
//
// Реализация класса ScenarioEngine по SCENARIO_ENGINE_DESIGN.md — движок
// целей/сообщений сценария. НЕ хранит и не запрашивает kinetics/rodSystem
// напрямую — все данные получает через snapshot, переданный извне (тот же
// принцип, что уже применяется в diagnostics.js). Использует
// evaluateCondition() из condition_lang.js как есть, без изменений.
//
// v1.19 — ВАЖНАЯ ПРАВКА ТАЙМИНГА: движок считает время РЕАЛЬНОЕ (то, что
// прошло на часах у оператора), а НЕ модельное время реактора (kinetics.t).
// Причина: в приложении есть ускорение симуляции (×1…×3600). Если бы
// "удержать 60 секунд" считалось в модельном времени, на ×60 это
// пролетало бы за 1 реальную секунду — оператор физически не успевал бы
// ничего удерживать, весь смысл упражнения терялся. Раньше (v1.15–v1.18)
// счёт шёл по modelTimeSec (kinetics.t) — это было неверно, найдено и
// исправлено по прямому замечанию пользователя. Теперь: НИКАКОГО
// модельного времени внутри движка вообще нет, только реальные секунды,
// переданные вызывающим кодом как дельта на каждый tick().
//
// Публичный API (изменён относительно v1.15-v1.18):
//   load(scenarioJson) -> { ok: true } | { ok: false, error }
//   unload()
//   isLoaded()
//   getMeta() -> { id, title, description, instructions, sequentialGoals }
//   tick(snapshot, realDtSec, simRunning)   — realDtSec: реальные секунды с прошлого tick();
//     simRunning — v2.3: goals/messages двигаются ВСЕГДА (как раньше), а вот
//     faults[] — только пока simRunning=true (авария не должна "тикать" на паузе)
//   getGoalsState() -> [{ id, title, goalText, hintText, instructions, type, kind, completed, progress, failed }]
//   getActiveMessages() -> [{ id, text, severity }]   (очередь — вычитывается и опустошается)
//   getActiveFaultEffects() -> {coolantFlowFraction?: number}  — v2.3, см. faults[]
//   resetGoal(id)
//   resetAll()   — v2.3: тоже заново "взводит" faults[] (см. ниже)
//   resetFaults()   — v2.3: ТОЛЬКО faults[], без прогресса целей (см. main.js afterStartReset())
//   rebase()   — больше не принимает время: обнуляет только scenarioTimeSec

// Внутренние helper-функции (isPlainObject/validateGoal/stepGoal/...) не
// должны попасть в глобальную область — в этом проекте каждый файл-класс
// (kinetics.js/control_rods.js/...) объявляет РОВНО ОДНО глобальное имя.
// Оборачиваем всё в IIFE и наружу отдаём только сам класс ScenarioEngine —
// либо через module.exports (node, тесты), либо как глобальную переменную
// (браузер, обычный <script>, без require/сборщика).
(function (global) {
  // В браузере evaluateCondition уже глобально доступна — condition_lang.js
  // подключается как обычный <script> раньше scenario_engine.js в index.html
  // (порядок важен). В node (тесты, запуск напрямую через
  // `node js/core/scenario_engine.test.js`) global-окружения с DOM нет,
  // поэтому здесь же, если доступен require, подтягиваем ту же функцию через
  // него — присваивание в локальную переменную этого IIFE, не отдельное
  // глобальное объявление, поэтому конфликтовать не с чем.
  const evaluateCondition = typeof require === 'function'
    ? require('./condition_lang.js').evaluateCondition
    : global.evaluateCondition;

  const VALID_KINDS = ['hold', 'reach', 'guarded-reach', 'sequence'];
const VALID_TYPES = ['exercise', 'task'];
const VALID_SEVERITIES = ['info', 'caution'];

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

// v2.0 — общий валидатор для instructions[] (и на уровне всего сценария, и
// на уровне отдельной цели, см. ниже) — необязательное поле: если
// отсутствует, возвращает null (ок, значит массив просто пуст).  Не
// вызывает исключений — как и остальная валидация в этом файле, ошибка
// возвращается строкой, а не throw.
function validateStringArrayField(container, fieldName, where) {
  if (container[fieldName] === undefined) return null;
  const arr = container[fieldName];
  if (!Array.isArray(arr)) return `${where}: ${fieldName} не массив`;
  for (let i = 0; i < arr.length; i++) {
    if (typeof arr[i] !== 'string' || !arr[i]) {
      return `${where}: ${fieldName}[${i}] должен быть непустой строкой`;
    }
  }
  return null;
}

// Валидирует один goal, возвращает строку ошибки или null, если всё ок.
function validateGoal(goal, index) {
  const where = `goals[${index}]`;
  if (!isPlainObject(goal)) return `${where}: не объект`;
  if (typeof goal.id !== 'string' || !goal.id) return `${where}: отсутствует или пустой id`;
  if (VALID_TYPES.indexOf(goal.type) === -1) {
    return `${where} (id=${goal.id}): недопустимый type "${goal.type}", ожидается один из ${VALID_TYPES.join('/')}`;
  }
  if (VALID_KINDS.indexOf(goal.kind) === -1) {
    return `${where} (id=${goal.id}): недопустимый kind "${goal.kind}", ожидается один из ${VALID_KINDS.join('/')}`;
  }
  const params = goal.params;
  if (!isPlainObject(params)) return `${where} (id=${goal.id}): отсутствует params`;
  // v2.0 — instructions[] на уровне ОТДЕЛЬНОЙ цели: собственное "как это
  // сделать" для конкретной цели, а не общее на весь урок (см.
  // scenarioJson.instructions выше и sequentialGoals ниже — вместе они дают
  // игровой формат "одна цель за раз, каждая со своей инструкцией").
  const instrErr = validateStringArrayField(goal, 'instructions', `${where} (id=${goal.id})`);
  if (instrErr) return instrErr;
  switch (goal.kind) {
    case 'hold':
      if (!isPlainObject(params.condition)) return `${where} (id=${goal.id}): hold требует params.condition`;
      if (typeof params.durationSec !== 'number' || params.durationSec <= 0) {
        return `${where} (id=${goal.id}): hold требует params.durationSec > 0`;
      }
      break;
    case 'reach':
      if (!isPlainObject(params.condition)) return `${where} (id=${goal.id}): reach требует params.condition`;
      break;
    case 'guarded-reach':
      if (!isPlainObject(params.targetCondition)) {
        return `${where} (id=${goal.id}): guarded-reach требует params.targetCondition`;
      }
      if (!isPlainObject(params.forbidCondition)) {
        return `${where} (id=${goal.id}): guarded-reach требует params.forbidCondition`;
      }
      break;
    case 'sequence':
      if (typeof params.initial !== 'string') return `${where} (id=${goal.id}): sequence требует params.initial`;
      if (typeof params.success !== 'string') return `${where} (id=${goal.id}): sequence требует params.success`;
      if (!isPlainObject(params.states)) return `${where} (id=${goal.id}): sequence требует params.states`;
      if (!Object.prototype.hasOwnProperty.call(params.states, params.initial)) {
        return `${where} (id=${goal.id}): params.initial "${params.initial}" не найден в params.states`;
      }
      break;
    default:
      // недостижимо — kind уже провалидирован выше
      break;
  }
  return null;
}

function validateMessage(msg, index) {
  const where = `messages[${index}]`;
  if (!isPlainObject(msg)) return `${where}: не объект`;
  if (typeof msg.id !== 'string' || !msg.id) return `${where}: отсутствует или пустой id`;
  if (typeof msg.text !== 'string' || !msg.text) return `${where} (id=${msg.id}): отсутствует text`;
  if (msg.severity !== undefined && VALID_SEVERITIES.indexOf(msg.severity) === -1) {
    return `${where} (id=${msg.id}): недопустимый severity "${msg.severity}"`;
  }
  if (!isPlainObject(msg.condition)) return `${where} (id=${msg.id}): отсутствует condition`;
  return null;
}

// v2.3 — faults[]: аварийные триггеры сценария (см. AGENT_HANDOFF.md, "План
// новой физики"). В отличие от messages[] (только текст), effect РЕАЛЬНО
// действует на физику через main.js (см. getActiveFaultEffects()) — engine
// сам физику не трогает, только считает, какое значение должно быть
// применено СЕЙЧАС, вызывающий код (main.js) сам решает, куда его положить.
const VALID_FAULT_EFFECT_TYPES = ['coolantFlowRamp'];
function validateFault(fault, index) {
  const where = `faults[${index}]`;
  if (!isPlainObject(fault)) return `${where}: не объект`;
  if (typeof fault.id !== 'string' || !fault.id) return `${where}: отсутствует или пустой id`;
  if (!isPlainObject(fault.trigger)) return `${where} (id=${fault.id}): отсутствует trigger`;
  const effect = fault.effect;
  if (!isPlainObject(effect)) return `${where} (id=${fault.id}): отсутствует effect`;
  if (VALID_FAULT_EFFECT_TYPES.indexOf(effect.type) === -1) {
    return `${where} (id=${fault.id}): недопустимый effect.type "${effect.type}" (допустимо: ${VALID_FAULT_EFFECT_TYPES.join(', ')})`;
  }
  if (typeof effect.to !== 'number' || effect.to < 0 || effect.to > 1) {
    return `${where} (id=${fault.id}): effect.to должен быть числом в диапазоне 0..1`;
  }
  if (typeof effect.durationSec !== 'number' || effect.durationSec <= 0) {
    return `${where} (id=${fault.id}): effect.durationSec должен быть положительным числом`;
  }
  return null;
}

// Начальное внутреннее состояние цели, зависящее от kind.
function initialGoalRuntimeState(goal) {
  switch (goal.kind) {
    case 'hold':
      return { timerSec: 0 };
    case 'reach':
      return { done: false };
    case 'guarded-reach':
      return { reachedTarget: false, failed: false };
    case 'sequence':
      return { currentState: goal.params.initial };
    default:
      return {};
  }
}

function isGoalCompleted(goal, state) {
  switch (goal.kind) {
    case 'hold':
      return state.timerSec >= goal.params.durationSec;
    case 'reach':
      return state.done === true;
    case 'guarded-reach':
      return state.reachedTarget === true;
    case 'sequence':
      return state.currentState === goal.params.success;
    default:
      return false;
  }
}

// Продвигает состояние одной цели на dt РЕАЛЬНЫХ секунд, учитывая текущий
// snapshot (уже дополненный scenarioTimeSec). Мутирует state.
function stepGoal(goal, state, snapshot, dtSec) {
  switch (goal.kind) {
    case 'hold': {
      const conditionTrue = evaluateCondition(snapshot, goal.params.condition);
      if (conditionTrue) {
        state.timerSec += dtSec;
      } else {
        state.timerSec = 0;
      }
      break;
    }
    case 'reach': {
      if (!state.done) {
        state.done = evaluateCondition(snapshot, goal.params.condition);
      }
      break;
    }
    case 'guarded-reach': {
      const forbidNow = evaluateCondition(snapshot, goal.params.forbidCondition);
      if (forbidNow) {
        // Срыв откатывает reachedTarget, а не только failed — попытка
        // должна начаться заново, а не остаться "наполовину защёлкнутой".
        state.reachedTarget = false;
        state.failed = true;
      } else {
        const targetNow = evaluateCondition(snapshot, goal.params.targetCondition);
        if (targetNow) {
          state.reachedTarget = true;
          state.failed = false;
        }
      }
      break;
    }
    case 'sequence': {
      const currentDef = goal.params.states[state.currentState];
      const transitions = (currentDef && currentDef.transitions) || [];
      for (let i = 0; i < transitions.length; i++) {
        const t = transitions[i];
        if (evaluateCondition(snapshot, t.if)) {
          state.currentState = t.goto;
          break; // первый истинный переход по порядку массива, не все сразу
        }
      }
      break;
    }
    default:
      break;
  }
}

class ScenarioEngine {
  constructor() {
    this._loaded = false;
    this._scenario = null;
    this._goalRuntimes = null; // Map(id -> { goal, state })
    this._messageRuntimes = null; // Map(id -> { msg, prevTrue, everShown })
    this._faultRuntimes = null; // Map(id -> { fault, triggered, triggerTimeSec })
    this._pendingMessages = [];
    // Реальные секунды с момента load()/rebase() — НЕ модельное время.
    this._scenarioElapsedSec = 0;
    // v2.3 — ОТДЕЛЬНЫЙ счётчик реального времени для faults[]: в отличие
    // от _scenarioElapsedSec (двигается ВСЕГДА, даже на паузе — так нужно
    // целям/сообщениям, см. AGENT_HANDOFF.md v1.19), аварии не должны
    // "тикать", пока реактор физически стоит на паузе — иначе Х/Г-старт
    // "лечит" аварию лишь на мгновение, пока не пройдёт очередной порог
    // времени. Двигается ТОЛЬКО когда tick() вызван с simRunning=true.
    this._faultElapsedSec = 0;
  }

  load(scenarioJson) {
    if (!isPlainObject(scenarioJson)) {
      return { ok: false, error: 'Файл сценария повреждён: ожидается JSON-объект' };
    }
    if (typeof scenarioJson.id !== 'string' || !scenarioJson.id) {
      return { ok: false, error: 'Файл сценария повреждён: отсутствует id' };
    }
    if (typeof scenarioJson.title !== 'string' || !scenarioJson.title) {
      return { ok: false, error: 'Файл сценария повреждён: отсутствует title' };
    }
    const goals = scenarioJson.goals !== undefined ? scenarioJson.goals : [];
    const messages = scenarioJson.messages !== undefined ? scenarioJson.messages : [];
    const faults = scenarioJson.faults !== undefined ? scenarioJson.faults : [];
    // instructions — необязательное поле, отличающее УРОК от голого
    // сценария: явная, пронумерованная последовательность действий
    // оператора для достижения цели ("сначала снизить мощность стержнями
    // группы 3, затем..."), а не просто формулировка самой цели/подсказка
    // к ней. Сценарий (.scenario.json) обычно этого поля не содержит —
    // именно это и есть функциональная разница между "загрузить сценарий"
    // и "загрузить урок" (см. LESSON_FORMAT_SPEC.md).
    if (!Array.isArray(goals)) return { ok: false, error: 'Файл сценария повреждён: goals не массив' };
    if (!Array.isArray(messages)) return { ok: false, error: 'Файл сценария повреждён: messages не массив' };
    if (!Array.isArray(faults)) return { ok: false, error: 'Файл сценария повреждён: faults не массив' };
    const topInstrErr = validateStringArrayField(scenarioJson, 'instructions', 'Файл сценария повреждён');
    if (topInstrErr) return { ok: false, error: topInstrErr };
    // v2.0 — sequentialGoals: необязательный флаг (по умолчанию false —
    // старое поведение без изменений). true включает игровой режим "одна
    // цель за раз": пока цель N не выполнена, цели N+1..конец не
    // показываются вообще, а при выполнении текущей цели движок сам
    // добавляет короткое сообщение-подтверждение в журнал (см. tick() ниже).
    // Рендер — Dashboard.renderScenarioPanel() (js/ui/dashboard.js).
    if (scenarioJson.sequentialGoals !== undefined && typeof scenarioJson.sequentialGoals !== 'boolean') {
      return { ok: false, error: 'Файл сценария повреждён: sequentialGoals должен быть boolean' };
    }

    for (let i = 0; i < goals.length; i++) {
      const err = validateGoal(goals[i], i);
      if (err) return { ok: false, error: `Файл сценария повреждён: ${err}` };
    }
    for (let i = 0; i < messages.length; i++) {
      const err = validateMessage(messages[i], i);
      if (err) return { ok: false, error: `Файл сценария повреждён: ${err}` };
    }
    for (let i = 0; i < faults.length; i++) {
      const err = validateFault(faults[i], i);
      if (err) return { ok: false, error: `Файл сценария повреждён: ${err}` };
    }

    // Валидация пройдена — строим внутренние структуры.
    const goalRuntimes = new Map();
    for (const goal of goals) {
      goalRuntimes.set(goal.id, {
        goal,
        state: initialGoalRuntimeState(goal),
      });
    }
    const messageRuntimes = new Map();
    for (const msg of messages) {
      messageRuntimes.set(msg.id, {
        msg,
        prevTrue: false,
        everShown: false,
      });
    }
    const faultRuntimes = new Map();
    for (const fault of faults) {
      faultRuntimes.set(fault.id, {
        fault,
        triggered: false,
        triggerTimeSec: null,
      });
    }

    this._loaded = true;
    this._scenario = scenarioJson;
    this._goalRuntimes = goalRuntimes;
    this._messageRuntimes = messageRuntimes;
    this._faultRuntimes = faultRuntimes;
    this._pendingMessages = [];
    this._scenarioElapsedSec = 0;
    this._faultElapsedSec = 0;
    return { ok: true };
  }

  unload() {
    this._loaded = false;
    this._scenario = null;
    this._goalRuntimes = null;
    this._messageRuntimes = null;
    this._faultRuntimes = null;
    this._pendingMessages = [];
  }

  isLoaded() {
    return this._loaded;
  }

  getMeta() {
    if (!this._loaded) return null;
    return {
      id: this._scenario.id,
      title: this._scenario.title,
      description: this._scenario.description || '',
      instructions: this._scenario.instructions || [],
      sequentialGoals: this._scenario.sequentialGoals === true,
    };
  }

  /**
   * @param snapshot - текущий срез модели (как для diagnostics.evaluate())
   * @param realDtSec - РЕАЛЬНЫЕ секунды, прошедшие с прошлого tick() (не
   *   модельное время, не умноженное на simSpeed — то, что показывают часы
   *   на стене). Вызывающий код (main.js) уже считает эту величину для
   *   собственных нужд (realDt, до умножения на simSpeed) — сюда передаётся
   *   она же, без изменений.
   */
  tick(snapshot, realDtSec, simRunning) {
    if (!this._loaded) return;
    const dtSec = Math.max(0, realDtSec);
    this._scenarioElapsedSec += dtSec;
    // v2.3 — faults[] используют ОТДЕЛЬНЫЙ снап с scenarioTimeSec от
    // _faultElapsedSec (двигается только пока simRunning=true — см.
    // конструктор). goals/messages по-прежнему используют общий snap с
    // _scenarioElapsedSec (двигается всегда) — их поведение не меняется.
    if (simRunning) this._faultElapsedSec += dtSec;

    const snap = Object.assign({}, snapshot, { scenarioTimeSec: this._scenarioElapsedSec });

    for (const runtime of this._goalRuntimes.values()) {
      const { goal, state } = runtime;
      const wasCompleted = isGoalCompleted(goal, state);
      if (goal.type === 'exercise' && wasCompleted) {
        // Упражнение: успех навсегда, движок больше не тратит тик на
        // пересчёт условия этой цели.
        continue;
      }
      stepGoal(goal, state, snap, dtSec);
      // v2.0 — авто-подтверждение выполнения цели (только для
      // sequentialGoals-уроков, см. load()). Обычные сценарии без этого
      // флага ведут себя байт-в-байт как раньше — никакого нового
      // сообщения не появляется, если автор явно не включил игровой режим.
      if (this._scenario.sequentialGoals && !wasCompleted && isGoalCompleted(goal, state)) {
        this._pendingMessages.push({
          id: `__goal-complete-${goal.id}`,
          text: `Цель «${goal.title}» выполнена!`,
          severity: 'info',
        });
      }
    }

    for (const runtime of this._messageRuntimes.values()) {
      const { msg } = runtime;
      const nowTrue = evaluateCondition(snap, msg.condition);
      const risingEdge = nowTrue && !runtime.prevTrue;
      if (risingEdge && (msg.repeat === true || !runtime.everShown)) {
        this._pendingMessages.push({
          id: msg.id,
          text: msg.text,
          severity: msg.severity || 'info',
        });
        runtime.everShown = true;
      }
      runtime.prevTrue = nowTrue;
    }

    // v2.3 — faults[]: срабатывает РОВНО один раз за загрузку (не repeat,
    // в отличие от messages) — авария не должна "переигрываться" заново,
    // если условие триггера почему-то станет ложным и снова истинным.
    // triggerTimeSec фиксируется в МОМЕНТ срабатывания — от него отсчитывается
    // прогресс рампы в getActiveFaultEffects(), а не от начала сценария.
    // Оценка триггера — ТОЛЬКО пока simRunning=true, на своём отдельном
    // снапе (scenarioTimeSec переопределён на _faultElapsedSec) — иначе на
    // паузе авария, привязанная к чистому времени, срабатывала бы "втихую",
    // пока оператор ничего не делает (найдено при проверке Х/Г-старта после
    // аварии — реактор "лечился" только на мгновение).
    if (simRunning) {
      const faultSnap = Object.assign({}, snapshot, { scenarioTimeSec: this._faultElapsedSec });
      for (const runtime of this._faultRuntimes.values()) {
        if (runtime.triggered) continue;
        if (evaluateCondition(faultSnap, runtime.fault.trigger)) {
          runtime.triggered = true;
          runtime.triggerTimeSec = this._faultElapsedSec;
        }
      }
    }
  }

  /**
   * Текущие значения, которые сработавшие faults[] должны СЕЙЧАС применить
   * к физике — движок сам физику не трогает (не знает про kinetics.js),
   * это отдаёт main.js, который решает, куда именно положить значение.
   * Пока поддержан один тип эффекта (coolantFlowRamp) — если сработало
   * несколько одновременно, берётся ХУДШИЙ (наименьший) расход, а не
   * последний по порядку — консервативно с точки зрения безопасности.
   * @returns {{coolantFlowFraction?: number}}
   */
  getActiveFaultEffects() {
    if (!this._loaded) return {};
    let coolantFlowFraction = null;
    for (const runtime of this._faultRuntimes.values()) {
      if (!runtime.triggered) continue;
      const { effect } = runtime.fault;
      if (effect.type === 'coolantFlowRamp') {
        const elapsed = this._faultElapsedSec - runtime.triggerTimeSec;
        const progress = Math.max(0, Math.min(1, elapsed / effect.durationSec));
        const value = 1 + (effect.to - 1) * progress; // рампа ОТ полного расхода (1.0) К effect.to
        if (coolantFlowFraction === null || value < coolantFlowFraction) coolantFlowFraction = value;
      }
    }
    return coolantFlowFraction === null ? {} : { coolantFlowFraction };
  }

  getGoalsState() {
    if (!this._loaded) return [];
    const result = [];
    for (const runtime of this._goalRuntimes.values()) {
      const { goal, state } = runtime;
      let progress = null;
      if (goal.kind === 'hold') {
        progress = Math.max(0, Math.min(1, state.timerSec / goal.params.durationSec));
      }
      result.push({
        id: goal.id,
        title: goal.title,
        goalText: goal.goalText,
        hintText: goal.hintText,
        instructions: goal.instructions || [],
        type: goal.type,
        kind: goal.kind,
        completed: isGoalCompleted(goal, state),
        progress,
        // Только у guarded-reach есть содержательное значение — остальным
        // kind это поле не нужно, undefined ожидаемо и безопасно для UI.
        failed: goal.kind === 'guarded-reach' ? state.failed : undefined,
      });
    }
    return result;
  }

  // Очередь: вызывающий код вычитывает накопленные сообщения, движок
  // отдаёт их и опустошает очередь — повторный вызов без нового tick()
  // вернёт пустой массив.
  getActiveMessages() {
    const pending = this._pendingMessages;
    this._pendingMessages = [];
    return pending;
  }

  resetGoal(id) {
    if (!this._loaded) return;
    const runtime = this._goalRuntimes.get(id);
    if (!runtime) return;
    runtime.state = initialGoalRuntimeState(runtime.goal);
  }

  resetAll() {
    if (!this._loaded) return;
    for (const runtime of this._goalRuntimes.values()) {
      runtime.state = initialGoalRuntimeState(runtime.goal);
    }
    this.resetFaults();
  }

  /**
   * v2.3 — заново "взводит" ТОЛЬКО faults[], не трогая прогресс целей (в
   * отличие от resetAll()). Нужен отдельно: Горячий/Холодный старт должен
   * "вылечить" реактор от последствий сработавшей аварии (расход
   * теплоносителя и т.п. — см. main.js afterStartReset()), но НЕ должен
   * заодно списывать прогресс уже выполненных целей урока — это разные,
   * независимые вещи (тот же принцип разделения, что уже применён для
   * rebase() vs resetAll(), см. комментарий у rebase() ниже).
   */
  resetFaults() {
    if (!this._loaded) return;
    for (const runtime of this._faultRuntimes.values()) {
      runtime.triggered = false;
      runtime.triggerTimeSec = null;
    }
    this._faultElapsedSec = 0;
  }

  // Обнуляет только scenarioTimeSec (реальные секунды с начала сценария) —
  // прогресс целей (timerSec/completed/...) НЕ трогает. Раньше (v1.15-v1.18)
  // это было нужно, чтобы защититься от скачка modelTimeSec при Х/Г-старте;
  // теперь движок вообще не знает о модельном времени, но метод сохранён —
  // Х/Г-старт/загрузка состояния всё ещё разумно считать новой "точкой
  // отсчёта" сценарного времени (для сообщений/sequence, которые могут
  // зависеть от scenarioTimeSec), не сбрасывая при этом прогресс целей.
  rebase() {
    if (!this._loaded) return;
    this._scenarioElapsedSec = 0;
    this._faultElapsedSec = 0;
  }
}

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ScenarioEngine };
  } else {
    global.ScenarioEngine = ScenarioEngine;
  }
})(typeof window !== 'undefined' ? window : globalThis);
